# ARENA X

A tournament platform for Free Fire MAX solo, duo and squad events. Players register, form teams,
join matches, receive private room details at release time, submit results, and follow leaderboards.
Administrators run tournaments, verify results, release room credentials, record prize allocations
and moderate accounts.

ARENA X is an independent community tool. It is not made by, endorsed by or affiliated with Garena
or Free Fire MAX, and it uses no official logos or artwork. The app records prize allocations only;
it does not pay anyone. Prize payments happen outside the app and are recorded by an administrator.

## Requirements

- Node.js 22.13 or newer (uses the built-in `node:sqlite` module and `node:http`).
- npm.

## Setup

```bash
npm install
npm run build          # bundles the web app into public/ and typechecks the server
npm run migrate        # creates the database schema (also runs automatically on first start)
npm start              # serves on http://127.0.0.1:3000
```

Set `ARENA_SECRET` (32+ characters) before storing any real room credentials. See `.env.example`.

## Creating an administrator

Public registration can never create an administrator. Use the bootstrap command on the server:

```bash
ARENA_ADMIN_PASSWORD='at-least-12-characters' npm run admin:create -- --email ops@example.com --name "ARENA Ops"
```

Running it again for an existing email promotes that account and resets its password. Only people
with access to the server and its environment should be able to run it.

## Development data

```bash
npm run seed           # demo tournaments, players and one duo team; refuses to run in production
```

The seed prints generated local-only passwords once. They are for development databases only.

## Tests

```bash
npm test               # unit, integration, HTTP and browser tests (node:test, real SQLite files in temp directories)
npm run test:unit
npm run test:integration
npm run test:browser   # drives the built web app in Chromium; skips with a reason if Chromium cannot launch
```

Set `ARENA_SCREENSHOT_DIR` to keep the browser test's screenshots. Run `npm run build` first, because the
browser test serves the bundle in `public/`.

The integration suite covers registration capacity and waitlists, duplicate protection, lifecycle
guards, room credential release and access logging, result verification, standings and prize
allocation, audit-chain tamper detection, HTTP security controls, and a cross-process registration
race. See `docs/IMPLEMENTATION_STATUS.md` for what is and is not covered.

## Project layout

- `server/domain/` pure rules: scoring, ranking and tie-breaks, prize arithmetic, tournament lifecycle, permissions.
- `server/services/` transactional business operations.
- `server/http/` HTTP server, routing, sessions, CSRF checks, server-sent events.
- `server/db/migrations/` versioned SQL migrations.
- `web/src/` React single-page app, bundled by `scripts/build-web.mjs`.
- `tests/` unit, integration and helper code.
- `docs/` implementation status and security notes.

## Known limits

Read `docs/SECURITY.md` before running this anywhere other than a local machine. In short: the app
is a single process with an in-memory rate limiter and live-update bus, so it is not built for
multiple instances; it has not been through an external security review; and no hosting, backup or
monitoring setup is included.
