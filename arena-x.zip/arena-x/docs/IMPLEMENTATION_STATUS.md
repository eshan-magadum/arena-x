# ARENA X implementation status

Each claim says how it was checked. Nothing here is a claim of production readiness.

## Implemented

- Accounts: public sign-up (always player), sign-in, sign-out, profile and in-game ID, password change,
  session revocation, player and administrator roles. Administrators are created only through the CLI.
- Separate administrator sign-in at `/admin/login`, backed by its own endpoint. A correct player password
  is refused there with a clear message, so player accounts cannot enter through that door.
- Tournaments: create, edit (fields lock according to lifecycle state), lifecycle transitions with
  `expectedStatus` checks, IANA time zones including `Asia/Kolkata`, publishing rules.
- Registration: solo, duo and squad entries, captain-led teams with invitations, atomic capacity with
  waitlist, manual or automatic approval, cancellation, duplicate protection.
- Team chat with history paging and live updates, restricted to team members.
- Matches: create, update state, assign entries, room credentials encrypted with AES-256-GCM, release
  at match start minus the tournament lead time, every disclosure logged.
- Results: player submission, administrator approve or reject with a reason, resubmission after rejection,
  corrections of approved results with a reason, completion blocked until every entry is verified.
- Scoring: kills times kill point plus placement points, configurable tie-breakers, competition ranking;
  finalisation refuses to award prizes across an unresolved tie inside the prize places.
- Prizes: integer minor-unit allocation from basis-point shares, unallocated remainder reported, status
  tracking (allocated, approved, fulfilled, failed, disputed). The app does not pay anyone; prize rows are
  records only and no money moves.
- Standings: live provisional standings, then a frozen snapshot at finalisation.
- Winners announcement: finalising a tournament publishes an announcement listing the top three.
- Leaderboards and player statistics built from approved results only.
- Live public pages: the leaderboard and tournament pages update over server-sent events without a reload.
  The event stream is open to guests as well as signed-in users. Updates are sent after the database commit,
  so clients refetch data that is already saved.
- Player match history at `/history`: every match the player is entered in, with result status, kills,
  placement and points. Points appear only after approval.
- Administrator analytics at `/admin/analytics`: player, team, tournament, registration, match and result
  counts, a 14-day registration series, and prize records by status. Read-only.
- Notifications with unread count and live updates over server-sent events.
- Announcements from the admin console, shown on the public home page.
- Moderation: suspend, ban and reinstate with reasons; suspension revokes live sessions at once; removal of chat messages.
- Audit log: hash-chained events, verification endpoint, secret-looking fields redacted.
- Exports: CSV for registrations, results, leaderboard, players and audit, scoped to a tournament, with
  spreadsheet formula neutralisation.
- Web app: public pages, player dashboard, profile, teams, match room view, match history, administrator
  console with analytics, responsive layout, reduced-motion handling, skip link, focus management in dialogs.

Deliberately not built:

- Manual ranking override. Rankings come only from approved results and recorded corrections, so there is
  no way to edit a position by hand.
- Money movement and payment confirmation. Prize rows and the audit log are the only transaction records.

## Tested

Automated, run with `npm test`: **57 tests, all passing, 0 skipped** on the sandbox used for this build
(31 unit, 24 integration and HTTP, 2 browser).

- Unit (31 tests): scoring and ranking, ties and tie-break order, prize allocation including values beyond the
  float-safe range, share validation, tournament transitions and schedule rules, request validation and
  mass-assignment rejection, time-zone round-trips, CSV escaping, redirect safety.
- Integration against real SQLite files: capacity and waitlist, duplicate protection, registration windows,
  room release timing and access logging, result approval and resubmission, standings, finalisation and exact
  prize totals, audit tamper and deletion detection, redaction.
- HTTP security: security headers, cookie flags, CSRF header and cross-origin refusal, strict body validation,
  admin access control, logout revocation, public payloads without room credentials, login rate limiting,
  refusal of player accounts at the administrator sign-in.
- HTTP end to end (`lifecycle-http`): public sign-up, tournament creation and publishing, registration, match
  scheduling, room refusal to outsiders and before release, release to entrants, result submission and a
  refused duplicate, approval, finalisation with exact standings and prize amounts, CSV export, announcement,
  audit verification, suspension revoking the session and blocking sign-in.
- Features (`features`): a guest receives live events without signing in; a full journey covers administrator
  sign-in, live updates, player match history, analytics and the winner announcement.
- Concurrency: ten processes and a duplicate attempt racing on one database file. No oversold places, no
  double registration.
- Browser (`tests/browser`, Chromium via Playwright, against the built bundle):
  - Tournament journey: the administrator creates a match, assigns entries, saves and publishes a room,
    closes registration, starts the tournament and sets the match live. Each of three players signs in, sees
    the released room and submits a result through the form. The administrator approves all three in the
    submissions queue, finalises standings, and sees standings and prize amounts. Also covered: CSV download,
    announcement publication and its appearance on the public page, first Tab reaching the skip link, no
    sideways scrolling at phone width on the home, tournaments, leaderboard and player match pages, and zero
    console errors across the journey.
  - Administrator sign-in and navigation: a player is refused at `/admin/login`; the administrator signs in,
    opens analytics, and every sidebar link opens its screen. The player's match history renders its empty state.

Found and fixed during testing, in order of discovery:

- Opening registration with a closing time already in the past was allowed, leaving a tournament marked open
  that nobody could join. Transitions into `registration_open` now check the clock.
- The `playerStats` query passed three parameters for two placeholders, failing every dashboard load.
- Asia/Kolkata was rejected as an invalid zone because it is missing from `Intl.supportedValuesOf`.
- The administrator's Standings tab could never show rows. It read the standings array one level too high
  (the endpoint wraps the list with its provisional flag and finalisation time). It now reads the list and
  shows whether standings are provisional or frozen.
- The player match page was 120px wider than a phone screen. A `.stack` grid had no column definition, so
  its column grew to its widest unbreakable child (the room details row). It is now `minmax(0, 1fr)`.
- Keyboard focus moved into the main region on first page load, so the first Tab skipped the "Skip to
  content" link. Focus now moves only after in-app navigation.
- Missing `.meter` style on tournament capacity bars.
- The public leaderboard and tournament pages listened for `match` and `registration` events that the server
  never sent, so they were not live. The server now broadcasts tournament changes and guests can subscribe.
- The administrator sidebar could not be reached by a generic link search: the public header also has a
  "Tournaments" link. The browser test now scopes admin navigation to the sidebar.

Screenshots reviewed earlier (phone player match page, phone leaderboard, desktop admin announcements page).
The analytics and match history screenshots are written by the browser test but have not been reviewed by eye.

## Unverified

- Web type checking after the latest changes. `@types/react` could not be installed in the build sandbox
  because the package registry was unreachable, so `npx tsc -p web/tsconfig.json --noEmit` was not run here.
  The production bundle builds (esbuild does not type check). Run `npm run typecheck` and the web config
  check on a machine with dependencies installed.
- Live updates in a real browser. The guest stream and refresh-on-change are covered at HTTP level only;
  the browser journey does not yet watch a leaderboard update in place.
- Moderation actions in the browser. Covered over HTTP, not through the UI.
- Mobile layout beyond the pages checked. Two minor cosmetic issues seen in earlier screenshots, not fixed:
  player names wrap onto two lines in the leaderboard table at phone width, and the results table on the
  player match page clips its last column behind a horizontal scroll inside its wrapper (the page itself does
  not scroll sideways).
- Keyboard use beyond the skip link: the full tab order of forms, dialogs and tables is not walked through.
- Screen reader behaviour: not tested with any assistive technology.
- Accessibility audit with an automated tool: not run.
- Behaviour on a clean machine from `npm install`. The sandbox used a pre-installed dependency tree; a fresh
  install could not be run here.
- Load behaviour: not measured.

## Blocked

- External security review, penetration test, accessibility audit by people with disabilities: not possible
  from this environment, and not done.
- Public deployment, backups, monitoring and incident response: not in scope for this build and not set up.
