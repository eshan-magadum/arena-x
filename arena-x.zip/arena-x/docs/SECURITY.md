# ARENA X security notes

This document describes what the code does and where its limits are. It is not a certification,
and nothing here has been independently reviewed.

## Controls in the code

- Passwords are hashed with scrypt. Session tokens are random and stored only as SHA-256 hashes.
- Session cookie `arenax_session` is HttpOnly and SameSite=Lax, and Secure when `NODE_ENV=production`.
  Player sessions last 14 days; administrator sessions last 8 hours.
- State-changing requests must carry the `x-arena-request: 1` header, and any Origin header must
  match the Host. This blocks cross-site form posts and most CSRF attempts.
- Every request body is validated by strict schemas. Unknown fields are rejected, which blocks
  mass assignment such as setting `role` or `status` from the client.
- Room credentials are encrypted with AES-256-GCM using a key derived from `ARENA_SECRET`. They are
  excluded from public and administrator list payloads and are returned only to entrants (or
  administrators) after the release time. Each disclosure is written to `room_access_log`.
- The audit log is hash-chained. Editing or deleting a stored event is detected by
  `verifyAuditChain`. Secret-looking detail fields are redacted before writing.
- Security headers: a Content-Security-Policy that allows only same-origin scripts and styles,
  `frame-ancestors 'none'`, `X-Frame-Options: DENY`, `nosniff`, restrictive Permissions-Policy.
- Login is rate limited per account (8 attempts per 15 minutes), and routes can declare their own fixed-window limits. Counters are held in memory.
- Spreadsheet exports prefix cell values beginning with `= + - @` or a tab with an apostrophe.
- Prize arithmetic uses integer minor units and basis points, so no money is created or lost by rounding.
- The client-side sign-in redirect (`safeInternalPath`) accepts only paths beginning with a single `/`, so `//host` and absolute URLs are ignored.

## Limits and assumptions

- **Single process.** The rate limiter and the live-event bus are held in memory. Running several
  instances would weaken rate limits and stop live updates reaching clients on other instances.
- **Key management.** If `ARENA_SECRET` changes or is lost, stored room credentials cannot be
  decrypted. There is no key rotation procedure in the code.
- **Bootstrap command.** Anyone who can run `npm run admin:create` can make any account an
  administrator and reset its password. Restrict server and shell access accordingly.
- **Not a payment system.** Prize allocations are records. Verify payments outside the app.
- **Transport.** The app does not terminate TLS. Run it behind HTTPS in any shared environment.
- **Evidence links.** Result evidence is stored as a URL. The app does not fetch or scan it.
- **Data protection.** No data retention policy, export-on-request workflow or deletion workflow for
  personal data is implemented beyond the moderation tools. Check the legal requirements in your
  jurisdiction before collecting real player data.
- **No external review.** Treat the current code as untested by any third party.

## Reporting

Report suspected vulnerabilities to the address configured as `ARENA_SUPPORT_EMAIL`, and do not
test them against systems you do not own.
