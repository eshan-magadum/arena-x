import { getRow, getRows, run, transact, type Db } from '../db/index.ts';
import { newId } from '../lib/crypto.ts';
import { nowIso, now } from '../lib/clock.ts';
import { recordAudit } from '../lib/audit.ts';
import { conflict, forbidden, notFound, unprocessable } from '../lib/errors.ts';
import { parseWith, registrationCreateSchema, registrationDecisionSchema } from '../lib/validation.ts';
import { ACTIVE_REGISTRATION_STATUSES, type RegistrationStatus, ROSTER_SIZE } from '../domain/constants.ts';
import { acceptsRegistrations } from '../domain/tournamentRules.ts';
import { requirePermission } from '../domain/permissions.ts';
import { effectiveRestriction, getUserRow, isUniqueViolation, type Viewer } from './accounts.ts';import { assertCanParticipate, getMembership } from './teams.ts';
import { getTournamentBySlug, loadTournamentRow, confirmedCount, type TournamentRow } from './tournaments.ts';
import { notifyUsers } from './notifications.ts';

/**
 * Tournament registration. Capacity, duplicate protection and roster rules are enforced inside a
 * single immediate write transaction, so concurrent requests for the last slot are serialised by
 * SQLite's write lock and cannot overfill the tournament. The database also carries unique
 * indexes as a second line of defence.
 */

interface RegistrationRow {
  id: string;
  tournament_id: string;
  kind: 'solo' | 'team';
  user_id: string | null;
  team_id: string | null;
  entrant_name: string;
  status: RegistrationStatus;
  status_reason: string | null;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface RegistrationDto {
  id: string;
  tournamentId: string;
  kind: 'solo' | 'team';
  teamId: string | null;
  entrantName: string;
  status: RegistrationStatus;
  statusReason: string | null;
  createdAt: string;
  members: Array<{ userId: string; displayName: string; inGameId?: string | null }>;
}

function loadRegistration(db: Db, id: string): RegistrationRow {
  const row = getRow<RegistrationRow>(db, 'SELECT * FROM registrations WHERE id = ?', id);
  if (!row) throw notFound('That registration could not be found.');
  return row;
}

function membersOf(db: Db, registrationId: string, includeIds: boolean) {
  return getRows<{ user_id: string; display_name_snapshot: string; in_game_id_snapshot: string }>(
    db,
    'SELECT user_id, display_name_snapshot, in_game_id_snapshot FROM registration_members WHERE registration_id = ? ORDER BY display_name_snapshot',
    registrationId,
  ).map((m) => ({
    userId: m.user_id,
    displayName: m.display_name_snapshot,
    ...(includeIds ? { inGameId: m.in_game_id_snapshot } : {}),
  }));
}

function toDto(db: Db, row: RegistrationRow, includeIds: boolean): RegistrationDto {
  return {
    id: row.id,
    tournamentId: row.tournament_id,
    kind: row.kind,
    teamId: row.team_id,
    entrantName: row.entrant_name,
    status: row.status,
    statusReason: row.status_reason,
    createdAt: row.created_at,
    members: membersOf(db, row.id, includeIds),
  };
}

function confirmedSlots(db: Db, tournamentId: string): number {
  return confirmedCount(db, tournamentId);
}

function activeParticipantNames(db: Db, tournamentId: string, userIds: string[]): string[] {
  if (userIds.length === 0) return [];
  const placeholders = userIds.map(() => '?').join(',');
  return getRows<{ display_name: string }>(
    db,
    `SELECT u.display_name FROM tournament_participants tp JOIN users u ON u.id = tp.user_id
     WHERE tp.tournament_id = ? AND tp.user_id IN (${placeholders})`,
    tournamentId,
    ...userIds,
  ).map((r) => r.display_name);
}

/* ------------------------------------------------------------------ */
/* Entering a tournament                                               */
/* ------------------------------------------------------------------ */

export function registerForTournament(db: Db, viewer: Viewer, slug: string, rawInput: unknown): RegistrationDto {
  const input = parseWith(registrationCreateSchema, rawInput ?? {});
  const tournamentSnapshot = getTournamentBySlug(db, viewer, slug);
  assertCanParticipate(db, viewer);

  let registrationId = '';
  try {
    transact(db, () => {
      const tournament = loadTournamentRow(db, tournamentSnapshot.id);
      if (!acceptsRegistrations(tournament.status, tournament.reg_closes_at, now())) {
        throw conflict('Registration is not open for this tournament right now.', 'registration_closed');
      }
      const plan = buildEntryPlan(db, viewer, tournament, input.teamId);
      const memberIds = plan.members.map((m) => m.userId);

      const duplicates = activeParticipantNames(db, tournament.id, memberIds);
      if (duplicates.length > 0) {
        throw conflict(
          `${duplicates.join(', ')} ${duplicates.length > 1 ? 'are' : 'is'} already entered in this tournament. A player can enter only once.`,
          'already_registered',
          { players: duplicates },
        );
      }

      let status: RegistrationStatus;
      if (tournament.approval_mode === 'manual') {
        status = 'pending';
      } else {
        status = confirmedSlots(db, tournament.id) < tournament.capacity ? 'confirmed' : 'waitlisted';
      }

      registrationId = newId();
      const at = nowIso();
      run(
        db,
        `INSERT INTO registrations (id, tournament_id, kind, user_id, team_id, entrant_name, status, status_reason, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?)`,
        registrationId,
        tournament.id,
        plan.kind,
        plan.kind === 'solo' ? viewer.id : null,
        plan.teamId,
        plan.entrantName,
        status,
        viewer.id,
        at,
        at,
      );
      for (const member of plan.members) {
        run(
          db,
          'INSERT INTO registration_members (registration_id, user_id, in_game_id_snapshot, display_name_snapshot) VALUES (?, ?, ?, ?)',
          registrationId,
          member.userId,
          member.inGameId,
          member.displayName,
        );
        run(
          db,
          'INSERT INTO tournament_participants (tournament_id, user_id, registration_id) VALUES (?, ?, ?)',
          tournament.id,
          member.userId,
          registrationId,
        );
      }
      const message =
        status === 'confirmed'
          ? `Your place in ${tournament.name} is confirmed.`
          : status === 'waitlisted'
            ? `${tournament.name} is full. You are on the waitlist and will be promoted automatically if a place opens.`
            : `Your registration for ${tournament.name} has been received and is awaiting admin approval.`;
      notifyUsers(db, memberIds, {
        kind: 'registration',
        title: status === 'confirmed' ? 'Registration confirmed' : status === 'waitlisted' ? 'Waitlisted' : 'Registration received',
        body: message,
        link: `/tournaments/${tournament.slug}`,
      });
      recordAudit(db, {
        actorId: viewer.id,
        actorRole: viewer.role,
        action: 'registration.created',
        entityType: 'registration',
        entityId: registrationId,
        detail: { tournamentId: tournament.id, status, kind: plan.kind },
      });
    });
  } catch (error) {
    if (isUniqueViolation(error)) {
      throw conflict('That entry already exists for this tournament.', 'already_registered');
    }
    throw error;
  }
  return toDto(db, loadRegistration(db, registrationId), true);
}

interface EntryPlan {
  kind: 'solo' | 'team';
  teamId: string | null;
  entrantName: string;
  members: Array<{ userId: string; displayName: string; inGameId: string }>;
}

/** Works out who is entering and checks every roster rule for the tournament's mode. */
function buildEntryPlan(db: Db, viewer: Viewer, tournament: TournamentRow, teamId: string | undefined): EntryPlan {
  if (tournament.mode === 'solo') {
    if (teamId) throw unprocessable('Solo tournaments are entered individually, so no team is needed.', undefined, 'team_not_applicable');
    return {
      kind: 'solo',
      teamId: null,
      entrantName: viewer.displayName,
      members: [{ userId: viewer.id, displayName: viewer.displayName, inGameId: viewer.inGameId as string }],
    };
  }
  if (!teamId) {
    throw unprocessable(`Choose a ${tournament.mode} team to enter this tournament.`, undefined, 'team_required');
  }
  const team = getRow<{ id: string; name: string; mode: string; disbanded_at: string | null }>(
    db,
    'SELECT id, name, mode, disbanded_at FROM teams WHERE id = ?',
    teamId,
  );
  if (!team || team.disbanded_at) throw notFound('That team could not be found.');
  const membership = getMembership(db, teamId, viewer.id);
  if (!membership) throw notFound('That team could not be found.');
  if (membership.role !== 'captain') {
    throw forbidden('Only the team captain can enter the team into a tournament.', 'captain_required');
  }
  if (team.mode !== tournament.mode) {
    throw unprocessable(`${team.name} is a ${team.mode} team, but this tournament is ${tournament.mode}.`, undefined, 'mode_mismatch');
  }
  const members = getRows<{ user_id: string; display_name: string; in_game_id: string | null }>(
    db,
    `SELECT tm.user_id, u.display_name, u.in_game_id FROM team_members tm
     JOIN users u ON u.id = tm.user_id WHERE tm.team_id = ? ORDER BY tm.joined_at`,
    teamId,
  );
  const rosterSize = ROSTER_SIZE[tournament.mode];
  if (members.length !== rosterSize || tournament.roster_size !== rosterSize) {
    throw unprocessable(
      `${team.name} needs exactly ${rosterSize} players to enter ${tournament.mode} tournaments. It currently has ${members.length}.`,
      { have: members.length, need: rosterSize },
      'roster_incomplete',
    );
  }
  const ineligible = members.filter((m) => {
    const row = getUserRow(db, m.user_id);
    return !m.in_game_id || !row || effectiveRestriction(row, nowIso()) !== null;
  });
  if (ineligible.length > 0) {
    throw unprocessable(
      `${ineligible.map((m) => m.display_name).join(', ')} cannot enter yet. Each player needs an in-game ID and an account in good standing.`,
      { players: ineligible.map((m) => m.display_name) },
      'roster_member_ineligible',
    );
  }
  return {
    kind: 'team',
    teamId,
    entrantName: team.name,
    members: members.map((m) => ({ userId: m.user_id, displayName: m.display_name, inGameId: m.in_game_id as string })),
  };
}

/* ------------------------------------------------------------------ */
/* Player options and withdrawals                                      */
/* ------------------------------------------------------------------ */

export function getEntryOptions(db: Db, viewer: Viewer, slug: string) {
  const tournament = getTournamentBySlug(db, viewer, slug);
  const row = loadTournamentRow(db, tournament.id);
  const open = acceptsRegistrations(row.status, row.reg_closes_at, now());
  const reasons: string[] = [];
  if (!open) reasons.push('Registration is not open right now.');
  if (!viewer.inGameId) reasons.push('Add your Free Fire MAX in-game ID in your profile first.');
  if (viewer.restriction) reasons.push('Your account is restricted from competing right now.');

  const myEntries = getRows<{ id: string; status: string; entrant_name: string; created_at: string }>(
    db,
    `SELECT DISTINCT r.id, r.status, r.entrant_name, r.created_at FROM registrations r
     JOIN registration_members rm ON rm.registration_id = r.id
     WHERE r.tournament_id = ? AND rm.user_id = ? AND r.status IN (${ACTIVE_REGISTRATION_STATUSES.map(() => '?').join(',')})`,
    row.id,
    viewer.id,
    ...ACTIVE_REGISTRATION_STATUSES,
  );

  let teams: Array<{
    id: string;
    name: string;
    memberCount: number;
    rosterSize: number;
    eligible: boolean;
    issues: string[];
  }> = [];
  if (row.mode !== 'solo') {
    const myTeams = getRows<{ id: string; name: string }>(
      db,
      `SELECT t.id, t.name FROM team_members tm JOIN teams t ON t.id = tm.team_id
       WHERE tm.user_id = ? AND tm.role = 'captain' AND t.mode = ? AND t.disbanded_at IS NULL ORDER BY t.name`,
      viewer.id,
      row.mode,
    );
    teams = myTeams.map((team) => {
      const count = getRow<{ n: number }>(db, 'SELECT COUNT(*) AS n FROM team_members WHERE team_id = ?', team.id)?.n ?? 0;
      const issues: string[] = [];
      if (count !== ROSTER_SIZE[row.mode]) issues.push(`Needs exactly ${ROSTER_SIZE[row.mode]} players (has ${count}).`);
      const incomplete = getRows<{ display_name: string; in_game_id: string | null }>(
        db,
        `SELECT u.display_name, u.in_game_id FROM team_members tm JOIN users u ON u.id = tm.user_id WHERE tm.team_id = ?`,
        team.id,
      ).filter((m) => !m.in_game_id);
      if (incomplete.length) issues.push(`${incomplete.map((m) => m.display_name).join(', ')} still needs an in-game ID.`);
      return { id: team.id, name: team.name, memberCount: count, rosterSize: ROSTER_SIZE[row.mode], eligible: issues.length === 0, issues };
    });
  }

  return {
    tournamentId: row.id,
    mode: row.mode,
    open,
    canRegister: open && reasons.length === 0 && myEntries.length === 0,
    reasons,
    myEntries: myEntries.map((e) => ({ id: e.id, status: e.status, entrantName: e.entrant_name })),
    teams,
  };
}

export function cancelRegistration(db: Db, viewer: Viewer, registrationId: string): RegistrationDto {
  return transact(db, () => {
    const reg = loadRegistration(db, registrationId);
    const tournament = loadTournamentRow(db, reg.tournament_id);
    const isAdmin = viewer.role === 'admin';
    const ownsSolo = reg.kind === 'solo' && reg.user_id === viewer.id;
    const isCaptain = reg.kind === 'team' && getMembership(db, reg.team_id as string, viewer.id)?.role === 'captain';
    if (!isAdmin && !ownsSolo && !isCaptain) {
      throw notFound('That registration could not be found.');
    }
    if (!(ACTIVE_REGISTRATION_STATUSES as readonly string[]).includes(reg.status)) {
      throw conflict('This registration is no longer active.', 'registration_inactive');
    }
    if (!isAdmin) {
      const withdrawalOpen = tournament.status === 'registration_open' && now().getTime() < Date.parse(tournament.reg_closes_at);
      if (!withdrawalOpen) {
        throw conflict('Withdrawals close when registration closes. Contact an admin if you need help.', 'withdrawal_closed');
      }
    } else if (!['draft', 'scheduled', 'registration_open', 'registration_closed'].includes(tournament.status)) {
      throw conflict('Registrations can only be cancelled before the tournament goes live.', 'withdrawal_closed');
    }
    const at = nowIso();
    const wasConfirmed = reg.status === 'confirmed';
    const memberIds = membersOf(db, reg.id, false).map((m) => m.userId);
    run(db, "UPDATE registrations SET status = 'cancelled', status_reason = ?, updated_at = ? WHERE id = ?", isAdmin ? 'Cancelled by an administrator' : 'Withdrawn by the entrant', at, reg.id);
    run(db, 'DELETE FROM tournament_participants WHERE registration_id = ?', reg.id);
    notifyUsers(db, memberIds.filter((id) => id !== viewer.id), {
      kind: 'registration',
      title: 'Registration cancelled',
      body: `${reg.entrant_name} was removed from ${tournament.name}.`,
      link: `/tournaments/${tournament.slug}`,
    });
    recordAudit(db, {
      actorId: viewer.id,
      actorRole: viewer.role,
      action: 'registration.cancelled',
      entityType: 'registration',
      entityId: reg.id,
      detail: { tournamentId: tournament.id, wasConfirmed },
    });
    if (wasConfirmed) promoteFromWaitlist(db, tournament.id);
    return toDto(db, loadRegistration(db, reg.id), isAdmin);
  });
}

/* ------------------------------------------------------------------ */
/* Admin decisions                                                     */
/* ------------------------------------------------------------------ */

export function listRegistrations(db: Db, viewer: Viewer, tournamentId: string, status?: string): RegistrationDto[] {
  requirePermission(viewer, 'registrations:decide');
  loadTournamentRow(db, tournamentId);
  const rows = status
    ? getRows<RegistrationRow>(
        db,
        'SELECT * FROM registrations WHERE tournament_id = ? AND status = ? ORDER BY created_at ASC',
        tournamentId,
        status,
      )
    : getRows<RegistrationRow>(
        db,
        "SELECT * FROM registrations WHERE tournament_id = ? AND status <> 'cancelled' ORDER BY created_at ASC",
        tournamentId,
      );
  return rows.map((row) => toDto(db, row, true));
}

/** Promotes waitlisted entries, oldest first, while confirmed places remain. */
export function promoteFromWaitlist(db: Db, tournamentId: string): string[] {
  const tournament = loadTournamentRow(db, tournamentId);
  const promoted: string[] = [];
  while (confirmedSlots(db, tournamentId) < tournament.capacity) {
    const next = getRow<RegistrationRow>(
      db,
      "SELECT * FROM registrations WHERE tournament_id = ? AND status = 'waitlisted' ORDER BY created_at ASC, id ASC LIMIT 1",
      tournamentId,
    );
    if (!next) break;
    run(db, "UPDATE registrations SET status = 'confirmed', status_reason = NULL, updated_at = ? WHERE id = ?", nowIso(), next.id);
    promoted.push(next.id);
    notifyUsers(db, membersOf(db, next.id, false).map((m) => m.userId), {
      kind: 'registration',
      title: 'Place confirmed',
      body: `A place opened up and ${next.entrant_name} is now confirmed for ${tournament.name}.`,
      link: `/tournaments/${tournament.slug}`,
    });
  }
  return promoted;
}

export function decideRegistration(db: Db, viewer: Viewer, registrationId: string, rawInput: unknown): RegistrationDto {
  requirePermission(viewer, 'registrations:decide');
  const input = parseWith(registrationDecisionSchema, rawInput);
  return transact(db, () => {
    const reg = loadRegistration(db, registrationId);
    const tournament = loadTournamentRow(db, reg.tournament_id);
    if (!['scheduled', 'registration_open', 'registration_closed'].includes(tournament.status)) {
      throw conflict('Registrations can only be decided before the tournament goes live.', 'decision_closed');
    }
    const memberIds = membersOf(db, reg.id, false).map((m) => m.userId);
    const at = nowIso();
    let next: RegistrationStatus;

    switch (input.decision) {
      case 'approve': {
        if (reg.status !== 'pending' && reg.status !== 'waitlisted') {
          throw conflict('Only pending or waitlisted entries can be approved.', 'invalid_decision');
        }
        if (confirmedSlots(db, tournament.id) >= tournament.capacity) {
          throw conflict('All places are taken. Keep this entry on the waitlist, or raise capacity first.', 'capacity_full');
        }
        next = 'confirmed';
        break;
      }
      case 'waitlist': {
        if (reg.status !== 'pending' && reg.status !== 'confirmed') {
          throw conflict('Only pending or confirmed entries can be waitlisted.', 'invalid_decision');
        }
        next = 'waitlisted';
        break;
      }
      case 'reject': {
        if (!(ACTIVE_REGISTRATION_STATUSES as readonly string[]).includes(reg.status)) {
          throw conflict('This registration is no longer active.', 'registration_inactive');
        }
        next = 'rejected';
        break;
      }
    }

    run(db, 'UPDATE registrations SET status = ?, status_reason = ?, updated_at = ? WHERE id = ?', next, input.reason ?? null, at, reg.id);
    if (next === 'rejected') {
      run(db, 'DELETE FROM tournament_participants WHERE registration_id = ?', reg.id);
    }
    const messages: Record<RegistrationStatus, string> = {
      confirmed: `Your place in ${tournament.name} is confirmed.`,
      waitlisted: `You are on the waitlist for ${tournament.name}.`,
      rejected: `Your registration for ${tournament.name} was not approved.${input.reason ? ` Reason: ${input.reason}` : ''}`,
      pending: '',
      cancelled: '',
    };
    notifyUsers(db, memberIds, {
      kind: 'registration',
      title: next === 'confirmed' ? 'Registration approved' : next === 'rejected' ? 'Registration not approved' : 'Registration update',
      body: messages[next],
      link: `/tournaments/${tournament.slug}`,
    });
    recordAudit(db, {
      actorId: viewer.id,
      actorRole: viewer.role,
      action: `registration.${input.decision}`,
      entityType: 'registration',
      entityId: reg.id,
      detail: { tournamentId: tournament.id, from: reg.status, to: next, reason: input.reason ?? null },
    });
    // Rejecting a confirmed entry frees its place. Waitlisted entries move up automatically;
    // an explicit "waitlist" decision does not, so the admin's choice is never reversed.
    if (reg.status === 'confirmed' && next === 'rejected') {
      promoteFromWaitlist(db, tournament.id);
    }
    return toDto(db, loadRegistration(db, reg.id), true);
  });
}
