import { getRow, getRows, run, transact, type Db } from '../db/index.ts';
import { newId } from '../lib/crypto.ts';
import { nowIso, now } from '../lib/clock.ts';
import { recordAudit, verifyAuditChain } from '../lib/audit.ts';
import { forbidden } from '../lib/errors.ts';
import { announcementSchema, parseWith } from '../lib/validation.ts';
import { requirePermission } from '../domain/permissions.ts';
import { ACTIVE_REGISTRATION_STATUSES } from '../domain/constants.ts';
import { playerStats, leaderboard, recentWinners, submissionsCountPending, getStandings } from './results.ts';
import { notifyUsers, unreadCount } from './notifications.ts';
import { listMyTeams } from './teams.ts';
import { prizeTotals } from './prizes.ts';
import { listPublicMatches } from './matches.ts';
import { effectiveRestriction, type Viewer, type UserRow } from './accounts.ts';
import { getTournamentBySlug, toTournamentRecord, tournamentCounts, type TournamentRow } from './tournaments.ts';

/** Public tournament page: configuration, schedule and standings. Internal counters are admin-only. */
export function tournamentDetail(db: Db, viewer: Viewer | null, slug: string) {
  const row = getTournamentBySlug(db, viewer, slug);
  const isAdmin = viewer?.role === 'admin';
  const record = toTournamentRecord(row, tournamentCounts(db, row.id));
  const standings = getStandings(db, row);
  return {
    tournament: isAdmin ? record : { ...record, pendingCount: undefined, activeRegistrationCount: undefined },
    matches: listPublicMatches(db, row.id),
    standings: {
      provisional: standings.provisional,
      finalizedAt: standings.finalizedAt,
      rows: standings.standings.map((s) => ({
        rank: s.rank,
        entrantName: s.entrantName,
        kind: s.kind,
        members: s.members,
        totalPoints: s.totalPoints,
        kills: s.kills,
        firstPlaces: s.firstPlaces,
        bestPlacement: s.bestPlacement,
        matchesPlayed: s.matchesPlayed,
        ...(isAdmin ? { pendingSubmissions: s.pendingSubmissions, registrationId: s.registrationId } : {}),
      })),
    },
  };
}

/**
 * Read models for the home page, dashboards, announcements, audit viewer and exports.
 * Everything shown here is computed from persisted records. Empty states are returned as empty
 * collections, never filled with placeholder numbers.
 */

/* ------------------------------------------------------------------ */
/* Public home                                                         */
/* ------------------------------------------------------------------ */

export function homeData(db: Db) {
  const featured = getRows<TournamentRow>(
    db,
    `SELECT * FROM tournaments WHERE status IN ('registration_open', 'scheduled', 'registration_closed', 'live')
     ORDER BY CASE status WHEN 'live' THEN 0 WHEN 'registration_open' THEN 1 WHEN 'scheduled' THEN 2 ELSE 3 END, starts_at ASC
     LIMIT 3`,
  ).map((row) => toTournamentRecord(row, counts(db, row.id)));
  return {
    featured,
    winners: recentWinners(db, 5),
    topPlayers: leaderboard(db, 'players', undefined, 5),
    announcements: listAnnouncements(db, 3),
    stats: {
      verifiedResults: Number(getRow<{ n: number }>(db, "SELECT COUNT(*) AS n FROM result_submissions WHERE status = 'approved'")?.n ?? 0),
      finishedTournaments: Number(getRow<{ n: number }>(db, "SELECT COUNT(*) AS n FROM tournaments WHERE status = 'completed'")?.n ?? 0),
    },
  };
}

function counts(db: Db, tournamentId: string) {
  const row = getRow<{ confirmed: number | null; pending: number | null }>(
    db,
    `SELECT SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending
     FROM registrations WHERE tournament_id = ?`,
    tournamentId,
  );
  return { confirmedCount: Number(row?.confirmed ?? 0) };
}

/* ------------------------------------------------------------------ */
/* Player dashboard                                                    */
/* ------------------------------------------------------------------ */

export function playerDashboard(db: Db, viewer: Viewer) {
  const active = ACTIVE_REGISTRATION_STATUSES.map(() => '?').join(',');
  const registrations = getRows<{
    id: string;
    status: string;
    entrant_name: string;
    kind: string;
    tournament_id: string;
    tournament_name: string;
    tournament_slug: string;
    tournament_status: string;
    starts_at: string;
    mode: string;
  }>(
    db,
    `SELECT DISTINCT r.id, r.status, r.entrant_name, r.kind, t.id AS tournament_id, t.name AS tournament_name,
            t.slug AS tournament_slug, t.status AS tournament_status, t.starts_at, t.mode
     FROM registrations r
     JOIN tournaments t ON t.id = r.tournament_id
     JOIN registration_members rm ON rm.registration_id = r.id
     WHERE rm.user_id = ? AND r.status IN (${active}) AND t.status NOT IN ('completed', 'cancelled')
     ORDER BY t.starts_at ASC`,
    viewer.id,
    ...ACTIVE_REGISTRATION_STATUSES,
  );
  const matches = getRows<{
    match_id: string;
    round_label: string;
    starts_at: string;
    state: string;
    tournament_name: string;
    tournament_slug: string;
  }>(
    db,
    `SELECT DISTINCT m.id AS match_id, m.round_label, m.starts_at, m.state, t.name AS tournament_name, t.slug AS tournament_slug
     FROM match_entries me
     JOIN matches m ON m.id = me.match_id
     JOIN tournaments t ON t.id = m.tournament_id
     JOIN registration_members rm ON rm.registration_id = me.registration_id
     WHERE rm.user_id = ? AND m.state IN ('scheduled', 'live', 'awaiting_results')
     ORDER BY m.starts_at ASC LIMIT 10`,
    viewer.id,
  );
  const pendingResults = getRows<{ id: string; match_id: string; kills: number; placement: number; created_at: string; round_label: string }>(
    db,
    `SELECT rs.id, rs.match_id, rs.kills, rs.placement, rs.created_at, m.round_label
     FROM result_submissions rs
     JOIN matches m ON m.id = rs.match_id
     JOIN registration_members rm ON rm.registration_id = rs.registration_id
     WHERE rm.user_id = ? AND rs.status = 'pending' ORDER BY rs.created_at DESC LIMIT 10`,
    viewer.id,
  );
  const notifications = getRows<{ id: string; kind: string; title: string; body: string; link: string | null; read_at: string | null; created_at: string }>(
    db,
    'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 6',
    viewer.id,
  );
  return {
    profile: {
      id: viewer.id,
      displayName: viewer.displayName,
      inGameId: viewer.inGameId,
      avatarKey: viewer.avatarKey,
      needsInGameId: !viewer.inGameId,
    },
    stats: playerStats(db, viewer.id),
    registrations: registrations.map((r) => ({
      id: r.id,
      status: r.status,
      entrantName: r.entrant_name,
      kind: r.kind,
      tournamentId: r.tournament_id,
      tournamentName: r.tournament_name,
      tournamentSlug: r.tournament_slug,
      tournamentStatus: r.tournament_status,
      startsAt: r.starts_at,
      mode: r.mode,
    })),
    matches: matches.map((m) => ({
      id: m.match_id,
      roundLabel: m.round_label,
      startsAt: m.starts_at,
      state: m.state,
      tournamentName: m.tournament_name,
      tournamentSlug: m.tournament_slug,
    })),
    pendingResults: pendingResults.map((p) => ({
      id: p.id,
      matchId: p.match_id,
      roundLabel: p.round_label,
      kills: p.kills,
      placement: p.placement,
      createdAt: p.created_at,
    })),
    teams: listMyTeams(db, viewer),
    notifications: {
      unread: unreadCount(db, viewer.id),
      items: notifications.map((n) => ({
        id: n.id,
        kind: n.kind,
        title: n.title,
        body: n.body,
        link: n.link,
        read: n.read_at !== null,
        createdAt: n.created_at,
      })),
    },
    announcements: listAnnouncements(db, 3),
  };
}

/* ------------------------------------------------------------------ */
/* Announcements                                                       */
/* ------------------------------------------------------------------ */

export function listAnnouncements(db: Db, limit = 10) {
  return getRows<{ id: string; title: string; body: string; created_at: string }>(
    db,
    'SELECT id, title, body, created_at FROM announcements ORDER BY created_at DESC LIMIT ?',
    Math.min(Math.max(limit, 1), 50),
  ).map((a) => ({ id: a.id, title: a.title, body: a.body, createdAt: a.created_at }));
}

export function publishAnnouncement(db: Db, actor: Viewer, rawInput: unknown) {
  requirePermission(actor, 'announcements:publish');
  const input = parseWith(announcementSchema, rawInput);
  return transact(db, () => {
    const id = newId();
    const at = nowIso();
    run(db, 'INSERT INTO announcements (id, title, body, created_by, created_at) VALUES (?, ?, ?, ?, ?)', id, input.title, input.body, actor.id, at);
    const recipients = getRows<{ id: string }>(db, "SELECT id FROM users WHERE status = 'active' OR (status = 'suspended' AND suspended_until <= ?)", at).map((r) => r.id);
    notifyUsers(db, recipients, {
      kind: 'announcement',
      title: input.title,
      body: input.body.slice(0, 240),
      link: '/',
    });
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'announcement.published',
      entityType: 'announcement',
      entityId: id,
      detail: { recipients: recipients.length },
    });
    return { id, title: input.title, body: input.body, createdAt: at };
  });
}

/* ------------------------------------------------------------------ */
/* Admin dashboard                                                     */
/* ------------------------------------------------------------------ */

export function adminDashboard(db: Db, actor: Viewer) {
  requirePermission(actor, 'tournaments:manage');
  const at = now();
  const weekAgo = new Date(at.getTime() - 7 * 24 * 60 * 60_000).toISOString();
  const users = getRow<{ total: number; restricted: number; admins: number }>(
    db,
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status <> 'active' AND NOT (status = 'suspended' AND suspended_until <= ?) THEN 1 ELSE 0 END) AS restricted,
            SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) AS admins
     FROM users`,
    at.toISOString(),
  );
  const tournamentsByStatus = getRows<{ status: string; n: number }>(db, 'SELECT status, COUNT(*) AS n FROM tournaments GROUP BY status');
  const registrations = getRow<{ last7: number; pending: number }>(
    db,
    `SELECT SUM(CASE WHEN created_at >= ? THEN 1 ELSE 0 END) AS last7,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending
     FROM registrations`,
    weekAgo,
  );
  const liveMatches = getRow<{ n: number }>(db, "SELECT COUNT(*) AS n FROM matches WHERE state IN ('live', 'awaiting_results')");
  const recentAudit = getRows<{ seq: number; action: string; entity_type: string; entity_id: string | null; created_at: string; actor_role: string | null }>(
    db,
    'SELECT seq, action, entity_type, entity_id, created_at, actor_role FROM audit_events ORDER BY seq DESC LIMIT 12',
  );
  return {
    users: {
      total: Number(users?.total ?? 0),
      restricted: Number(users?.restricted ?? 0),
      admins: Number(users?.admins ?? 0),
    },
    tournaments: Object.fromEntries(tournamentsByStatus.map((t) => [t.status, Number(t.n)])),
    registrations: {
      createdLast7Days: Number(registrations?.last7 ?? 0),
      pendingApproval: Number(registrations?.pending ?? 0),
    },
    results: { pendingReview: submissionsCountPending(db) },
    matches: { liveOrAwaitingResults: Number(liveMatches?.n ?? 0) },
    prizes: prizeTotals(db),
    recentAudit: recentAudit.map((a) => ({
      seq: a.seq,
      action: a.action,
      entityType: a.entity_type,
      entityId: a.entity_id,
      actorRole: a.actor_role,
      createdAt: a.created_at,
    })),
  };
}

/* ------------------------------------------------------------------ */
/* Audit log                                                           */
/* ------------------------------------------------------------------ */

export function listAuditEvents(db: Db, actor: Viewer, options: { before?: number; limit?: number; entityType?: string }) {
  requirePermission(actor, 'audit:read');
  const limit = Math.min(Math.max(options.limit ?? 50, 1), 200);
  const rows = options.entityType
    ? getRows<AuditDbRow>(
        db,
        'SELECT * FROM audit_events WHERE entity_type = ? AND seq < ? ORDER BY seq DESC LIMIT ?',
        options.entityType,
        options.before ?? Number.MAX_SAFE_INTEGER,
        limit,
      )
    : getRows<AuditDbRow>(db, 'SELECT * FROM audit_events WHERE seq < ? ORDER BY seq DESC LIMIT ?', options.before ?? Number.MAX_SAFE_INTEGER, limit);
  return {
    items: rows.map((r) => ({
      seq: r.seq,
      id: r.id,
      action: r.action,
      actorId: r.actor_id,
      actorRole: r.actor_role,
      entityType: r.entity_type,
      entityId: r.entity_id,
      detail: JSON.parse(r.detail) as Record<string, unknown>,
      createdAt: r.created_at,
      hash: r.hash.slice(0, 16),
    })),
    nextCursor: rows.length === limit ? rows[rows.length - 1]!.seq : null,
  };
}

interface AuditDbRow {
  seq: number;
  id: string;
  actor_id: string | null;
  actor_role: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  detail: string;
  created_at: string;
  hash: string;
}

export function verifyAudit(db: Db, actor: Viewer) {
  requirePermission(actor, 'audit:read');
  return verifyAuditChain(db);
}

/* ------------------------------------------------------------------ */
/* CSV exports                                                         */
/* ------------------------------------------------------------------ */

/**
 * Spreadsheet applications execute cells that begin with = + - @, so such values are prefixed
 * with an apostrophe. Fields containing separators or quotes are quoted per RFC 4180.
 */
export function toCsv(headers: string[], rows: Array<Array<string | number | boolean | null>>): string {
  const escape = (value: string | number | boolean | null): string => {
    if (value === null || value === undefined) return '';
    let text = String(value);
    if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  return [headers, ...rows].map((line) => line.map(escape).join(',')).join('\r\n') + '\r\n';
}

export const EXPORT_DATASETS = ['registrations', 'results', 'leaderboard', 'players', 'audit'] as const;
export type ExportDataset = (typeof EXPORT_DATASETS)[number];

export function exportDataset(db: Db, actor: Viewer, dataset: ExportDataset, tournamentId?: string): { filename: string; csv: string; rows: number } {
  requirePermission(actor, 'exports:read');
  const stamp = nowIso().slice(0, 10);
  let headers: string[];
  let rows: Array<Array<string | number | boolean | null>>;
  let filename: string;

  switch (dataset) {
    case 'registrations': {
      if (!tournamentId) throw forbidden('Choose a tournament to export registrations for.', 'tournament_required');
      headers = ['registration_id', 'entrant', 'kind', 'status', 'players', 'created_at'];
      rows = getRows<{ id: string; entrant_name: string; kind: string; status: string; created_at: string }>(
        db,
        'SELECT id, entrant_name, kind, status, created_at FROM registrations WHERE tournament_id = ? ORDER BY created_at',
        tournamentId,
      ).map((r) => {
        const players = getRows<{ display_name_snapshot: string; in_game_id_snapshot: string }>(
          db,
          'SELECT display_name_snapshot, in_game_id_snapshot FROM registration_members WHERE registration_id = ? ORDER BY display_name_snapshot',
          r.id,
        ).map((m) => `${m.display_name_snapshot} (${m.in_game_id_snapshot})`);
        return [r.id, r.entrant_name, r.kind, r.status, players.join('; '), r.created_at];
      });
      filename = `arena-x-registrations-${tournamentId.slice(0, 8)}-${stamp}.csv`;
      break;
    }
    case 'results': {
      if (!tournamentId) throw forbidden('Choose a tournament to export results for.', 'tournament_required');
      headers = ['match', 'entrant', 'kills', 'placement', 'status', 'total_points', 'submitted_at', 'reviewed_at', 'review_reason'];
      rows = getRows<{
        round_label: string;
        entrant_name: string;
        kills: number;
        placement: number;
        status: string;
        total_points: number | null;
        created_at: string;
        reviewed_at: string | null;
        review_reason: string | null;
      }>(
        db,
        `SELECT m.round_label, r.entrant_name, rs.kills, rs.placement, rs.status, rs.total_points, rs.created_at, rs.reviewed_at, rs.review_reason
         FROM result_submissions rs JOIN matches m ON m.id = rs.match_id JOIN registrations r ON r.id = rs.registration_id
         WHERE m.tournament_id = ? ORDER BY m.match_number, r.entrant_name, rs.created_at`,
        tournamentId,
      ).map((r) => [r.round_label, r.entrant_name, r.kills, r.placement, r.status, r.total_points, r.created_at, r.reviewed_at, r.review_reason]);
      filename = `arena-x-results-${tournamentId.slice(0, 8)}-${stamp}.csv`;
      break;
    }
    case 'leaderboard': {
      headers = ['rank', 'player', 'total_points', 'kills', 'wins', 'matches'];
      rows = leaderboard(db, 'players', undefined, 200).map((r) => [r.rank, r.name, r.totalPoints, r.kills, r.wins, r.matchesPlayed]);
      filename = `arena-x-player-leaderboard-${stamp}.csv`;
      break;
    }
    case 'players': {
      requirePermission(actor, 'players:moderate');
      headers = ['user_id', 'display_name', 'in_game_id', 'role', 'status', 'created_at'];
      rows = getRows<UserRow>(db, 'SELECT * FROM users ORDER BY created_at').map((u) => {
        const restriction = effectiveRestriction(u, nowIso());
        return [u.id, u.display_name, u.in_game_id, u.role, restriction?.kind ?? 'active', u.created_at];
      });
      filename = `arena-x-players-${stamp}.csv`;
      break;
    }
    case 'audit': {
      requirePermission(actor, 'audit:read');
      headers = ['seq', 'created_at', 'action', 'actor_role', 'entity_type', 'entity_id', 'detail'];
      rows = getRows<AuditDbRow>(db, 'SELECT * FROM audit_events ORDER BY seq').map((r) => [
        r.seq,
        r.created_at,
        r.action,
        r.actor_role,
        r.entity_type,
        r.entity_id,
        r.detail,
      ]);
      filename = `arena-x-audit-${stamp}.csv`;
      break;
    }
  }

  recordAudit(db, {
    actorId: actor.id,
    actorRole: actor.role,
    action: 'export.generated',
    entityType: 'export',
    entityId: null,
    detail: { dataset, tournamentId: tournamentId ?? null, rows: rows.length },
  });
  return { filename, csv: toCsv(headers, rows), rows: rows.length };
}
