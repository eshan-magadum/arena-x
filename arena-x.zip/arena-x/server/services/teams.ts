import { getRow, getRows, run, transact, type Db } from '../db/index.ts';
import { newId } from '../lib/crypto.ts';
import { nowIso } from '../lib/clock.ts';
import { recordAudit } from '../lib/audit.ts';
import { conflict, forbidden, notFound, unprocessable } from '../lib/errors.ts';
import { publishToUsers } from '../lib/events.ts';
import { parseWith, teamCreateSchema, inviteSchema, chatMessageSchema, emailSchema } from '../lib/validation.ts';
import { ROSTER_SIZE, TEAM_MODES, type TeamMode } from '../domain/constants.ts';
import { requirePermission } from '../domain/permissions.ts';
import { effectiveRestriction, getUserRow, isUniqueViolation, type Viewer } from './accounts.ts';
import { notifyUsers } from './notifications.ts';

/**
 * Team workflows: creation, invitations, roster management, captain permissions and team chat.
 * Every function re-derives membership from the database. Client-supplied team IDs are only
 * lookup keys, never proof of membership.
 */

interface TeamRow {
  id: string;
  name: string;
  mode: TeamMode;
  captain_id: string;
  created_at: string;
  disbanded_at: string | null;
}

interface MembershipRow {
  team_id: string;
  user_id: string;
  mode: TeamMode;
  role: 'captain' | 'member';
}

function getTeamRow(db: Db, teamId: string): TeamRow {
  const row = getRow<TeamRow>(db, 'SELECT * FROM teams WHERE id = ?', teamId);
  if (!row || row.disbanded_at) throw notFound('That team could not be found.');
  return row;
}

export function getMembership(db: Db, teamId: string, userId: string): MembershipRow | undefined {
  return getRow<MembershipRow>(db, 'SELECT * FROM team_members WHERE team_id = ? AND user_id = ?', teamId, userId);
}

/** Throws a 404 for non-members so team existence is not revealed to outsiders. */
export function requireMember(db: Db, teamId: string, userId: string): MembershipRow {
  const membership = getMembership(db, teamId, userId);
  if (!membership) throw notFound('That team could not be found.');
  return membership;
}

function requireCaptain(db: Db, teamId: string, userId: string): MembershipRow {
  const membership = requireMember(db, teamId, userId);
  if (membership.role !== 'captain') {
    throw forbidden('Only the team captain can do that.', 'captain_required');
  }
  return membership;
}

/** Restriction and profile requirements that apply to anyone joining or creating a team. */
export function assertCanParticipate(db: Db, viewer: Viewer): void {
  if (viewer.restriction) {
    throw forbidden('Your account is restricted, so you cannot take part in competitions right now.', 'account_restricted');
  }
  const row = getUserRow(db, viewer.id);
  if (!row || effectiveRestriction(row, nowIso())) {
    throw forbidden('Your account is restricted, so you cannot take part in competitions right now.', 'account_restricted');
  }
  if (!viewer.inGameId) {
    throw forbidden('Add your Free Fire MAX in-game ID in your profile before joining or forming a team.', 'in_game_id_required');
  }
}

function memberCount(db: Db, teamId: string): number {
  return getRow<{ n: number }>(db, 'SELECT COUNT(*) AS n FROM team_members WHERE team_id = ?', teamId)?.n ?? 0;
}

function userHasTeamInMode(db: Db, userId: string, mode: TeamMode): boolean {
  return Boolean(getRow(db, 'SELECT team_id FROM team_members WHERE user_id = ? AND mode = ?', userId, mode));
}

/* ------------------------------------------------------------------ */
/* Creation and reads                                                  */
/* ------------------------------------------------------------------ */

export function createTeam(db: Db, viewer: Viewer, rawInput: unknown): string {
  const input = parseWith(teamCreateSchema, rawInput);
  assertCanParticipate(db, viewer);
  if (!TEAM_MODES.includes(input.mode)) {
    throw unprocessable('Teams are available for duo and squad modes only.');
  }
  const mode = input.mode as TeamMode;
  if (userHasTeamInMode(db, viewer.id, mode)) {
    throw conflict('You already belong to a ' + mode + ' team. Leave it before creating another.', 'already_in_team');
  }
  if (getRow(db, 'SELECT id FROM teams WHERE name = ? COLLATE NOCASE', input.name)) {
    throw conflict('That team name is already taken.', 'team_name_taken');
  }
  const id = newId();
  const at = nowIso();
  try {
    transact(db, () => {
      run(db, 'INSERT INTO teams (id, name, mode, captain_id, created_at) VALUES (?, ?, ?, ?, ?)', id, input.name, mode, viewer.id, at);
      run(
        db,
        'INSERT INTO team_members (team_id, user_id, mode, role, joined_at) VALUES (?, ?, ?, ?, ?)',
        id,
        viewer.id,
        mode,
        'captain',
        at,
      );
      recordAudit(db, {
        actorId: viewer.id,
        actorRole: viewer.role,
        action: 'team.created',
        entityType: 'team',
        entityId: id,
        detail: { mode },
      });
    });
  } catch (error) {
    if (isUniqueViolation(error)) throw conflict('That team name is already taken.', 'team_name_taken');
    throw error;
  }
  return id;
}

export interface TeamDetail {
  id: string;
  name: string;
  mode: TeamMode;
  rosterSize: number;
  createdAt: string;
  viewer: { isMember: boolean; isCaptain: boolean };
  members: Array<{
    userId: string;
    displayName: string;
    avatarKey: string;
    role: 'captain' | 'member';
    inGameId: string | null;
  }>;
  invitations: Array<{ id: string; inviteeName: string; createdAt: string }>;
  registrations: Array<{ id: string; tournamentId: string; tournamentName: string; status: string; createdAt: string }>;
}

export function getTeamDetail(db: Db, teamId: string, viewer: Viewer | null): TeamDetail {
  const team = getTeamRow(db, teamId);
  const membership = viewer ? getMembership(db, teamId, viewer.id) : undefined;
  const isMember = Boolean(membership);
  const isCaptain = membership?.role === 'captain';
  const canSeeIds = isMember || viewer?.role === 'admin';
  const members = getRows<{
    user_id: string;
    display_name: string;
    avatar_key: string;
    role: 'captain' | 'member';
    in_game_id: string | null;
  }>(
    db,
    `SELECT tm.user_id, u.display_name, u.avatar_key, tm.role, u.in_game_id
     FROM team_members tm JOIN users u ON u.id = tm.user_id
     WHERE tm.team_id = ? ORDER BY CASE tm.role WHEN 'captain' THEN 0 ELSE 1 END, tm.joined_at`,
    teamId,
  );
  const invitations = isCaptain
    ? getRows<{ id: string; display_name: string; created_at: string }>(
        db,
        `SELECT ti.id, u.display_name, ti.created_at FROM team_invitations ti
         JOIN users u ON u.id = ti.invitee_id
         WHERE ti.team_id = ? AND ti.status = 'pending' ORDER BY ti.created_at`,
        teamId,
      )
    : [];
  const registrations = canSeeIds
    ? getRows<{ id: string; tournament_id: string; tournament_name: string; status: string; created_at: string }>(
        db,
        `SELECT r.id, r.tournament_id, t.name AS tournament_name, r.status, r.created_at
         FROM registrations r JOIN tournaments t ON t.id = r.tournament_id
         WHERE r.team_id = ? ORDER BY r.created_at DESC LIMIT 25`,
        teamId,
      )
    : [];
  return {
    id: team.id,
    name: team.name,
    mode: team.mode,
    rosterSize: ROSTER_SIZE[team.mode],
    createdAt: team.created_at,
    viewer: { isMember, isCaptain: Boolean(isCaptain) },
    members: members.map((m) => ({
      userId: m.user_id,
      displayName: m.display_name,
      avatarKey: m.avatar_key,
      role: m.role,
      inGameId: canSeeIds ? m.in_game_id : null,
    })),
    invitations: invitations.map((i) => ({ id: i.id, inviteeName: i.display_name, createdAt: i.created_at })),
    registrations: registrations.map((r) => ({
      id: r.id,
      tournamentId: r.tournament_id,
      tournamentName: r.tournament_name,
      status: r.status,
      createdAt: r.created_at,
    })),
  };
}

export interface MyTeamsResult {
  teams: Array<{ id: string; name: string; mode: TeamMode; role: 'captain' | 'member'; memberCount: number; rosterSize: number }>;
  invitations: Array<{ id: string; teamId: string; teamName: string; mode: TeamMode; inviterName: string; createdAt: string }>;
}

export function listMyTeams(db: Db, viewer: Viewer): MyTeamsResult {
  const teams = getRows<{ id: string; name: string; mode: TeamMode; role: 'captain' | 'member' }>(
    db,
    `SELECT t.id, t.name, t.mode, tm.role FROM team_members tm
     JOIN teams t ON t.id = tm.team_id
     WHERE tm.user_id = ? AND t.disbanded_at IS NULL ORDER BY t.name`,
    viewer.id,
  );
  const invitations = getRows<{ id: string; team_id: string; team_name: string; mode: TeamMode; inviter_name: string; created_at: string }>(
    db,
    `SELECT ti.id, ti.team_id, t.name AS team_name, t.mode, u.display_name AS inviter_name, ti.created_at
     FROM team_invitations ti
     JOIN teams t ON t.id = ti.team_id
     JOIN users u ON u.id = ti.inviter_id
     WHERE ti.invitee_id = ? AND ti.status = 'pending' AND t.disbanded_at IS NULL
     ORDER BY ti.created_at DESC`,
    viewer.id,
  );
  return {
    teams: teams.map((t) => ({
      id: t.id,
      name: t.name,
      mode: t.mode,
      role: t.role,
      memberCount: memberCount(db, t.id),
      rosterSize: ROSTER_SIZE[t.mode],
    })),
    invitations: invitations.map((i) => ({
      id: i.id,
      teamId: i.team_id,
      teamName: i.team_name,
      mode: i.mode,
      inviterName: i.inviter_name,
      createdAt: i.created_at,
    })),
  };
}

/* ------------------------------------------------------------------ */
/* Invitations                                                         */
/* ------------------------------------------------------------------ */

export function inviteToTeam(db: Db, viewer: Viewer, teamId: string, rawInput: unknown): string {
  const input = parseWith(inviteSchema, rawInput);
  const team = getTeamRow(db, teamId);
  requireCaptain(db, teamId, viewer.id);
  const invitee = getRow<{
    id: string;
    display_name: string;
    in_game_id: string | null;
    status: 'active' | 'suspended' | 'banned';
    suspended_until: string | null;
    status_reason: string | null;
  }>(
    db,
    'SELECT id, display_name, in_game_id, status, suspended_until, status_reason FROM users WHERE email = ?',
    emailSchema.parse(input.email),
  );
  if (!invitee) {
    throw notFound('No ARENA X player uses that email address.');
  }
  if (invitee.id === viewer.id) {
    throw unprocessable('You are already on this team.');
  }
  if (!invitee.in_game_id) {
    throw unprocessable('That player has not added a Free Fire MAX in-game ID yet, so they cannot join a team.', undefined, 'invitee_not_ready');
  }
  if (effectiveRestriction(invitee, nowIso())) {
    throw unprocessable('That player cannot be invited right now.', undefined, 'invitee_restricted');
  }
  if (memberCount(db, teamId) >= ROSTER_SIZE[team.mode]) {
    throw conflict(`This ${team.mode} roster is already full (${ROSTER_SIZE[team.mode]} players).`, 'team_full');
  }
  if (userHasTeamInMode(db, invitee.id, team.mode)) {
    throw conflict('That player already belongs to a ' + team.mode + ' team.', 'invitee_already_in_team');
  }
  const pending = getRow(
    db,
    "SELECT id FROM team_invitations WHERE team_id = ? AND invitee_id = ? AND status = 'pending'",
    teamId,
    invitee.id,
  );
  if (pending) throw conflict('An invitation to that player is already waiting for a reply.', 'invite_pending');

  const id = newId();
  const at = nowIso();
  try {
    transact(db, () => {
      run(
        db,
        "INSERT INTO team_invitations (id, team_id, invitee_id, inviter_id, status, created_at) VALUES (?, ?, ?, ?, 'pending', ?)",
        id,
        teamId,
        invitee.id,
        viewer.id,
        at,
      );
      recordAudit(db, {
        actorId: viewer.id,
        actorRole: viewer.role,
        action: 'team.invited',
        entityType: 'team',
        entityId: teamId,
        detail: { inviteeId: invitee.id },
      });
      notifyUsers(db, [invitee.id], {
        kind: 'team_invite',
        title: 'Team invitation',
        body: `You have been invited to join ${team.name}.`,
        link: '/dashboard',
      });
    });
  } catch (error) {
    if (isUniqueViolation(error)) throw conflict('An invitation to that player is already waiting for a reply.', 'invite_pending');
    throw error;
  }
  return id;
}

export function respondToInvitation(db: Db, viewer: Viewer, inviteId: string, accept: boolean): void {
  const invite = getRow<{ id: string; team_id: string; invitee_id: string; inviter_id: string; status: string }>(
    db,
    'SELECT * FROM team_invitations WHERE id = ?',
    inviteId,
  );
  if (!invite || invite.invitee_id !== viewer.id) throw notFound('That invitation could not be found.');
  if (invite.status !== 'pending') {
    throw conflict('This invitation has already been answered.', 'invite_closed');
  }
  const team = getTeamRow(db, invite.team_id);
  const at = nowIso();
  if (!accept) {
    transact(db, () => {
      run(db, "UPDATE team_invitations SET status = 'declined', resolved_at = ? WHERE id = ?", at, inviteId);
      notifyUsers(db, [invite.inviter_id], {
        kind: 'team_invite',
        title: 'Invitation declined',
        body: `${viewer.displayName} declined the invitation to ${team.name}.`,
        link: `/teams/${team.id}`,
      });
    });
    return;
  }
  assertCanParticipate(db, viewer);
  if (memberCount(db, team.id) >= ROSTER_SIZE[team.mode]) {
    throw conflict('This roster is already full, so the invitation can no longer be accepted.', 'team_full');
  }
  if (userHasTeamInMode(db, viewer.id, team.mode)) {
    throw conflict('You already belong to a ' + team.mode + ' team. Leave it before joining another.', 'already_in_team');
  }
  transact(db, () => {
    run(
      db,
      'INSERT INTO team_members (team_id, user_id, mode, role, joined_at) VALUES (?, ?, ?, ?, ?)',
      team.id,
      viewer.id,
      team.mode,
      'member',
      at,
    );
    run(db, "UPDATE team_invitations SET status = 'accepted', resolved_at = ? WHERE id = ?", at, inviteId);
    // Accepting one team of this mode makes any other pending invitations for the same mode stale.
    run(
      db,
      `UPDATE team_invitations SET status = 'revoked', resolved_at = ?
       WHERE invitee_id = ? AND status = 'pending' AND id <> ?
         AND team_id IN (SELECT id FROM teams WHERE mode = ?)`,
      at,
      viewer.id,
      inviteId,
      team.mode,
    );
    recordAudit(db, {
      actorId: viewer.id,
      actorRole: viewer.role,
      action: 'team.joined',
      entityType: 'team',
      entityId: team.id,
    });
    notifyUsers(db, [invite.inviter_id], {
      kind: 'team_invite',
      title: 'New teammate',
      body: `${viewer.displayName} joined ${team.name}.`,
      link: `/teams/${team.id}`,
    });
    publishToUsers(
      getRows<{ user_id: string }>(db, 'SELECT user_id FROM team_members WHERE team_id = ?', team.id).map((r) => r.user_id),
      { type: 'team', data: { teamId: team.id } },
    );
  });
}

export function revokeInvitation(db: Db, viewer: Viewer, inviteId: string): void {
  const invite = getRow<{ id: string; team_id: string; invitee_id: string; status: string }>(
    db,
    'SELECT * FROM team_invitations WHERE id = ?',
    inviteId,
  );
  if (!invite) throw notFound('That invitation could not be found.');
  requireCaptain(db, invite.team_id, viewer.id);
  if (invite.status !== 'pending') throw conflict('This invitation has already been answered.', 'invite_closed');
  run(db, "UPDATE team_invitations SET status = 'revoked', resolved_at = ? WHERE id = ?", nowIso(), inviteId);
}

/* ------------------------------------------------------------------ */
/* Roster management                                                   */
/* ------------------------------------------------------------------ */

function assertRosterUnlocked(db: Db, teamId: string): void {
  const locked = getRow(
    db,
    `SELECT r.id FROM registrations r JOIN tournaments t ON t.id = r.tournament_id
     WHERE r.team_id = ? AND r.status IN ('pending', 'confirmed', 'waitlisted') AND t.status NOT IN ('completed', 'cancelled')`,
    teamId,
  );
  if (locked) {
    throw conflict(
      'This team is entered in a tournament, so its roster is locked. Withdraw the registration first.',
      'team_locked',
    );
  }
}

export function removeMember(db: Db, viewer: Viewer, teamId: string, userId: string): void {
  const actorMembership = requireMember(db, teamId, viewer.id);
  const targetMembership = getMembership(db, teamId, userId);
  if (!targetMembership) throw notFound('That player is not on this team.');
  const leavingSelf = userId === viewer.id;
  if (!leavingSelf && actorMembership.role !== 'captain') {
    throw forbidden('Only the team captain can remove players.', 'captain_required');
  }
  if (targetMembership.role === 'captain') {
    throw conflict('The captain cannot leave or be removed. Disband the team instead.', 'captain_protected');
  }
  assertRosterUnlocked(db, teamId);
  const team = getTeamRow(db, teamId);
  transact(db, () => {
    run(db, 'DELETE FROM team_members WHERE team_id = ? AND user_id = ?', teamId, userId);
    recordAudit(db, {
      actorId: viewer.id,
      actorRole: viewer.role,
      action: leavingSelf ? 'team.left' : 'team.member_removed',
      entityType: 'team',
      entityId: teamId,
      detail: { userId },
    });
    notifyUsers(db, [userId], {
      kind: 'team_roster',
      title: leavingSelf ? 'Left team' : 'Removed from team',
      body: leavingSelf ? `You left ${team.name}.` : `You were removed from ${team.name}.`,
      link: '/teams',
    });
  });
}

export function disbandTeam(db: Db, viewer: Viewer, teamId: string): void {
  requireCaptain(db, teamId, viewer.id);
  assertRosterUnlocked(db, teamId);
  const team = getTeamRow(db, teamId);
  const members = getRows<{ user_id: string }>(db, 'SELECT user_id FROM team_members WHERE team_id = ?', teamId).map(
    (r) => r.user_id,
  );
  transact(db, () => {
    run(db, "UPDATE team_invitations SET status = 'revoked', resolved_at = ? WHERE team_id = ? AND status = 'pending'", nowIso(), teamId);
    // The team row is kept for history (registrations reference it); membership and chat access end here.
    run(db, 'DELETE FROM team_members WHERE team_id = ?', teamId);
    run(db, 'UPDATE teams SET disbanded_at = ? WHERE id = ?', nowIso(), teamId);
    recordAudit(db, {
      actorId: viewer.id,
      actorRole: viewer.role,
      action: 'team.disbanded',
      entityType: 'team',
      entityId: teamId,
    });
    notifyUsers(db, members.filter((id) => id !== viewer.id), {
      kind: 'team_roster',
      title: 'Team disbanded',
      body: `${team.name} has been disbanded by its captain.`,
      link: '/teams',
    });
  });
}

/* ------------------------------------------------------------------ */
/* Team chat                                                           */
/* ------------------------------------------------------------------ */

export interface ChatMessageDto {
  id: number;
  authorId: string;
  authorName: string;
  body: string;
  createdAt: string;
  removed: boolean;
}

export function listTeamMessages(
  db: Db,
  viewer: Viewer,
  teamId: string,
  options: { before?: number; limit?: number },
): { messages: ChatMessageDto[]; nextCursor: number | null } {
  requireMember(db, teamId, viewer.id);
  const limit = Math.min(Math.max(options.limit ?? 40, 1), 100);
  const rows = options.before
    ? getRows<{ id: number; author_id: string; display_name: string; body: string; created_at: string; hidden_at: string | null }>(
        db,
        `SELECT m.id, m.author_id, u.display_name, m.body, m.created_at, m.hidden_at
         FROM team_messages m JOIN users u ON u.id = m.author_id
         WHERE m.team_id = ? AND m.id < ? ORDER BY m.id DESC LIMIT ?`,
        teamId,
        options.before,
        limit + 1,
      )
    : getRows<{ id: number; author_id: string; display_name: string; body: string; created_at: string; hidden_at: string | null }>(
        db,
        `SELECT m.id, m.author_id, u.display_name, m.body, m.created_at, m.hidden_at
         FROM team_messages m JOIN users u ON u.id = m.author_id
         WHERE m.team_id = ? ORDER BY m.id DESC LIMIT ?`,
        teamId,
        limit + 1,
      );
  const hasMore = rows.length > limit;
  const page = rows.slice(0, limit).reverse();
  return {
    messages: page.map((r) => ({
      id: r.id,
      authorId: r.author_id,
      authorName: r.display_name,
      body: r.hidden_at ? '[Message removed by a moderator]' : r.body,
      createdAt: r.created_at,
      removed: r.hidden_at !== null,
    })),
    nextCursor: hasMore ? page[0]?.id ?? null : null,
  };
}

export function postTeamMessage(db: Db, viewer: Viewer, teamId: string, rawInput: unknown): ChatMessageDto {
  const input = parseWith(chatMessageSchema, rawInput);
  if (viewer.restriction) {
    throw forbidden('Your account is restricted, so you cannot post messages right now.', 'account_restricted');
  }
  requireMember(db, teamId, viewer.id);
  getTeamRow(db, teamId);
  const at = nowIso();
  const { lastInsertRowid } = run(
    db,
    'INSERT INTO team_messages (team_id, author_id, body, created_at) VALUES (?, ?, ?, ?)',
    teamId,
    viewer.id,
    input.body,
    at,
  );
  const id = lastInsertRowid;
  const memberIds = getRows<{ user_id: string }>(db, 'SELECT user_id FROM team_members WHERE team_id = ?', teamId).map((r) => r.user_id);
  publishToUsers(memberIds, { type: 'chat', data: { teamId } });
  return { id, authorId: viewer.id, authorName: viewer.displayName, body: input.body, createdAt: at, removed: false };
}

export function moderateTeamMessage(db: Db, actor: Viewer, messageId: number): void {
  requirePermission(actor, 'chat:moderate');
  const message = getRow<{ id: number; team_id: string }>(db, 'SELECT id, team_id FROM team_messages WHERE id = ?', messageId);
  if (!message) throw notFound('That message could not be found.');
  transact(db, () => {
    run(db, 'UPDATE team_messages SET hidden_at = ?, hidden_by = ? WHERE id = ?', nowIso(), actor.id, messageId);
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'chat.message_removed',
      entityType: 'team',
      entityId: message.team_id,
      detail: { messageId },
    });
  });
}
