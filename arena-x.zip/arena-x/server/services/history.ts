import { getRow, getRows, type Db } from '../db/index.ts';
import type { Viewer } from './accounts.ts';

/**
 * A player's match history: every match they were entered in, with the best result they hold for it.
 * An approved result is preferred over a pending or rejected one; a pending claim shows as pending,
 * never as a score. Read-only; nothing here changes standings.
 */

export interface MatchHistoryItem {
  matchId: string;
  roundLabel: string;
  startsAt: string;
  matchState: string;
  tournamentName: string;
  tournamentSlug: string;
  entrantName: string;
  resultStatus: 'none' | 'pending' | 'approved' | 'rejected';
  kills: number | null;
  placement: number | null;
  totalPoints: number | null;
}

interface EntryRow {
  match_id: string;
  round_label: string;
  starts_at: string;
  state: string;
  tournament_name: string;
  slug: string;
  registration_id: string;
  entrant_name: string;
}

interface SubmissionRow {
  status: 'pending' | 'approved' | 'rejected' | 'superseded';
  kills: number;
  placement: number;
  total_points: number | null;
}

export function playerMatchHistory(db: Db, viewer: Viewer, limit = 100): MatchHistoryItem[] {
  const entries = getRows<EntryRow>(
    db,
    `SELECT m.id AS match_id, m.round_label, m.starts_at, m.state,
            t.name AS tournament_name, t.slug, r.id AS registration_id, r.entrant_name
       FROM registration_members rm
       JOIN registrations r ON r.id = rm.registration_id
       JOIN match_entries me ON me.registration_id = r.id
       JOIN matches m ON m.id = me.match_id
       JOIN tournaments t ON t.id = m.tournament_id
      WHERE rm.user_id = ?
      ORDER BY m.starts_at DESC
      LIMIT ?`,
    viewer.id,
    limit,
  );

  return entries.map((entry) => {
    const approved = getRow<SubmissionRow>(
      db,
      `SELECT status, kills, placement, total_points FROM result_submissions
        WHERE match_id = ? AND registration_id = ? AND status = 'approved'
        ORDER BY rowid DESC LIMIT 1`,
      entry.match_id,
      entry.registration_id,
    );
    const latest = approved ?? getRow<SubmissionRow>(
      db,
      `SELECT status, kills, placement, total_points FROM result_submissions
        WHERE match_id = ? AND registration_id = ? AND status IN ('pending', 'rejected')
        ORDER BY rowid DESC LIMIT 1`,
      entry.match_id,
      entry.registration_id,
    );
    const resultStatus: MatchHistoryItem['resultStatus'] = !latest
      ? 'none'
      : latest.status === 'approved'
        ? 'approved'
        : latest.status === 'pending'
          ? 'pending'
          : 'rejected';
    return {
      matchId: entry.match_id,
      roundLabel: entry.round_label,
      startsAt: entry.starts_at,
      matchState: entry.state,
      tournamentName: entry.tournament_name,
      tournamentSlug: entry.slug,
      entrantName: entry.entrant_name,
      resultStatus,
      kills: latest ? latest.kills : null,
      placement: latest ? latest.placement : null,
      totalPoints: approved ? approved.total_points : null,
    };
  });
}
