import { getRow, getRows, run, transact, type Db } from '../db/index.ts';
import { dummyPasswordHash, hashPassword, newId, newSessionToken, sha256Hex, verifyPassword } from '../lib/crypto.ts';
import { addMinutesIso, nowIso } from '../lib/clock.ts';
import { recordAudit } from '../lib/audit.ts';
import { conflict, forbidden, notFound, unauthorized } from '../lib/errors.ts';
import {
  parseWith,
  registerSchema,
  profileUpdateSchema,
  passwordChangeSchema,
  moderationSchema,
  loginSchema,
  emailSchema,
} from '../lib/validation.ts';
import { publishToUsers } from '../lib/events.ts';
import { ACTIVE_REGISTRATION_STATUSES, type AvatarKey } from '../domain/constants.ts';
import type { Role } from '../domain/permissions.ts';
import { requirePermission } from '../domain/permissions.ts';

/**
 * Account lifecycle: registration, login, sessions, profile, password and moderation effects.
 * Passwords are hashed with scrypt; session tokens are random 256-bit values and only their
 * SHA-256 digest is stored, so a database leak does not yield usable session cookies.
 */

export interface SessionPolicy {
  playerDays: number;
  adminHours: number;
}

export const DEFAULT_SESSION_POLICY: SessionPolicy = { playerDays: 14, adminHours: 8 };

export interface UserRow {
  id: string;
  email: string;
  password_hash: string;
  display_name: string;
  in_game_id: string | null;
  avatar_key: string;
  role: Role;
  status: 'active' | 'suspended' | 'banned';
  suspended_until: string | null;
  status_reason: string | null;
  created_at: string;
  updated_at: string;
}

export interface Restriction {
  kind: 'suspended' | 'banned';
  until: string | null;
  reason: string | null;
}

/** The signed-in user as the rest of the application sees it. Never includes the password hash. */
export interface Viewer {
  id: string;
  email: string;
  displayName: string;
  inGameId: string | null;
  avatarKey: AvatarKey;
  role: Role;
  restriction: Restriction | null;
  createdAt: string;
}

export function effectiveRestriction(row: Pick<UserRow, 'status' | 'suspended_until' | 'status_reason'>, at: string): Restriction | null {
  if (row.status === 'banned') {
    return { kind: 'banned', until: null, reason: row.status_reason };
  }
  if (row.status === 'suspended' && row.suspended_until && row.suspended_until > at) {
    return { kind: 'suspended', until: row.suspended_until, reason: row.status_reason };
  }
  return null;
}

export function toViewer(row: UserRow, at: string = nowIso()): Viewer {
  return {
    id: row.id,
    email: row.email,
    displayName: row.display_name,
    inGameId: row.in_game_id,
    avatarKey: row.avatar_key as AvatarKey,
    role: row.role,
    restriction: effectiveRestriction(row, at),
    createdAt: row.created_at,
  };
}

export function isUniqueViolation(error: unknown): boolean {
  return error instanceof Error && /UNIQUE constraint failed/.test(error.message);
}

export async function registerAccount(db: Db, rawInput: unknown): Promise<Viewer> {
  const input = parseWith(registerSchema, rawInput);
  if (getRow(db, 'SELECT id FROM users WHERE email = ?', input.email)) {
    throw conflict('An account already exists for that email. Try signing in instead.', 'email_taken');
  }
  if (input.inGameId && getRow(db, 'SELECT id FROM users WHERE in_game_id = ?', input.inGameId)) {
    throw conflict('That in-game ID is already linked to another ARENA X account.', 'in_game_id_taken');
  }
  const passwordHash = await hashPassword(input.password);
  const id = newId();
  const at = nowIso();
  try {
    transact(db, () => {
      run(
        db,
        `INSERT INTO users (id, email, password_hash, display_name, in_game_id, avatar_key, role, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 'player', 'active', ?, ?)`,
        id,
        input.email,
        passwordHash,
        input.displayName,
        input.inGameId ?? null,
        input.avatarKey ?? 'bolt',
        at,
        at,
      );
      recordAudit(db, {
        actorId: id,
        actorRole: 'player',
        action: 'account.registered',
        entityType: 'user',
        entityId: id,
        detail: { hasInGameId: Boolean(input.inGameId) },
      });
    });
  } catch (error) {
    if (isUniqueViolation(error)) {
      throw conflict('That email or in-game ID is already in use.', 'account_conflict');
    }
    throw error;
  }
  return toViewer(getUserRowOrThrow(db, id));
}

export function getUserRow(db: Db, userId: string): UserRow | undefined {
  return getRow<UserRow>(db, 'SELECT * FROM users WHERE id = ?', userId);
}

function getUserRowOrThrow(db: Db, userId: string): UserRow {
  const row = getUserRow(db, userId);
  if (!row) throw notFound('Account not found.');
  return row;
}

export interface IssuedSession {
  token: string;
  expiresAt: string;
  viewer: Viewer;
}

export function createSession(db: Db, userId: string, role: Role, policy: SessionPolicy = DEFAULT_SESSION_POLICY): IssuedSession {
  const token = newSessionToken();
  const createdAt = nowIso();
  const expiresAt =
    role === 'admin'
      ? addMinutesIso(createdAt, policy.adminHours * 60)
      : addMinutesIso(createdAt, policy.playerDays * 24 * 60);
  run(
    db,
    'INSERT INTO sessions (token_hash, user_id, role_at_login, created_at, expires_at) VALUES (?, ?, ?, ?, ?)',
    sha256Hex(token),
    userId,
    role,
    createdAt,
    expiresAt,
  );
  return { token, expiresAt, viewer: toViewer(getUserRowOrThrow(db, userId), createdAt) };
}

export async function authenticate(db: Db, rawInput: unknown, policy?: SessionPolicy): Promise<IssuedSession> {
  const input = parseWith(loginSchema, rawInput);
  const row = getRow<UserRow>(db, 'SELECT * FROM users WHERE email = ?', emailSchema.parse(input.email));
  // Always run one password verification so response timing does not reveal which emails exist.
  const storedHash = row?.password_hash ?? (await dummyPasswordHash());
  const valid = await verifyPassword(input.password, storedHash);
  if (!row || !valid) {
    throw unauthorized('Email or password is not right.');
  }
  const restriction = effectiveRestriction(row, nowIso());
  if (restriction?.kind === 'banned') {
    throw forbidden('This account has been banned. Contact support if you believe this is a mistake.', 'account_banned');
  }
  if (restriction?.kind === 'suspended') {
    throw forbidden('This account is suspended until ' + restriction.until + '.', 'account_suspended');
  }
  const issued = transact(db, () => {
    // Opportunistic cleanup of expired sessions keeps the table small.
    run(db, 'DELETE FROM sessions WHERE expires_at <= ?', nowIso());
    const session = createSession(db, row.id, row.role, policy);
    recordAudit(db, {
      actorId: row.id,
      actorRole: row.role,
      action: 'auth.login',
      entityType: 'user',
      entityId: row.id,
    });
    return session;
  });
  return issued;
}

/** Looks up the viewer for a raw session token. Returns null for unknown or expired tokens. */
export function resolveSession(db: Db, rawToken: string | undefined | null): Viewer | null {
  if (!rawToken) return null;
  const row = getRow<UserRow & { expires_at: string }>(
    db,
    `SELECT u.*, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token_hash = ? AND s.expires_at > ?`,
    sha256Hex(rawToken),
    nowIso(),
  );
  if (!row) return null;
  return toViewer(row);
}

export function destroySession(db: Db, rawToken: string | undefined | null): void {
  if (!rawToken) return;
  run(db, 'DELETE FROM sessions WHERE token_hash = ?', sha256Hex(rawToken));
}

export function revokeAllSessions(db: Db, userId: string, keepTokenHash?: string): number {
  if (keepTokenHash) {
    return run(db, 'DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?', userId, keepTokenHash).changes;
  }
  return run(db, 'DELETE FROM sessions WHERE user_id = ?', userId).changes;
}

export async function changePassword(db: Db, viewer: Viewer, rawInput: unknown, currentToken: string): Promise<void> {
  const input = parseWith(passwordChangeSchema, rawInput);
  const row = getUserRowOrThrow(db, viewer.id);
  if (!(await verifyPassword(input.currentPassword, row.password_hash))) {
    throw unauthorized('Your current password is not right.');
  }
  const newHash = await hashPassword(input.newPassword);
  transact(db, () => {
    run(db, 'UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?', newHash, nowIso(), viewer.id);
    // Sign out every other device; keep the session that performed the change.
    revokeAllSessions(db, viewer.id, sha256Hex(currentToken));
    recordAudit(db, {
      actorId: viewer.id,
      actorRole: viewer.role,
      action: 'account.password_changed',
      entityType: 'user',
      entityId: viewer.id,
    });
  });
}

/**
 * Profile edits. The in-game ID cannot change while the player holds an active registration,
 * because rosters and room assignments refer to it. Changes are audited.
 */
export function updateProfile(db: Db, viewer: Viewer, rawInput: unknown): Viewer {
  const input = parseWith(profileUpdateSchema, rawInput);
  const row = getUserRowOrThrow(db, viewer.id);
  const nextInGameId = input.inGameId === undefined ? row.in_game_id : input.inGameId;
  if (nextInGameId !== row.in_game_id && nextInGameId !== null) {
    const taken = getRow(db, 'SELECT id FROM users WHERE in_game_id = ? AND id <> ?', nextInGameId, viewer.id);
    if (taken) throw conflict('That in-game ID is already linked to another ARENA X account.', 'in_game_id_taken');
  }
  if (nextInGameId !== row.in_game_id && hasActiveRegistration(db, viewer.id)) {
    throw conflict(
      'Your in-game ID is locked while you are entered in a tournament. Withdraw first, or ask an admin for help.',
      'in_game_id_locked',
    );
  }
  if (nextInGameId === null && row.in_game_id !== null && hasActiveRegistration(db, viewer.id)) {
    throw conflict('Your in-game ID cannot be removed while you are entered in a tournament.', 'in_game_id_locked');
  }
  transact(db, () => {
    run(
      db,
      'UPDATE users SET display_name = ?, in_game_id = ?, avatar_key = ?, updated_at = ? WHERE id = ?',
      input.displayName ?? row.display_name,
      nextInGameId,
      input.avatarKey ?? row.avatar_key,
      nowIso(),
      viewer.id,
    );
    recordAudit(db, {
      actorId: viewer.id,
      actorRole: viewer.role,
      action: 'profile.updated',
      entityType: 'user',
      entityId: viewer.id,
      detail: {
        changedDisplayName: input.displayName !== undefined && input.displayName !== row.display_name,
        changedInGameId: nextInGameId !== row.in_game_id,
      },
    });
  });
  return toViewer(getUserRowOrThrow(db, viewer.id));
}

export function hasActiveRegistration(db: Db, userId: string): boolean {
  const statuses = ACTIVE_REGISTRATION_STATUSES.map(() => '?').join(',');
  const row = getRow(
    db,
    `SELECT 1 AS found
     FROM tournament_participants tp
     JOIN registrations r ON r.id = tp.registration_id
     JOIN tournaments t ON t.id = tp.tournament_id
     WHERE tp.user_id = ? AND r.status IN (${statuses}) AND t.status NOT IN ('completed', 'cancelled')`,
    userId,
    ...ACTIVE_REGISTRATION_STATUSES,
  );
  return Boolean(row);
}

export interface PlayerSummary {
  id: string;
  displayName: string;
  avatarKey: AvatarKey;
  createdAt: string;
}

export function getPublicPlayer(db: Db, userId: string): PlayerSummary {
  const row = getUserRow(db, userId);
  if (!row) throw notFound('That player profile does not exist.');
  return {
    id: row.id,
    displayName: row.display_name,
    avatarKey: row.avatar_key as AvatarKey,
    createdAt: row.created_at,
  };
}

/* ------------------------------------------------------------------ */
/* Moderation                                                          */
/* ------------------------------------------------------------------ */

export interface ModerationResult {
  userId: string;
  status: string;
  suspendedUntil: string | null;
}

export function moderatePlayer(db: Db, actor: Viewer, targetId: string, rawInput: unknown): ModerationResult {
  requirePermission(actor, 'players:moderate');
  const input = parseWith(moderationSchema, rawInput);
  if (targetId === actor.id) {
    throw forbidden('You cannot moderate your own account.', 'self_moderation');
  }
  const target = getUserRowOrThrow(db, targetId);
  if (target.role === 'admin') {
    throw forbidden('Administrator accounts cannot be suspended or banned from the portal.', 'admin_protected');
  }
  const at = nowIso();
  return transact(db, () => {
    let status: 'active' | 'suspended' | 'banned';
    let until: string | null = null;
    if (input.action === 'suspend') {
      status = 'suspended';
      until = addMinutesIso(at, (input.days ?? 7) * 24 * 60);
    } else if (input.action === 'ban') {
      status = 'banned';
    } else {
      status = 'active';
    }
    run(
      db,
      'UPDATE users SET status = ?, suspended_until = ?, status_reason = ?, updated_at = ? WHERE id = ?',
      status,
      until,
      input.action === 'reinstate' ? null : input.reason,
      at,
      targetId,
    );
    run(
      db,
      'INSERT INTO moderation_actions (id, user_id, admin_id, action, reason, until, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      newId(),
      targetId,
      actor.id,
      input.action,
      input.reason,
      until,
      at,
    );
    if (status !== 'active') {
      // Remove live sessions so the restriction takes effect immediately, not only on next login.
      revokeAllSessions(db, targetId);
    }
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: `player.${input.action}`,
      entityType: 'user',
      entityId: targetId,
      detail: { reason: input.reason, until },
    });
    const notice =
      input.action === 'reinstate'
        ? 'Your ARENA X account has been reinstated.'
        : `Your ARENA X account has been ${input.action === 'ban' ? 'banned' : 'suspended'}.`;
    run(
      db,
      'INSERT INTO notifications (id, user_id, kind, title, body, link, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      newId(),
      targetId,
      'moderation',
      input.action === 'reinstate' ? 'Account reinstated' : 'Account restriction',
      notice + (input.reason ? ` Reason: ${input.reason}` : ''),
      null,
      at,
    );
    publishToUsers([targetId], { type: 'notification', data: { kind: 'moderation' } });
    return { userId: targetId, status, suspendedUntil: until };
  });
}

export interface PlayerListItem {
  id: string;
  email: string;
  displayName: string;
  inGameId: string | null;
  role: Role;
  status: string;
  suspendedUntil: string | null;
  createdAt: string;
}

export function listPlayers(db: Db, actor: Viewer, filters: { q?: string; limit?: number; offset?: number }): PlayerListItem[] {
  requirePermission(actor, 'players:moderate');
  const limit = Math.min(Math.max(filters.limit ?? 25, 1), 100);
  const offset = Math.max(filters.offset ?? 0, 0);
  const q = filters.q?.trim();
  const rows = q
    ? getRows<UserRow>(
        db,
        `SELECT * FROM users
         WHERE email LIKE ? OR display_name LIKE ? OR in_game_id = ?
         ORDER BY created_at DESC LIMIT ? OFFSET ?`,
        `%${q}%`,
        `%${q}%`,
        q,
        limit,
        offset,
      )
    : getRows<UserRow>(db, 'SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?', limit, offset);
  return rows.map(toPlayerListItem);
}

function toPlayerListItem(row: UserRow): PlayerListItem {
  return {
    id: row.id,
    email: row.email,
    displayName: row.display_name,
    inGameId: row.in_game_id,
    role: row.role,
    status: effectiveRestriction(row, nowIso())?.kind ?? 'active',
    suspendedUntil: row.suspended_until,
    createdAt: row.created_at,
  };
}

export function getPlayerForAdmin(db: Db, actor: Viewer, userId: string) {
  requirePermission(actor, 'players:moderate');
  const row = getUserRowOrThrow(db, userId);
  const moderation = getRows<{
    id: string;
    action: string;
    reason: string;
    until: string | null;
    created_at: string;
    admin_id: string;
  }>(db, 'SELECT * FROM moderation_actions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', userId);
  const registrations = getRows<{
    id: string;
    tournament_name: string;
    tournament_id: string;
    status: string;
    created_at: string;
    kind: string;
  }>(
    db,
    `SELECT r.id, r.status, r.created_at, r.kind, t.name AS tournament_name, t.id AS tournament_id
     FROM tournament_participants tp
     JOIN registrations r ON r.id = tp.registration_id
     JOIN tournaments t ON t.id = tp.tournament_id
     WHERE tp.user_id = ?
     UNION ALL
     SELECT r.id, r.status, r.created_at, r.kind, t.name AS tournament_name, t.id AS tournament_id
     FROM registration_members rm
     JOIN registrations r ON r.id = rm.registration_id
     JOIN tournaments t ON t.id = r.tournament_id
     WHERE rm.user_id = ? AND r.status NOT IN ('pending', 'confirmed', 'waitlisted')
     ORDER BY created_at DESC LIMIT 50`,
    userId,
    userId,
  );
  return {
    player: { ...toPlayerListItem(row), updatedAt: row.updated_at },
    moderation: moderation.map((m) => ({
      id: m.id,
      action: m.action,
      reason: m.reason,
      until: m.until,
      createdAt: m.created_at,
      adminId: m.admin_id,
    })),
    registrations: registrations.map((r) => ({
      id: r.id,
      tournamentId: r.tournament_id,
      tournamentName: r.tournament_name,
      status: r.status,
      kind: r.kind,
      createdAt: r.created_at,
    })),
  };
}
