import { getRow, getRows, run, transact, type Db } from '../db/index.ts';
import { decryptSecret, encryptSecret, newId } from '../lib/crypto.ts';
import { addMinutesIso, nowIso } from '../lib/clock.ts';
import { recordAudit } from '../lib/audit.ts';
import { conflict, forbidden, notFound, unprocessable } from '../lib/errors.ts';
import { notifyUsers } from './notifications.ts';
import {
  matchCreateSchema,
  matchEntriesSchema,
  matchUpdateSchema,
  parseWith,
  roomSchema,
} from '../lib/validation.ts';
import { requirePermission } from '../domain/permissions.ts';
import { loadTournamentRow, type TournamentRow } from './tournaments.ts';
import type { Viewer } from './accounts.ts';
import type { MatchState } from '../domain/constants.ts';

/**
 * Match scheduling, entry assignment and private room credentials.
 *
 * Room credentials are the most sensitive data in a match. They are encrypted at rest and only
 * leave the server through getRoomForViewer(), which checks, in order:
 *   1. the viewer is an entry in this match or an administrator,
 *   2. credentials have been published by an administrator,
 *   3. the release time (match start minus the tournament's lead time) has passed.
 * Every disclosure is written to room_access_log.
 */

const MATCH_TRANSITIONS: Record<MatchState, readonly MatchState[]> = {
  scheduled: ['live', 'cancelled'],
  live: ['awaiting_results', 'cancelled'],
  awaiting_results: ['live', 'completed', 'cancelled'],
  completed: [],
  cancelled: [],
};

interface MatchRow {
  id: string;
  tournament_id: string;
  match_number: number;
  round_label: string;
  starts_at: string;
  state: MatchState;
  created_at: string;
  updated_at: string;
}

function loadMatch(db: Db, matchId: string): MatchRow {
  const row = getRow<MatchRow>(db, 'SELECT * FROM matches WHERE id = ?', matchId);
  if (!row) throw notFound('That match could not be found.');
  return row;
}

function releaseTimeFor(match: MatchRow, tournament: TournamentRow): string {
  return addMinutesIso(match.starts_at, -tournament.room_lead_minutes);
}

function entryCount(db: Db, matchId: string): number {
  return getRow<{ n: number }>(db, 'SELECT COUNT(*) AS n FROM match_entries WHERE match_id = ?', matchId)?.n ?? 0;
}

function memberIdsForMatch(db: Db, matchId: string): string[] {
  return getRows<{ user_id: string }>(
    db,
    `SELECT DISTINCT rm.user_id FROM match_entries me
     JOIN registration_members rm ON rm.registration_id = me.registration_id
     WHERE me.match_id = ?`,
    matchId,
  ).map((r) => r.user_id);
}

/** Whether the viewer is a member of any registration entered in this match. */
export function isMatchParticipant(db: Db, matchId: string, userId: string): boolean {
  return Boolean(
    getRow(
      db,
      `SELECT 1 AS ok FROM match_entries me
       JOIN registration_members rm ON rm.registration_id = me.registration_id
       WHERE me.match_id = ? AND rm.user_id = ? LIMIT 1`,
      matchId,
      userId,
    ),
  );
}

/* ------------------------------------------------------------------ */
/* Scheduling                                                          */
/* ------------------------------------------------------------------ */

export function createMatch(db: Db, actor: Viewer, tournamentId: string, rawInput: unknown) {
  requirePermission(actor, 'matches:manage');
  const input = parseWith(matchCreateSchema, rawInput);
  return transact(db, () => {
    const tournament = loadTournamentRow(db, tournamentId);
    if (!['scheduled', 'registration_open', 'registration_closed', 'live'].includes(tournament.status)) {
      throw conflict('Matches can only be scheduled while a tournament is scheduled, open or live.', 'tournament_state');
    }
    const next = getRow<{ n: number }>(db, 'SELECT COALESCE(MAX(match_number), 0) + 1 AS n FROM matches WHERE tournament_id = ?', tournamentId)?.n ?? 1;
    const id = newId();
    const at = nowIso();
    run(
      db,
      'INSERT INTO matches (id, tournament_id, match_number, round_label, starts_at, state, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      id,
      tournamentId,
      next,
      input.roundLabel,
      input.startsAt,
      'scheduled',
      at,
      at,
    );
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'match.created',
      entityType: 'match',
      entityId: id,
      detail: { tournamentId, matchNumber: next, startsAt: input.startsAt },
    });
    return id;
  });
}

export function updateMatch(db: Db, actor: Viewer, matchId: string, rawInput: unknown): void {
  requirePermission(actor, 'matches:manage');
  const input = parseWith(matchUpdateSchema, rawInput);
  transact(db, () => {
    const match = loadMatch(db, matchId);
    const tournament = loadTournamentRow(db, match.tournament_id);
    if (match.state === 'completed' || match.state === 'cancelled') {
      throw conflict('Finished or cancelled matches cannot be changed.', 'match_closed');
    }
    if (input.state && input.state !== match.state) {
      if (!MATCH_TRANSITIONS[match.state].includes(input.state)) {
        throw conflict(`A match cannot move from ${match.state.replace('_', ' ')} to ${input.state.replace('_', ' ')}.`, 'match_transition');
      }
      if (input.state === 'live' && tournament.status !== 'live') {
        throw conflict('Start the tournament before starting a match.', 'tournament_not_live');
      }
      if (input.state === 'completed' && !allEntriesVerified(db, matchId)) {
        throw conflict('Every entry must have a verified result before the match can be completed.', 'results_pending');
      }
    }
    const at = nowIso();
    const scheduleChanged = input.startsAt !== undefined && input.startsAt !== match.starts_at;
    run(
      db,
      'UPDATE matches SET round_label = ?, starts_at = ?, state = ?, updated_at = ? WHERE id = ?',
      input.roundLabel ?? match.round_label,
      input.startsAt ?? match.starts_at,
      input.state ?? match.state,
      at,
      matchId,
    );
    if (scheduleChanged && roomPublished(db, matchId)) {
      notifyUsers(db, memberIdsForMatch(db, matchId), {
        kind: 'schedule',
        title: 'Match schedule updated',
        body: `${match.round_label} has moved. Check the new start time on your tournament page.`,
        link: `/tournaments/${tournament.slug}`,
      });
    }
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'match.updated',
      entityType: 'match',
      entityId: matchId,
      detail: { from: match.state, to: input.state ?? match.state, scheduleChanged },
    });
  });
}

export function assignEntries(db: Db, actor: Viewer, matchId: string, rawInput: unknown): void {
  requirePermission(actor, 'matches:manage');
  const input = parseWith(matchEntriesSchema, rawInput);
  transact(db, () => {
    const match = loadMatch(db, matchId);
    const tournament = loadTournamentRow(db, match.tournament_id);
    if (match.state !== 'scheduled') {
      throw conflict('Entries can only be changed before a match starts.', 'match_started');
    }
    if (input.registrationIds.length > tournament.max_entries_per_match) {
      throw unprocessable(`A match can hold at most ${tournament.max_entries_per_match} entries.`, undefined, 'lobby_full');
    }
    const placeholders = input.registrationIds.map(() => '?').join(',');
    const valid = getRows<{ id: string }>(
      db,
      `SELECT id FROM registrations WHERE tournament_id = ? AND status = 'confirmed' AND id IN (${placeholders})`,
      tournament.id,
      ...input.registrationIds,
    );
    if (valid.length !== input.registrationIds.length) {
      throw unprocessable('Every entry must be a confirmed registration in this tournament.', undefined, 'entry_not_confirmed');
    }
    const previous = memberIdsForMatch(db, matchId);
    run(db, 'DELETE FROM match_entries WHERE match_id = ?', matchId);
    for (const registrationId of input.registrationIds) {
      run(db, 'INSERT INTO match_entries (match_id, registration_id) VALUES (?, ?)', matchId, registrationId);
    }
    const current = memberIdsForMatch(db, matchId);
    const added = current.filter((id) => !previous.includes(id));
    const removed = previous.filter((id) => !current.includes(id));
    notifyUsers(db, added, {
      kind: 'schedule',
      title: 'Match assigned',
      body: `You have been placed in ${match.round_label} starting ${match.starts_at}.`,
      link: `/tournaments/${tournament.slug}`,
    });
    notifyUsers(db, removed, {
      kind: 'schedule',
      title: 'Match assignment changed',
      body: `You are no longer in ${match.round_label}.`,
      link: `/tournaments/${tournament.slug}`,
    });
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'match.entries_assigned',
      entityType: 'match',
      entityId: matchId,
      detail: { entries: input.registrationIds.length },
    });
  });
}

function allEntriesVerified(db: Db, matchId: string): boolean {
  const pending = getRow<{ n: number }>(
    db,
    `SELECT COUNT(*) AS n FROM match_entries me
     WHERE me.match_id = ? AND NOT EXISTS (
       SELECT 1 FROM result_submissions rs
       WHERE rs.match_id = me.match_id AND rs.registration_id = me.registration_id AND rs.status = 'approved')`,
    matchId,
  );
  return (pending?.n ?? 0) === 0 && entryCount(db, matchId) > 0;
}

/* ------------------------------------------------------------------ */
/* Room credentials                                                    */
/* ------------------------------------------------------------------ */

function roomPublished(db: Db, matchId: string): boolean {
  return Boolean(getRow(db, 'SELECT match_id FROM room_credentials WHERE match_id = ? AND published_at IS NOT NULL', matchId));
}

export function setRoom(db: Db, actor: Viewer, matchId: string, rawInput: unknown, secret: string): void {
  requirePermission(actor, 'rooms:manage');
  const input = parseWith(roomSchema, rawInput);
  transact(db, () => {
    const match = loadMatch(db, matchId);
    const existing = getRow<{ published_at: string | null }>(db, 'SELECT published_at FROM room_credentials WHERE match_id = ?', matchId);
    const at = nowIso();
    const roomIdEnc = encryptSecret(input.roomId, secret);
    const passwordEnc = input.roomPassword ? encryptSecret(input.roomPassword, secret) : null;
    if (existing) {
      run(
        db,
        'UPDATE room_credentials SET room_id_enc = ?, room_password_enc = ?, updated_at = ?, updated_by = ? WHERE match_id = ?',
        roomIdEnc,
        passwordEnc,
        at,
        actor.id,
        matchId,
      );
    } else {
      run(
        db,
        'INSERT INTO room_credentials (match_id, room_id_enc, room_password_enc, published_at, updated_at, updated_by) VALUES (?, ?, ?, NULL, ?, ?)',
        matchId,
        roomIdEnc,
        passwordEnc,
        at,
        actor.id,
      );
    }
    if (existing?.published_at) {
      const tournament = loadTournamentRow(db, match.tournament_id);
      notifyUsers(db, memberIdsForMatch(db, matchId), {
        kind: 'room',
        title: 'Room details updated',
        body: `The room details for ${match.round_label} have changed. Open the match to see the new details.`,
        link: `/tournaments/${tournament.slug}`,
      });
    }
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'room.updated',
      entityType: 'match',
      entityId: matchId,
      detail: { hasPassword: Boolean(input.roomPassword) },
    });
  });
}

export function publishRoom(db: Db, actor: Viewer, matchId: string): string {
  requirePermission(actor, 'rooms:manage');
  return transact(db, () => {
    const match = loadMatch(db, matchId);
    const tournament = loadTournamentRow(db, match.tournament_id);
    const room = getRow<{ match_id: string; published_at: string | null }>(
      db,
      'SELECT match_id, published_at FROM room_credentials WHERE match_id = ?',
      matchId,
    );
    if (!room) throw conflict('Enter the room details before publishing them.', 'room_not_set');
    if (match.state === 'completed' || match.state === 'cancelled') {
      throw conflict('Room details cannot be published for a finished or cancelled match.', 'match_closed');
    }
    const at = nowIso();
    run(db, 'UPDATE room_credentials SET published_at = COALESCE(published_at, ?), updated_at = ?, updated_by = ? WHERE match_id = ?', at, at, actor.id, matchId);
    const releaseAt = releaseTimeFor(match, tournament);
    notifyUsers(db, memberIdsForMatch(db, matchId), {
      kind: 'room',
      title: 'Room details published',
      body: `Room details for ${match.round_label} are available from ${releaseAt}.`,
      link: `/tournaments/${tournament.slug}`,
    });
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'room.published',
      entityType: 'match',
      entityId: matchId,
      detail: { releaseAt },
    });
    return releaseAt;
  });
}

export type RoomView =
  | { state: 'not_set' }
  | { state: 'not_published' }
  | { state: 'not_released'; releaseAt: string }
  | { state: 'available'; roomId: string; roomPassword: string | null; releaseAt: string };

/**
 * The only path that returns decrypted room credentials. Participants are verified against the
 * database for this specific match; the admin path is audited as an administrative disclosure.
 */
export function getRoomForViewer(db: Db, viewer: Viewer, matchId: string, secret: string): RoomView {
  const match = loadMatch(db, matchId);
  const tournament = loadTournamentRow(db, match.tournament_id);
  const isAdmin = viewer.role === 'admin';
  if (!isAdmin && !isMatchParticipant(db, matchId, viewer.id)) {
    throw forbidden('Room details are only shared with players entered in this match.', 'not_a_participant');
  }
  const room = getRow<{ room_id_enc: string; room_password_enc: string | null; published_at: string | null }>(
    db,
    'SELECT room_id_enc, room_password_enc, published_at FROM room_credentials WHERE match_id = ?',
    matchId,
  );
  if (!room) return { state: 'not_set' };
  if (!isAdmin && !room.published_at) return { state: 'not_published' };
  const releaseAt = releaseTimeFor(match, tournament);
  if (!isAdmin && nowIso() < releaseAt) return { state: 'not_released', releaseAt };

  run(
    db,
    'INSERT INTO room_access_log (match_id, user_id, via, accessed_at) VALUES (?, ?, ?, ?)',
    matchId,
    viewer.id,
    isAdmin ? 'admin' : 'participant',
    nowIso(),
  );
  return {
    state: 'available',
    roomId: decryptSecret(room.room_id_enc, secret),
    roomPassword: room.room_password_enc ? decryptSecret(room.room_password_enc, secret) : null,
    releaseAt,
  };
}

/* ------------------------------------------------------------------ */
/* Read models (never include room credentials)                        */
/* ------------------------------------------------------------------ */

export function listPublicMatches(db: Db, tournamentId: string) {
  return getRows<{ id: string; match_number: number; round_label: string; starts_at: string; state: string; entries: number }>(
    db,
    `SELECT m.id, m.match_number, m.round_label, m.starts_at, m.state,
            (SELECT COUNT(*) FROM match_entries me WHERE me.match_id = m.id) AS entries
     FROM matches m WHERE m.tournament_id = ? ORDER BY m.starts_at, m.match_number`,
    tournamentId,
  ).map((m) => ({
    id: m.id,
    matchNumber: m.match_number,
    roundLabel: m.round_label,
    startsAt: m.starts_at,
    state: m.state,
    entries: m.entries,
  }));
}

export function listAdminMatches(db: Db, actor: Viewer, tournamentId: string) {
  requirePermission(actor, 'matches:manage');
  loadTournamentRow(db, tournamentId);
  return getRows<MatchRow & { room_present: number; room_published: number }>(
    db,
    `SELECT m.*,
            (SELECT COUNT(*) FROM room_credentials rc WHERE rc.match_id = m.id) AS room_present,
            (SELECT COUNT(*) FROM room_credentials rc WHERE rc.match_id = m.id AND rc.published_at IS NOT NULL) AS room_published
     FROM matches m WHERE m.tournament_id = ? ORDER BY m.starts_at, m.match_number`,
    tournamentId,
  ).map((m) => ({
    id: m.id,
    matchNumber: m.match_number,
    roundLabel: m.round_label,
    startsAt: m.starts_at,
    state: m.state,
    roomStatus: m.room_published ? 'published' : m.room_present ? 'draft' : 'not_set',
    entries: getRows<{ registration_id: string; entrant_name: string; status: string }>(
      db,
      `SELECT me.registration_id, r.entrant_name, r.status FROM match_entries me
       JOIN registrations r ON r.id = me.registration_id WHERE me.match_id = ? ORDER BY r.entrant_name`,
      m.id,
    ).map((e) => ({ registrationId: e.registration_id, entrantName: e.entrant_name, status: e.status })),
  }));
}

/** Participant-facing match view. Room state is summarised, the credentials are not included. */
export function getMatchForParticipant(db: Db, viewer: Viewer, matchId: string) {
  const match = loadMatch(db, matchId);
  const tournament = loadTournamentRow(db, match.tournament_id);
  if (viewer.role !== 'admin' && !isMatchParticipant(db, matchId, viewer.id)) {
    throw notFound('That match could not be found.');
  }
  const room = getRow<{ published_at: string | null }>(db, 'SELECT published_at FROM room_credentials WHERE match_id = ?', matchId);
  const releaseAt = releaseTimeFor(match, tournament);
  const submissions = getRows<{ id: string; registration_id: string; status: string; kills: number; placement: number; total_points: number | null; review_reason: string | null; created_at: string }>(
    db,
    `SELECT rs.id, rs.registration_id, rs.status, rs.kills, rs.placement, rs.total_points, rs.review_reason, rs.created_at
     FROM result_submissions rs
     JOIN registration_members rm ON rm.registration_id = rs.registration_id
     WHERE rs.match_id = ? AND rm.user_id = ? ORDER BY rs.created_at DESC`,
    matchId,
    viewer.id,
  );
  return {
    id: match.id,
    tournamentId: match.tournament_id,
    tournamentName: tournament.name,
    tournamentSlug: tournament.slug,
    matchNumber: match.match_number,
    roundLabel: match.round_label,
    startsAt: match.starts_at,
    state: match.state,
    room: {
      status: !room ? 'not_set' : room.published_at ? (nowIso() < releaseAt ? 'not_released' : 'available') : 'not_published',
      releaseAt,
    },
    submissions: submissions.map((s) => ({
      id: s.id,
      registrationId: s.registration_id,
      status: s.status,
      kills: s.kills,
      placement: s.placement,
      totalPoints: s.total_points,
      reviewReason: s.review_reason,
      createdAt: s.created_at,
    })),
    canSubmitResult: match.state === 'live' || match.state === 'awaiting_results',
  };
}

export function matchTournamentId(db: Db, matchId: string): string {
  return loadMatch(db, matchId).tournament_id;
}

export function getMatchRow(db: Db, matchId: string): MatchRow {
  return loadMatch(db, matchId);
}

export { entryCount, allEntriesVerified, memberIdsForMatch, roomPublished };
