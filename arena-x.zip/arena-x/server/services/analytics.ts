import { getRow, getRows, type Db } from '../db/index.ts';
import { nowIso } from '../lib/clock.ts';
import { requirePermission } from '../domain/permissions.ts';
import type { Viewer } from './accounts.ts';

/**
 * Platform analytics for administrators. Every figure is a live count or sum over the database, so the
 * dashboard cannot show numbers that the stored data does not support. Days are UTC calendar days.
 */

export interface AnalyticsSnapshot {
  generatedAt: string;
  players: { total: number; active: number; suspended: number; banned: number; newLast14Days: number };
  teams: { total: number };
  tournaments: { byStatus: Record<string, number> };
  registrations: { byStatus: Record<string, number>; newLast14Days: number };
  matches: { byState: Record<string, number> };
  results: { byStatus: Record<string, number> };
  prizes: { byStatus: Record<string, { count: number; amountMinor: number }>; currency: string | null };
  dailyRegistrations: Array<{ day: string; count: number }>;
}

function countsByKey(rows: Array<{ key: string; n: number }>): Record<string, number> {
  return Object.fromEntries(rows.map((r) => [r.key, r.n]));
}

function lastFourteenDays(now: Date): string[] {
  const days: string[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 86_400_000);
    days.push(d.toISOString().slice(0, 10));
  }
  return days;
}

export function platformAnalytics(db: Db, actor: Viewer): AnalyticsSnapshot {
  requirePermission(actor, 'analytics:view');
  const now = new Date(nowIso());
  const since = `${lastFourteenDays(now)[0]}T00:00:00.000Z`;

  const playerRow = getRow<{ total: number; active: number; suspended: number; banned: number }>(
    db,
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active,
            SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) AS suspended,
            SUM(CASE WHEN status = 'banned' THEN 1 ELSE 0 END) AS banned
       FROM users WHERE role = 'player'`,
  )!;
  const newPlayers = getRow<{ n: number }>(db, "SELECT COUNT(*) AS n FROM users WHERE role = 'player' AND created_at >= ?", since)!;
  const teams = getRow<{ n: number }>(db, 'SELECT COUNT(*) AS n FROM teams')!;

  const tournaments = countsByKey(getRows<{ key: string; n: number }>(db, 'SELECT status AS key, COUNT(*) AS n FROM tournaments GROUP BY status'));
  const registrations = countsByKey(getRows<{ key: string; n: number }>(db, 'SELECT status AS key, COUNT(*) AS n FROM registrations GROUP BY status'));
  const newRegistrations = getRow<{ n: number }>(db, 'SELECT COUNT(*) AS n FROM registrations WHERE created_at >= ?', since)!;
  const matches = countsByKey(getRows<{ key: string; n: number }>(db, 'SELECT state AS key, COUNT(*) AS n FROM matches GROUP BY state'));
  const results = countsByKey(getRows<{ key: string; n: number }>(db, 'SELECT status AS key, COUNT(*) AS n FROM result_submissions GROUP BY status'));

  const prizeRows = getRows<{ status: string; n: number; amount: number; currency: string }>(
    db,
    'SELECT status, COUNT(*) AS n, COALESCE(SUM(amount_minor), 0) AS amount, MAX(currency) AS currency FROM prize_awards GROUP BY status',
  );
  const prizeByStatus: AnalyticsSnapshot['prizes']['byStatus'] = {};
  for (const row of prizeRows) prizeByStatus[row.status] = { count: row.n, amountMinor: row.amount };
  const currency = prizeRows[0]?.currency ?? null;

  const dailyRows = getRows<{ day: string; n: number }>(
    db,
    `SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS n FROM registrations
      WHERE created_at >= ? GROUP BY day`,
    since,
  );
  const dailyMap = new Map(dailyRows.map((r) => [r.day, r.n]));

  return {
    generatedAt: now.toISOString(),
    players: {
      total: playerRow.total,
      active: playerRow.active ?? 0,
      suspended: playerRow.suspended ?? 0,
      banned: playerRow.banned ?? 0,
      newLast14Days: newPlayers.n,
    },
    teams: { total: teams.n },
    tournaments: { byStatus: tournaments },
    registrations: { byStatus: registrations, newLast14Days: newRegistrations.n },
    matches: { byState: matches },
    results: { byStatus: results },
    prizes: { byStatus: prizeByStatus, currency },
    dailyRegistrations: lastFourteenDays(now).map((day) => ({ day, count: dailyMap.get(day) ?? 0 })),
  };
}
