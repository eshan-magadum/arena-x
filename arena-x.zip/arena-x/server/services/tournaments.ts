import { getRow, getRows, run, transact, type Db } from '../db/index.ts';
import { newId } from '../lib/crypto.ts';
import { nowIso } from '../lib/clock.ts';
import { recordAudit } from '../lib/audit.ts';
import { conflict, notFound, unprocessable } from '../lib/errors.ts';
import { parseWith, tournamentCreateSchema, tournamentUpdateSchema, transitionSchema } from '../lib/validation.ts';
import {
  ACTIVE_REGISTRATION_STATUSES,
  DEFAULT_TIEBREAK_ORDER,
  ROSTER_SIZE,
  type CoverStyle,
  type Mode,
  type TiebreakKey,
  type TournamentStatus,
} from '../domain/constants.ts';
import { lockedFields, scheduleIssues, transitionBlockers, acceptsRegistrations, canTransition } from '../domain/tournamentRules.ts';
import { validateScoringRules } from '../domain/scoring.ts';
import { computeAllocations, validatePrizeShares, unallocatedMinor } from '../domain/prizes.ts';
import { requirePermission } from '../domain/permissions.ts';
import type { Viewer } from './accounts.ts';
import { notifyUsers } from './notifications.ts';

/**
 * Tournament configuration, lifecycle transitions and read models.
 * Status is never accepted from the client as a direct value; it changes only through
 * transitionTournament(), which evaluates the transition rules against the database state.
 */

export interface TournamentRow {
  id: string;
  slug: string;
  name: string;
  description: string;
  rules_text: string;
  entry_requirements: string;
  mode: Mode;
  roster_size: number;
  status: TournamentStatus;
  capacity: number;
  approval_mode: 'auto' | 'manual';
  reg_opens_at: string;
  reg_closes_at: string;
  starts_at: string;
  timezone: string;
  max_entries_per_match: number;
  kill_point: number;
  placement_points: string;
  tiebreak_order: string;
  scoring_version: number;
  prize_pool_minor: number;
  prize_currency: string;
  prize_share_bps: string;
  room_lead_minutes: number;
  cover_style: CoverStyle;
  created_at: string;
  updated_at: string;
  finalized_at: string | null;
}

/** Camel-case configuration used for validation and API responses. */
export interface TournamentConfig {
  name: string;
  description: string;
  rulesText: string;
  entryRequirements: string;
  mode: Mode;
  capacity: number;
  approvalMode: 'auto' | 'manual';
  regOpensAt: string;
  regClosesAt: string;
  startsAt: string;
  timezone: string;
  maxEntriesPerMatch: number;
  killPoint: number;
  placementPoints: number[];
  tiebreakOrder: TiebreakKey[];
  prizePoolMinor: number;
  prizeCurrency: string;
  prizeShareBps: number[];
  roomLeadMinutes: number;
  coverStyle: CoverStyle;
}

export function loadTournamentRow(db: Db, id: string): TournamentRow {
  const row = getRow<TournamentRow>(db, 'SELECT * FROM tournaments WHERE id = ?', id);
  if (!row) throw notFound('That tournament could not be found.');
  return row;
}

export function rowToConfig(row: TournamentRow): TournamentConfig {
  return {
    name: row.name,
    description: row.description,
    rulesText: row.rules_text,
    entryRequirements: row.entry_requirements,
    mode: row.mode,
    capacity: row.capacity,
    approvalMode: row.approval_mode,
    regOpensAt: row.reg_opens_at,
    regClosesAt: row.reg_closes_at,
    startsAt: row.starts_at,
    timezone: row.timezone,
    maxEntriesPerMatch: row.max_entries_per_match,
    killPoint: row.kill_point,
    placementPoints: JSON.parse(row.placement_points) as number[],
    tiebreakOrder: JSON.parse(row.tiebreak_order) as TiebreakKey[],
    prizePoolMinor: row.prize_pool_minor,
    prizeCurrency: row.prize_currency,
    prizeShareBps: JSON.parse(row.prize_share_bps) as number[],
    roomLeadMinutes: row.room_lead_minutes,
    coverStyle: row.cover_style,
  };
}

function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || 'tournament';
}

function uniqueSlug(db: Db, name: string): string {
  const base = slugify(name);
  let candidate = base;
  while (getRow(db, 'SELECT id FROM tournaments WHERE slug = ?', candidate)) {
    candidate = `${base}-${newId().slice(0, 4)}`;
  }
  return candidate;
}

/** Shared validation for any proposed configuration. Returns human-readable issues. */
export function validateConfig(config: TournamentConfig): string[] {
  const issues = [...scheduleIssues({ regOpensAt: config.regOpensAt, regClosesAt: config.regClosesAt, startsAt: config.startsAt })];
  issues.push(
    ...validateScoringRules({
      killPoint: config.killPoint,
      placementPoints: config.placementPoints,
      tiebreakOrder: config.tiebreakOrder,
    }),
  );
  issues.push(...validatePrizeShares(config.prizeShareBps));
  if (config.prizeShareBps.length > config.placementPoints.length) {
    issues.push('Prize shares cannot cover more places than the scoring table defines.');
  }
  if (config.prizeShareBps.length > 0 && config.prizePoolMinor === 0) {
    issues.push('Set a prize pool before allocating prizes to placements.');
  }
  return issues;
}

export function toTournamentRecord(row: TournamentRow, extras: { confirmedCount?: number; pendingCount?: number } = {}) {
  const config = rowToConfig(row);
  const shares = computeAllocations(row.prize_pool_minor, config.prizeShareBps);
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    description: row.description,
    rulesText: row.rules_text,
    entryRequirements: row.entry_requirements,
    mode: row.mode,
    rosterSize: row.roster_size,
    status: row.status,
    capacity: row.capacity,
    approvalMode: row.approval_mode,
    confirmedCount: extras.confirmedCount ?? 0,
    pendingCount: extras.pendingCount ?? 0,
    regOpensAt: row.reg_opens_at,
    regClosesAt: row.reg_closes_at,
    startsAt: row.starts_at,
    timezone: row.timezone,
    maxEntriesPerMatch: row.max_entries_per_match,
    scoring: {
      killPoint: row.kill_point,
      placementPoints: config.placementPoints,
      tiebreakOrder: config.tiebreakOrder,
      version: row.scoring_version,
    },
    prize: {
      poolMinor: row.prize_pool_minor,
      currency: row.prize_currency,
      shares: shares.map((s, index) => ({
        placement: s.placement,
        basisPoints: config.prizeShareBps[index],
        amountMinor: s.amountMinor,
      })),
      unallocatedMinor: unallocatedMinor(row.prize_pool_minor, shares),
    },
    roomLeadMinutes: row.room_lead_minutes,
    coverStyle: row.cover_style,
    finalizedAt: row.finalized_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function tournamentCounts(db: Db, tournamentId: string): { confirmedCount: number; pendingCount: number } {
  const row = getRow<{ confirmed: number; pending: number }>(
    db,
    `SELECT
       SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed,
       SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending
     FROM registrations WHERE tournament_id = ?`,
    tournamentId,
  );
  return { confirmedCount: Number(row?.confirmed ?? 0), pendingCount: Number(row?.pending ?? 0) };
}

export function confirmedCount(db: Db, tournamentId: string): number {
  return tournamentCounts(db, tournamentId).confirmedCount;
}

/* ------------------------------------------------------------------ */
/* Reads                                                               */
/* ------------------------------------------------------------------ */

const PUBLIC_STATUSES: TournamentStatus[] = [
  'scheduled',
  'registration_open',
  'registration_closed',
  'live',
  'completed',
  'cancelled',
];

export function listTournaments(
  db: Db,
  viewer: Viewer | null,
  filters: { status?: string; mode?: string; limit?: number; offset?: number },
) {
  const limit = Math.min(Math.max(filters.limit ?? 20, 1), 100);
  const offset = Math.max(filters.offset ?? 0, 0);
  const clauses: string[] = [];
  const params: (string | number)[] = [];
  const isAdmin = viewer?.role === 'admin';
  if (!isAdmin) {
    clauses.push(`status IN (${PUBLIC_STATUSES.map(() => '?').join(',')})`);
    params.push(...PUBLIC_STATUSES);
  }
  if (filters.status) {
    clauses.push('status = ?');
    params.push(filters.status);
  }
  if (filters.mode) {
    clauses.push('mode = ?');
    params.push(filters.mode);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const rows = getRows<TournamentRow>(
    db,
    `SELECT * FROM tournaments ${where} ORDER BY starts_at ASC, name ASC LIMIT ? OFFSET ?`,
    ...params,
    limit,
    offset,
  );
  const total = getRow<{ n: number }>(db, `SELECT COUNT(*) AS n FROM tournaments ${where}`, ...params)?.n ?? 0;
  return {
    items: rows.map((row) => toTournamentRecord(row, tournamentCounts(db, row.id))),
    total,
    limit,
    offset,
  };
}

export function getTournamentBySlug(db: Db, viewer: Viewer | null, slug: string) {
  const row = getRow<TournamentRow>(db, 'SELECT * FROM tournaments WHERE slug = ?', slug);
  if (!row) throw notFound('That tournament could not be found.');
  const isAdmin = viewer?.role === 'admin';
  if (!isAdmin && !PUBLIC_STATUSES.includes(row.status)) {
    throw notFound('That tournament could not be found.');
  }
  return row;
}

export function getAdminTournament(db: Db, viewer: Viewer, id: string) {
  requirePermission(viewer, 'tournaments:manage');
  const row = loadTournamentRow(db, id);
  const hasRegistrations = Boolean(getRow(db, 'SELECT id FROM registrations WHERE tournament_id = ? LIMIT 1', id));
  return {
    ...toTournamentRecord(row, tournamentCounts(db, id)),
    lockedFields: [...lockedFields(row.status, hasRegistrations)],
    matchCount: getRow<{ n: number }>(db, 'SELECT COUNT(*) AS n FROM matches WHERE tournament_id = ?', id)?.n ?? 0,
    activeRegistrationCount:
      getRow<{ n: number }>(
        db,
        `SELECT COUNT(*) AS n FROM registrations WHERE tournament_id = ? AND status IN (${ACTIVE_REGISTRATION_STATUSES.map(() => '?').join(',')})`,
        id,
        ...ACTIVE_REGISTRATION_STATUSES,
      )?.n ?? 0,
  };
}

/* ------------------------------------------------------------------ */
/* Create and update                                                   */
/* ------------------------------------------------------------------ */

export function createTournament(db: Db, actor: Viewer, rawInput: unknown) {
  requirePermission(actor, 'tournaments:manage');
  const input = parseWith(tournamentCreateSchema, rawInput);
  const config: TournamentConfig = {
    ...input,
    tiebreakOrder: input.tiebreakOrder.length ? input.tiebreakOrder : [...DEFAULT_TIEBREAK_ORDER],
  };
  const issues = validateConfig(config);
  if (issues.length) throw unprocessable('Check the tournament setup.', issues.map((message) => ({ message })), 'invalid_configuration');
  const id = newId();
  const at = nowIso();
  transact(db, () => {
    run(
      db,
      `INSERT INTO tournaments (
        id, slug, name, description, rules_text, entry_requirements, mode, roster_size, status,
        capacity, approval_mode, reg_opens_at, reg_closes_at, starts_at, timezone, max_entries_per_match,
        kill_point, placement_points, tiebreak_order, scoring_version, prize_pool_minor, prize_currency,
        prize_share_bps, room_lead_minutes, cover_style, created_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?)`,
      id,
      uniqueSlug(db, config.name),
      config.name,
      config.description,
      config.rulesText,
      config.entryRequirements,
      config.mode,
      ROSTER_SIZE[config.mode],
      config.capacity,
      config.approvalMode,
      config.regOpensAt,
      config.regClosesAt,
      config.startsAt,
      config.timezone,
      config.maxEntriesPerMatch,
      config.killPoint,
      JSON.stringify(config.placementPoints),
      JSON.stringify(config.tiebreakOrder),
      config.prizePoolMinor,
      config.prizeCurrency,
      JSON.stringify(config.prizeShareBps),
      config.roomLeadMinutes,
      config.coverStyle,
      actor.id,
      at,
      at,
    );
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'tournament.created',
      entityType: 'tournament',
      entityId: id,
      detail: { mode: config.mode, capacity: config.capacity },
    });
  });
  return getAdminTournament(db, actor, id);
}

export function updateTournament(db: Db, actor: Viewer, id: string, rawInput: unknown) {
  requirePermission(actor, 'tournaments:manage');
  const patch = parseWith(tournamentUpdateSchema, rawInput);
  return transact(db, () => {
    const row = loadTournamentRow(db, id);
    if (row.status === 'completed' || row.status === 'cancelled') {
      throw conflict('Finished or cancelled tournaments cannot be edited.', 'tournament_closed');
    }
    const current = rowToConfig(row);
    const next: TournamentConfig = { ...current, ...stripUndefined(patch) };
    const hasRegistrations = Boolean(getRow(db, 'SELECT id FROM registrations WHERE tournament_id = ? LIMIT 1', id));
    const locked = lockedFields(row.status, hasRegistrations);

    const changed = (Object.keys(patch) as (keyof TournamentConfig)[]).filter(
      (key) => JSON.stringify(patch[key as keyof typeof patch]) !== JSON.stringify(current[key]),
    );
    const blockedKeys = changed.filter((key) => locked.has(key));
    if (blockedKeys.length) {
      throw conflict(
        `These settings are locked at this stage: ${blockedKeys.join(', ')}.`,
        'field_locked',
        { fields: blockedKeys },
      );
    }
    if (row.status === 'registration_open') {
      if (next.regClosesAt < current.regClosesAt) {
        throw conflict('While registration is open you can extend the closing time, but not bring it forward.', 'registration_close_shortened');
      }
      if (next.capacity < current.capacity) {
        throw conflict('While registration is open you can raise capacity, but not lower it.', 'capacity_decreased');
      }
    }
    const issues = validateConfig(next);
    if (issues.length) throw unprocessable('Check the tournament setup.', issues.map((message) => ({ message })), 'invalid_configuration');
    if (next.capacity < confirmedCount(db, id)) {
      throw conflict('Capacity cannot be set below the number of confirmed entries.', 'capacity_below_confirmed');
    }

    const at = nowIso();
    run(
      db,
      `UPDATE tournaments SET
        name = ?, description = ?, rules_text = ?, entry_requirements = ?, mode = ?, roster_size = ?,
        capacity = ?, approval_mode = ?, reg_opens_at = ?, reg_closes_at = ?, starts_at = ?, timezone = ?,
        max_entries_per_match = ?, kill_point = ?, placement_points = ?, tiebreak_order = ?,
        scoring_version = CASE WHEN ? THEN scoring_version + 1 ELSE scoring_version END,
        prize_pool_minor = ?, prize_currency = ?, prize_share_bps = ?, room_lead_minutes = ?, cover_style = ?,
        updated_at = ?
       WHERE id = ?`,
      next.name,
      next.description,
      next.rulesText,
      next.entryRequirements,
      next.mode,
      ROSTER_SIZE[next.mode],
      next.capacity,
      next.approvalMode,
      next.regOpensAt,
      next.regClosesAt,
      next.startsAt,
      next.timezone,
      next.maxEntriesPerMatch,
      next.killPoint,
      JSON.stringify(next.placementPoints),
      JSON.stringify(next.tiebreakOrder),
      scoringChanged(current, next) ? 1 : 0,
      next.prizePoolMinor,
      next.prizeCurrency,
      JSON.stringify(next.prizeShareBps),
      next.roomLeadMinutes,
      next.coverStyle,
      at,
      id,
    );
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'tournament.updated',
      entityType: 'tournament',
      entityId: id,
      detail: { fields: changed, status: row.status },
    });
    return getAdminTournament(db, actor, id);
  });
}

function scoringChanged(a: TournamentConfig, b: TournamentConfig): boolean {
  return (
    a.killPoint !== b.killPoint ||
    JSON.stringify(a.placementPoints) !== JSON.stringify(b.placementPoints) ||
    JSON.stringify(a.tiebreakOrder) !== JSON.stringify(b.tiebreakOrder)
  );
}

function stripUndefined<T extends object>(value: T): Partial<T> {
  return Object.fromEntries(Object.entries(value).filter(([, v]) => v !== undefined)) as Partial<T>;
}

/* ------------------------------------------------------------------ */
/* Lifecycle transitions                                               */
/* ------------------------------------------------------------------ */

export function transitionTournament(db: Db, actor: Viewer, id: string, rawInput: unknown) {
  requirePermission(actor, 'tournaments:manage');
  const input = parseWith(transitionSchema, rawInput);
  if (input.to === 'completed') {
    throw conflict('Finish a tournament through the finalize action so its standings and prizes are recorded.', 'use_finalize');
  }
  const at = new Date(nowIso());
  return transact(db, () => {
    const row = loadTournamentRow(db, id);
    if (input.expectedStatus && input.expectedStatus !== row.status) {
      throw conflict(
        `This tournament is now ${row.status.replace('_', ' ')}. Refresh and try again.`,
        'stale_state',
        { currentStatus: row.status },
      );
    }
    const matchCount =
      getRow<{ n: number }>(db, "SELECT COUNT(*) AS n FROM matches WHERE tournament_id = ? AND state <> 'cancelled'", id)?.n ?? 0;
    const blockers = transitionBlockers({
      from: row.status,
      to: input.to,
      name: row.name,
      description: row.description,
      mode: row.mode,
      capacity: row.capacity,
      scheduleIssues: scheduleIssues({ regOpensAt: row.reg_opens_at, regClosesAt: row.reg_closes_at, startsAt: row.starts_at }),
      matchCount,
      now: at,
      regClosesAt: row.reg_closes_at,
    });
    if (blockers.length) {
      throw conflict(blockers[0] as string, 'transition_blocked', { blockers });
    }
    if (!canTransition(row.status, input.to)) {
      throw conflict('That status change is not allowed.', 'transition_not_allowed');
    }
    const stamp = at.toISOString();
    run(db, 'UPDATE tournaments SET status = ?, updated_at = ? WHERE id = ? AND status = ?', input.to, stamp, id, row.status);

    if (input.to === 'cancelled') {
      cancelEverythingFor(db, id, actor, stamp, input.note);
    } else if (input.to === 'live') {
      const participants = getRows<{ user_id: string }>(
        db,
        "SELECT tp.user_id FROM tournament_participants tp JOIN registrations r ON r.id = tp.registration_id WHERE tp.tournament_id = ? AND r.status = 'confirmed'",
        id,
      ).map((r) => r.user_id);
      notifyUsers(db, participants, {
        kind: 'tournament',
        title: 'Tournament is live',
        body: `${row.name} is now live. Check your match schedule for room details.`,
        link: `/tournaments/${row.slug}`,
      });
    }

    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'tournament.status_changed',
      entityType: 'tournament',
      entityId: id,
      detail: { from: row.status, to: input.to, note: input.note ?? null },
    });
    return getAdminTournament(db, actor, id);
  });
}

function cancelEverythingFor(db: Db, tournamentId: string, actor: Viewer, at: string, note?: string): void {
  const active = getRows<{ id: string; user_id: string | null; team_id: string | null }>(
    db,
    `SELECT r.id, r.user_id, r.team_id FROM registrations r WHERE r.tournament_id = ? AND r.status IN (${ACTIVE_REGISTRATION_STATUSES.map(() => '?').join(',')})`,
    tournamentId,
    ...ACTIVE_REGISTRATION_STATUSES,
  );
  const recipients = new Set<string>();
  for (const reg of active) {
    run(db, "UPDATE registrations SET status = 'cancelled', status_reason = ?, updated_at = ? WHERE id = ?", 'Tournament cancelled', at, reg.id);
    run(db, 'DELETE FROM tournament_participants WHERE registration_id = ?', reg.id);
    getRows<{ user_id: string }>(db, 'SELECT user_id FROM registration_members WHERE registration_id = ?', reg.id).forEach((m) =>
      recipients.add(m.user_id),
    );
  }
  run(db, "UPDATE matches SET state = 'cancelled', updated_at = ? WHERE tournament_id = ? AND state <> 'completed'", at, tournamentId);
  const name = getRow<{ name: string; slug: string }>(db, 'SELECT name, slug FROM tournaments WHERE id = ?', tournamentId);
  notifyUsers(db, [...recipients], {
    kind: 'tournament',
    title: 'Tournament cancelled',
    body: `${name?.name ?? 'A tournament'} has been cancelled.${note ? ` ${note}` : ''}`,
    link: name ? `/tournaments/${name.slug}` : '/tournaments',
  });
  recordAudit(db, {
    actorId: actor.id,
    actorRole: actor.role,
    action: 'tournament.cancelled_participants_released',
    entityType: 'tournament',
    entityId: tournamentId,
    detail: { releasedRegistrations: active.length },
  });
}

export function assertRegistrationWindow(status: TournamentStatus, regClosesAt: string, now: Date): void {
  if (!acceptsRegistrations(status, regClosesAt, now)) {
    throw conflict('Registration is not open for this tournament right now.', 'registration_closed');
  }
}
