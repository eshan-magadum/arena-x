import { getRow, getRows, run, transact, type Db } from '../db/index.ts';
import { nowIso } from '../lib/clock.ts';
import { recordAudit } from '../lib/audit.ts';
import { conflict, notFound, unprocessable } from '../lib/errors.ts';
import { parseWith, prizeUpdateSchema } from '../lib/validation.ts';
import { requirePermission } from '../domain/permissions.ts';
import { canMovePrize, formatMinor } from '../domain/prizes.ts';
import { PRIZE_STATUSES, type PrizeStatus } from '../domain/constants.ts';
import type { Viewer } from './accounts.ts';
import { notifyUsers } from './notifications.ts';
import { loadTournamentRow } from './tournaments.ts';

/**
 * Prize records. The statuses describe administrative progress only:
 *   allocated -> approved -> fulfilled (recorded manually by an administrator)
 * ARENA X does not move money. "fulfilled" means an administrator has recorded, with a reference,
 * that the prize was delivered through a process outside this application.
 */

interface PrizeRow {
  id: string;
  tournament_id: string;
  placement: number;
  registration_id: string;
  amount_minor: number;
  currency: string;
  status: PrizeStatus;
  external_reference: string | null;
  status_note: string | null;
  created_at: string;
  updated_at: string;
}

export function listPrizeAwards(db: Db, actor: Viewer, tournamentId: string) {
  requirePermission(actor, 'prizes:manage');
  loadTournamentRow(db, tournamentId);
  return getRows<PrizeRow & { entrant_name: string }>(
    db,
    `SELECT pa.*, r.entrant_name FROM prize_awards pa
     JOIN registrations r ON r.id = pa.registration_id
     WHERE pa.tournament_id = ? ORDER BY pa.placement`,
    tournamentId,
  ).map((p) => ({
    id: p.id,
    placement: p.placement,
    entrantName: p.entrant_name,
    registrationId: p.registration_id,
    amountMinor: p.amount_minor,
    currency: p.currency,
    display: formatMinor(p.amount_minor, p.currency),
    status: p.status,
    externalReference: p.external_reference,
    statusNote: p.status_note,
    updatedAt: p.updated_at,
  }));
}

export function updatePrizeAward(db: Db, actor: Viewer, awardId: string, rawInput: unknown) {
  requirePermission(actor, 'prizes:manage');
  const input = parseWith(prizeUpdateSchema, rawInput);
  if (input.status === 'fulfilled' && (input.note ?? '').length < 5 && !input.externalReference) {
    throw unprocessable(
      'Describe how the prize was delivered (a note or a reference) before recording it as fulfilled.',
      undefined,
      'fulfilment_detail_required',
    );
  }
  transact(db, () => {
    const award = getRow<PrizeRow>(db, 'SELECT * FROM prize_awards WHERE id = ?', awardId);
    if (!award) throw notFound('That prize record could not be found.');
    if (award.status === input.status) {
      // A repeated request must not create a second change or a second notification.
      throw conflict(`This prize is already marked ${input.status}.`, 'no_change');
    }
    if (!canMovePrize(award.status, input.status)) {
      throw conflict(`A prize cannot move from ${award.status} to ${input.status}.`, 'prize_transition');
    }
    const at = nowIso();
    run(
      db,
      'UPDATE prize_awards SET status = ?, status_note = ?, external_reference = COALESCE(?, external_reference), updated_at = ? WHERE id = ? AND status = ?',
      input.status,
      input.note ?? null,
      input.externalReference ?? null,
      at,
      awardId,
      award.status,
    );
    const tournament = loadTournamentRow(db, award.tournament_id);
    const members = getRows<{ user_id: string }>(db, 'SELECT user_id FROM registration_members WHERE registration_id = ?', award.registration_id).map(
      (r) => r.user_id,
    );
    notifyUsers(db, members, {
      kind: 'prize',
      title: 'Prize update',
      body: `Your ${ordinal(award.placement)} place prize for ${tournament.name} (${formatMinor(award.amount_minor, award.currency)}) is now ${input.status}.`,
      link: `/tournaments/${tournament.slug}`,
    });
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'prize.status_changed',
      entityType: 'prize_award',
      entityId: awardId,
      detail: { from: award.status, to: input.status, placement: award.placement, amountMinor: award.amount_minor },
    });
  });
  return listPrizeAwards(db, actor, getRow<{ tournament_id: string }>(db, 'SELECT tournament_id FROM prize_awards WHERE id = ?', awardId)!.tournament_id);
}

export function prizeTotals(db: Db) {
  const rows = getRows<{ status: string; currency: string; total: number; n: number }>(
    db,
    'SELECT status, currency, COALESCE(SUM(amount_minor), 0) AS total, COUNT(*) AS n FROM prize_awards GROUP BY status, currency',
  );
  const byStatus: Record<string, { count: number; totals: Record<string, number> }> = {};
  for (const status of PRIZE_STATUSES) byStatus[status] = { count: 0, totals: {} };
  for (const row of rows) {
    const bucket = byStatus[row.status] ?? { count: 0, totals: {} };
    bucket.count += Number(row.n);
    bucket.totals[row.currency] = Number(row.total);
    byStatus[row.status] = bucket;
  }
  return byStatus;
}

function ordinal(n: number): string {
  const suffix = n % 10 === 1 && n % 100 !== 11 ? 'st' : n % 10 === 2 && n % 100 !== 12 ? 'nd' : n % 10 === 3 && n % 100 !== 13 ? 'rd' : 'th';
  return `${n}${suffix}`;
}
