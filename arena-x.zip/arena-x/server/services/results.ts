import { getRow, getRows, run, transact, type Db } from '../db/index.ts';
import { newId } from '../lib/crypto.ts';
import { nowIso } from '../lib/clock.ts';
import { recordAudit } from '../lib/audit.ts';
import { conflict, forbidden, notFound, unprocessable } from '../lib/errors.ts';
import { isUniqueViolation, type Viewer } from './accounts.ts';
import { notifyUsers } from './notifications.ts';
import { parseWith, resultCorrectionSchema, resultSubmissionSchema, submissionDecisionSchema } from '../lib/validation.ts';
import {
  rankEntries,
  scoreResult,
  unresolvedTiesWithin,
  validateResultValues,
  type EntryTotals,
  type RankedEntry,
  type ScoringRules,
} from '../domain/scoring.ts';
import { computeAllocations } from '../domain/prizes.ts';
import { requirePermission } from '../domain/permissions.ts';
import { DEFAULT_TIEBREAK_ORDER, type TiebreakKey } from '../domain/constants.ts';
import { getMatchRow, allEntriesVerified, entryCount } from './matches.ts';
import { loadTournamentRow, rowToConfig, type TournamentRow } from './tournaments.ts';
import { assertCanParticipate, getMembership } from './teams.ts';

/**
 * Result submission, verification, scoring, standings, finalisation and leaderboards.
 *
 * Trust model: players submit claims; only administrators can make a result authoritative.
 * Points are calculated on the server from the tournament's rules at approval time and stored
 * with that snapshot, so later rule edits cannot silently rewrite history.
 */

export interface SubmissionRow {
  id: string;
  match_id: string;
  registration_id: string;
  submitted_by: string;
  kills: number;
  placement: number;
  evidence_url: string | null;
  notes: string | null;
  source: 'player' | 'admin_correction';
  status: 'pending' | 'approved' | 'rejected' | 'superseded';
  kill_points: number | null;
  placement_points: number | null;
  total_points: number | null;
  scoring_snapshot: string | null;
  review_reason: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  supersedes_id: string | null;
  created_at: string;
}

export interface SubmissionDto {
  id: string;
  matchId: string;
  registrationId: string;
  entrantName: string;
  kills: number;
  placement: number;
  evidenceUrl: string | null;
  notes: string | null;
  source: string;
  status: string;
  killPoints: number | null;
  placementPoints: number | null;
  totalPoints: number | null;
  reviewReason: string | null;
  reviewedAt: string | null;
  createdAt: string;
}

function toSubmissionDto(db: Db, row: SubmissionRow): SubmissionDto {
  const entrant = getRow<{ entrant_name: string }>(db, 'SELECT entrant_name FROM registrations WHERE id = ?', row.registration_id);
  return {
    id: row.id,
    matchId: row.match_id,
    registrationId: row.registration_id,
    entrantName: entrant?.entrant_name ?? 'Unknown entrant',
    kills: row.kills,
    placement: row.placement,
    evidenceUrl: row.evidence_url,
    notes: row.notes,
    source: row.source,
    status: row.status,
    killPoints: row.kill_points,
    placementPoints: row.placement_points,
    totalPoints: row.total_points,
    reviewReason: row.review_reason,
    reviewedAt: row.reviewed_at,
    createdAt: row.created_at,
  };
}

function scoringRulesOf(tournament: TournamentRow): ScoringRules {
  const config = rowToConfig(tournament);
  return { killPoint: config.killPoint, placementPoints: config.placementPoints, tiebreakOrder: config.tiebreakOrder };
}

function snapshotOf(rules: ScoringRules, version: number): string {
  return JSON.stringify({ version, ...rules });
}

function membersNamed(db: Db, registrationId: string): string[] {
  return getRows<{ user_id: string }>(db, 'SELECT user_id FROM registration_members WHERE registration_id = ?', registrationId).map(
    (r) => r.user_id,
  );
}

/* ------------------------------------------------------------------ */
/* Submission                                                          */
/* ------------------------------------------------------------------ */

export function submitResult(db: Db, viewer: Viewer, matchId: string, rawInput: unknown): SubmissionDto {
  const input = parseWith(resultSubmissionSchema, rawInput);
  if (viewer.restriction) {
    throw forbidden('Your account is restricted, so you cannot submit results right now.', 'account_restricted');
  }
  assertCanParticipate(db, viewer);
  let id = '';
  try {
    transact(db, () => {
      const match = getMatchRow(db, matchId);
      const tournament = loadTournamentRow(db, match.tournament_id);
      if (tournament.status !== 'live') {
        throw conflict('Results can only be submitted while the tournament is live.', 'tournament_not_live');
      }
      if (match.state !== 'live' && match.state !== 'awaiting_results') {
        throw conflict('Results are not being accepted for this match right now.', 'results_closed');
      }
      const entry = getRow<{ registration_id: string; kind: string; team_id: string | null }>(
        db,
        `SELECT me.registration_id, r.kind, r.team_id FROM match_entries me
         JOIN registrations r ON r.id = me.registration_id
         JOIN registration_members rm ON rm.registration_id = r.id
         WHERE me.match_id = ? AND rm.user_id = ? LIMIT 1`,
        matchId,
        viewer.id,
      );
      if (!entry) {
        throw forbidden('Only players entered in this match can submit its result.', 'not_a_participant');
      }
      if (entry.kind === 'team') {
        const membership = getMembership(db, entry.team_id as string, viewer.id);
        if (membership?.role !== 'captain') {
          throw forbidden('Only the team captain can submit the team result.', 'captain_required');
        }
      }
      const issues = validateResultValues(input, entryCount(db, matchId));
      if (issues.length) {
        throw unprocessable('Check the result values.', issues, 'invalid_result');
      }
      const approved = getRow(db, "SELECT id FROM result_submissions WHERE match_id = ? AND registration_id = ? AND status = 'approved'", matchId, entry.registration_id);
      if (approved) {
        throw conflict('This result has already been verified. Ask an admin to correct it if it is wrong.', 'already_verified');
      }
      const pending = getRow(db, "SELECT id FROM result_submissions WHERE match_id = ? AND registration_id = ? AND status = 'pending'", matchId, entry.registration_id);
      if (pending) {
        throw conflict('A result for this match is already waiting for review.', 'submission_pending');
      }
      id = newId();
      run(
        db,
        `INSERT INTO result_submissions (id, match_id, registration_id, submitted_by, kills, placement, evidence_url, notes, source, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'player', 'pending', ?)`,
        id,
        matchId,
        entry.registration_id,
        viewer.id,
        input.kills,
        input.placement,
        input.evidenceUrl ?? null,
        input.notes ?? null,
        nowIso(),
      );
      recordAudit(db, {
        actorId: viewer.id,
        actorRole: viewer.role,
        action: 'result.submitted',
        entityType: 'result_submission',
        entityId: id,
        detail: { matchId, registrationId: entry.registration_id, kills: input.kills, placement: input.placement },
      });
    });
  } catch (error) {
    if (isUniqueViolation(error)) {
      throw conflict('A result for this match is already waiting for review.', 'submission_pending');
    }
    throw error;
  }
  return toSubmissionDto(db, getRow<SubmissionRow>(db, 'SELECT * FROM result_submissions WHERE id = ?', id)!);
}

export function listMySubmissions(db: Db, viewer: Viewer, matchId: string): SubmissionDto[] {
  return getRows<SubmissionRow>(
    db,
    `SELECT rs.* FROM result_submissions rs
     JOIN registration_members rm ON rm.registration_id = rs.registration_id
     WHERE rs.match_id = ? AND rm.user_id = ? ORDER BY rs.created_at DESC`,
    matchId,
    viewer.id,
  ).map((row) => toSubmissionDto(db, row));
}

/* ------------------------------------------------------------------ */
/* Review queue and verification                                       */
/* ------------------------------------------------------------------ */

export function listSubmissionsForReview(db: Db, actor: Viewer, filters: { status?: string; tournamentId?: string }) {
  requirePermission(actor, 'results:review');
  const clauses: string[] = [];
  const params: (string | number)[] = [];
  if (filters.status) {
    clauses.push('rs.status = ?');
    params.push(filters.status);
  }
  if (filters.tournamentId) {
    clauses.push('t.id = ?');
    params.push(filters.tournamentId);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  return getRows<SubmissionRow & { tournament_id: string; tournament_name: string; match_round: string; entrant_name: string; mode: string }>(
    db,
    `SELECT rs.*, t.id AS tournament_id, t.name AS tournament_name, m.round_label AS match_round,
            r.entrant_name, t.mode
     FROM result_submissions rs
     JOIN matches m ON m.id = rs.match_id
     JOIN tournaments t ON t.id = m.tournament_id
     JOIN registrations r ON r.id = rs.registration_id
     ${where}
     ORDER BY CASE rs.status WHEN 'pending' THEN 0 ELSE 1 END, rs.created_at ASC
     LIMIT 200`,
    ...params,
  ).map((row) => ({
    ...toSubmissionDto(db, row),
    tournamentId: row.tournament_id,
    tournamentName: row.tournament_name,
    matchRound: row.match_round,
    mode: row.mode,
    supersedesId: row.supersedes_id,
  }));
}

export function reviewSubmission(db: Db, actor: Viewer, submissionId: string, rawInput: unknown): SubmissionDto {
  requirePermission(actor, 'results:review');
  const input = parseWith(submissionDecisionSchema, rawInput);
  transact(db, () => {
    const sub = getRow<SubmissionRow>(db, 'SELECT * FROM result_submissions WHERE id = ?', submissionId);
    if (!sub) throw notFound('That result could not be found.');
    if (sub.status !== 'pending') {
      throw conflict('This result has already been reviewed.', 'not_pending');
    }
    const match = getMatchRow(db, sub.match_id);
    const tournament = loadTournamentRow(db, match.tournament_id);
    if (tournament.status !== 'live') {
      throw conflict('Results can only be reviewed while the tournament is live.', 'tournament_not_live');
    }
    const at = nowIso();
    const recipients = membersNamed(db, sub.registration_id);
    if (input.decision === 'approve') {
      const rules = scoringRulesOf(tournament);
      const breakdown = scoreResult({ kills: sub.kills, placement: sub.placement }, rules);
      run(
        db,
        `UPDATE result_submissions SET status = 'approved', kill_points = ?, placement_points = ?, total_points = ?,
           scoring_snapshot = ?, review_reason = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ?`,
        breakdown.killPoints,
        breakdown.placementPoints,
        breakdown.totalPoints,
        snapshotOf(rules, tournament.scoring_version),
        input.reason ?? null,
        actor.id,
        at,
        submissionId,
      );
      if (allEntriesVerified(db, match.id)) {
        run(db, "UPDATE matches SET state = 'completed', updated_at = ? WHERE id = ? AND state IN ('live', 'awaiting_results')", at, match.id);
      }
      notifyUsers(db, recipients, {
        kind: 'result',
        title: 'Result verified',
        body: `${sub.kills} kills and placement ${sub.placement} were verified for ${match.round_label}: ${breakdown.totalPoints} points.`,
        link: `/matches/${match.id}`,
      });
    } else {
      run(
        db,
        "UPDATE result_submissions SET status = 'rejected', review_reason = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ?",
        input.reason ?? null,
        actor.id,
        at,
        submissionId,
      );
      notifyUsers(db, recipients, {
        kind: 'result',
        title: 'Result not verified',
        body: `The result for ${match.round_label} was rejected. Reason: ${input.reason}. You can submit a corrected result.`,
        link: `/matches/${match.id}`,
      });
    }
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: `result.${input.decision === 'approve' ? 'approved' : 'rejected'}`,
      entityType: 'result_submission',
      entityId: submissionId,
      detail: { matchId: match.id, reason: input.reason ?? null, kills: sub.kills, placement: sub.placement },
    });
  });
  return toSubmissionDto(db, getRow<SubmissionRow>(db, 'SELECT * FROM result_submissions WHERE id = ?', submissionId)!);
}

/**
 * Corrects a verified result. The original row is kept as "superseded" and a new approved row
 * records the corrected values, the reason and the reviewing administrator.
 */
export function correctApprovedResult(db: Db, actor: Viewer, submissionId: string, rawInput: unknown): SubmissionDto {
  requirePermission(actor, 'results:review');
  const input = parseWith(resultCorrectionSchema, rawInput);
  let correctedId = '';
  transact(db, () => {
    const old = getRow<SubmissionRow>(db, 'SELECT * FROM result_submissions WHERE id = ?', submissionId);
    if (!old) throw notFound('That result could not be found.');
    if (old.status !== 'approved') {
      throw conflict('Only verified results can be corrected.', 'not_approved');
    }
    const match = getMatchRow(db, old.match_id);
    const tournament = loadTournamentRow(db, match.tournament_id);
    if (tournament.status !== 'live') {
      throw conflict('Standings are final once a tournament completes, so corrections are no longer possible.', 'standings_final');
    }
    const issues = validateResultValues(input, entryCount(db, match.id));
    if (issues.length) throw unprocessable('Check the corrected values.', issues, 'invalid_result');
    const rules = scoringRulesOf(tournament);
    const breakdown = scoreResult({ kills: input.kills, placement: input.placement }, rules);
    const at = nowIso();
    run(db, "UPDATE result_submissions SET status = 'superseded' WHERE id = ?", submissionId);
    correctedId = newId();
    run(
      db,
      `INSERT INTO result_submissions (id, match_id, registration_id, submitted_by, kills, placement, evidence_url, notes,
         source, status, kill_points, placement_points, total_points, scoring_snapshot, review_reason, reviewed_by, reviewed_at, supersedes_id, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'admin_correction', 'approved', ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      correctedId,
      old.match_id,
      old.registration_id,
      old.submitted_by,
      input.kills,
      input.placement,
      old.evidence_url,
      old.notes,
      breakdown.killPoints,
      breakdown.placementPoints,
      breakdown.totalPoints,
      snapshotOf(rules, tournament.scoring_version),
      input.reason,
      actor.id,
      at,
      submissionId,
      at,
    );
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'result.corrected',
      entityType: 'result_submission',
      entityId: correctedId,
      detail: {
        supersedes: submissionId,
        before: { kills: old.kills, placement: old.placement, totalPoints: old.total_points },
        after: { kills: input.kills, placement: input.placement, totalPoints: breakdown.totalPoints },
        reason: input.reason,
      },
    });
    notifyUsers(db, membersNamed(db, old.registration_id), {
      kind: 'result',
      title: 'Result corrected',
      body: `An administrator corrected the verified result for ${match.round_label}. Reason: ${input.reason}`,
      link: `/matches/${match.id}`,
    });
  });
  return toSubmissionDto(db, getRow<SubmissionRow>(db, 'SELECT * FROM result_submissions WHERE id = ?', correctedId)!);
}

/* ------------------------------------------------------------------ */
/* Standings                                                           */
/* ------------------------------------------------------------------ */

interface StandingRowRaw {
  registration_id: string;
  entrant_name: string;
  kind: string;
  team_id: string | null;
  total_points: number;
  kills: number;
  first_places: number;
  best_placement: number | null;
  matches_played: number;
}

export interface StandingDto {
  rank: number;
  registrationId: string;
  entrantName: string;
  kind: string;
  members: string[];
  totalPoints: number;
  kills: number;
  firstPlaces: number;
  bestPlacement: number | null;
  matchesPlayed: number;
  pendingSubmissions: number;
}

function liveStandings(db: Db, tournamentId: string, tiebreak: readonly TiebreakKey[]): StandingDto[] {
  const raw = getRows<StandingRowRaw>(
    db,
    `SELECT r.id AS registration_id, r.entrant_name, r.kind, r.team_id,
            COALESCE(SUM(s.total_points), 0) AS total_points,
            COALESCE(SUM(s.kills), 0) AS kills,
            COALESCE(SUM(CASE WHEN s.placement = 1 THEN 1 ELSE 0 END), 0) AS first_places,
            MIN(s.placement) AS best_placement,
            COUNT(s.id) AS matches_played
     FROM registrations r
     LEFT JOIN result_submissions s ON s.registration_id = r.id AND s.status = 'approved'
     WHERE r.tournament_id = ? AND r.status = 'confirmed'
     GROUP BY r.id`,
    tournamentId,
  );
  const pending = new Map(
    getRows<{ registration_id: string; n: number }>(
      db,
      `SELECT rs.registration_id, COUNT(*) AS n FROM result_submissions rs
       JOIN registrations r ON r.id = rs.registration_id
       WHERE r.tournament_id = ? AND rs.status = 'pending' GROUP BY rs.registration_id`,
      tournamentId,
    ).map((p) => [p.registration_id, p.n] as const),
  );
  const entries: EntryTotals[] = raw.map((r) => ({
    registrationId: r.registration_id,
    totalPoints: Number(r.total_points),
    kills: Number(r.kills),
    firstPlaces: Number(r.first_places),
    bestPlacement: r.best_placement === null ? null : Number(r.best_placement),
    matchesPlayed: Number(r.matches_played),
  }));
  const ranked = rankEntries(entries, tiebreak);
  const byId = new Map(raw.map((r) => [r.registration_id, r]));
  const standings: StandingDto[] = ranked.map((entry) => {
    const row = byId.get(entry.registrationId)!;
    return {
      rank: entry.rank,
      registrationId: row.registration_id,
      entrantName: row.entrant_name,
      kind: row.kind,
      members: getRows<{ display_name_snapshot: string }>(
        db,
        'SELECT display_name_snapshot FROM registration_members WHERE registration_id = ? ORDER BY display_name_snapshot',
        row.registration_id,
      ).map((m) => m.display_name_snapshot),
      totalPoints: entry.totalPoints,
      kills: entry.kills,
      firstPlaces: entry.firstPlaces,
      bestPlacement: entry.bestPlacement,
      matchesPlayed: entry.matchesPlayed,
      pendingSubmissions: pending.get(row.registration_id) ?? 0,
    };
  });
  return standings;
}

/**
 * Public standings. Once a tournament is finalised the stored snapshot is returned, so the
 * published table can never drift. Before that, the table is provisional and counts approved
 * results only.
 */
export function getStandings(db: Db, tournament: TournamentRow) {
  if (tournament.finalized_at) {
    const rows = getRows<{
      registration_id: string;
      rank: number;
      total_points: number;
      kills: number;
      first_places: number;
      best_placement: number | null;
      matches_played: number;
      entrant_name: string;
      kind: string;
    }>(
      db,
      `SELECT ts.*, r.entrant_name, r.kind FROM tournament_standings ts
       JOIN registrations r ON r.id = ts.registration_id
       WHERE ts.tournament_id = ? ORDER BY ts.rank, r.entrant_name`,
      tournament.id,
    );
    return {
      provisional: false,
      finalizedAt: tournament.finalized_at,
      standings: rows.map((r) => ({
        rank: r.rank,
        registrationId: r.registration_id,
        entrantName: r.entrant_name,
        kind: r.kind,
        members: getRows<{ display_name_snapshot: string }>(
          db,
          'SELECT display_name_snapshot FROM registration_members WHERE registration_id = ? ORDER BY display_name_snapshot',
          r.registration_id,
        ).map((m) => m.display_name_snapshot),
        totalPoints: r.total_points,
        kills: r.kills,
        firstPlaces: r.first_places,
        bestPlacement: r.best_placement,
        matchesPlayed: r.matches_played,
        pendingSubmissions: 0,
      })),
    };
  }
  const standings = liveStandings(db, tournament.id, rowToConfig(tournament).tiebreakOrder);
  return { provisional: true, finalizedAt: null, standings };
}

/* ------------------------------------------------------------------ */
/* Finalisation                                                        */
/* ------------------------------------------------------------------ */

export interface FinalizeOutcome {
  tournamentId: string;
  standings: StandingDto[];
  prizeAwards: Array<{ placement: number; registrationId: string; entrantName: string; amountMinor: number; currency: string }>;
}

export function finalizeTournament(db: Db, actor: Viewer, tournamentId: string): FinalizeOutcome {
  requirePermission(actor, 'tournaments:manage');
  requirePermission(actor, 'results:review');
  return transact(db, () => {
    const tournament = loadTournamentRow(db, tournamentId);
    if (tournament.status !== 'live') {
      throw conflict('Only a live tournament can be finalised.', 'not_live');
    }
    const pending = getRow<{ n: number }>(
      db,
      `SELECT COUNT(*) AS n FROM result_submissions rs JOIN matches m ON m.id = rs.match_id
       WHERE m.tournament_id = ? AND rs.status = 'pending'`,
      tournamentId,
    )?.n ?? 0;
    if (pending > 0) {
      throw conflict(`${pending} result${pending === 1 ? ' is' : 's are'} still waiting for review. Resolve them before finalising.`, 'pending_results', { pending });
    }
    const unfinished = getRows<{ id: string; round_label: string }>(
      db,
      "SELECT id, round_label FROM matches WHERE tournament_id = ? AND state NOT IN ('completed', 'cancelled')",
      tournamentId,
    );
    if (unfinished.length > 0) {
      throw conflict(
        `These matches are not finished yet: ${unfinished.map((m) => m.round_label).join(', ')}. Complete or cancel them first.`,
        'matches_unfinished',
        { matches: unfinished },
      );
    }

    const config = rowToConfig(tournament);
    const standings = liveStandings(db, tournamentId, config.tiebreakOrder);
    const ranked: RankedEntry[] = standings.map((s) => ({
      registrationId: s.registrationId,
      totalPoints: s.totalPoints,
      kills: s.kills,
      firstPlaces: s.firstPlaces,
      bestPlacement: s.bestPlacement,
      matchesPlayed: s.matchesPlayed,
      rank: s.rank,
    }));
    if (config.prizeShareBps.length > 0 && config.prizePoolMinor > 0) {
      const ties = unresolvedTiesWithin(ranked, config.prizeShareBps.length);
      if (ties.length > 0) {
        throw conflict(
          'Two or more entries are tied for a prize place. Resolve the tie before finalising: the tie-breakers did not separate them.',
          'unresolved_tie',
          { groups: ties.map((g) => g.map((e) => e.registrationId)) },
        );
      }
    }

    const at = nowIso();
    for (const s of standings) {
      run(
        db,
        `INSERT INTO tournament_standings (tournament_id, registration_id, rank, total_points, kills, first_places, best_placement, matches_played, finalized_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        tournamentId,
        s.registrationId,
        s.rank,
        s.totalPoints,
        s.kills,
        s.firstPlaces,
        s.bestPlacement,
        s.matchesPlayed,
        at,
      );
    }

    const prizeAwards: FinalizeOutcome['prizeAwards'] = [];
    if (config.prizePoolMinor > 0 && config.prizeShareBps.length > 0) {
      const allocations = computeAllocations(config.prizePoolMinor, config.prizeShareBps);
      for (const allocation of allocations) {
        const winner = standings.find((s) => s.rank === allocation.placement);
        if (!winner) continue;
        run(
          db,
          `INSERT INTO prize_awards (id, tournament_id, placement, registration_id, amount_minor, currency, status, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, 'allocated', ?, ?)`,
          newId(),
          tournamentId,
          allocation.placement,
          winner.registrationId,
          allocation.amountMinor,
          config.prizeCurrency,
          at,
          at,
        );
        prizeAwards.push({
          placement: allocation.placement,
          registrationId: winner.registrationId,
          entrantName: winner.entrantName,
          amountMinor: allocation.amountMinor,
          currency: config.prizeCurrency,
        });
      }
    }

    run(db, "UPDATE tournaments SET status = 'completed', finalized_at = ?, updated_at = ? WHERE id = ?", at, at, tournamentId);

    const everyone = getRows<{ user_id: string }>(
      db,
      `SELECT DISTINCT rm.user_id FROM registration_members rm
       JOIN registrations r ON r.id = rm.registration_id
       WHERE r.tournament_id = ? AND r.status = 'confirmed'`,
      tournamentId,
    ).map((r) => r.user_id);
    notifyUsers(db, everyone, {
      kind: 'results',
      title: 'Final results published',
      body: `${tournament.name} is complete. Final standings are now published.`,
      link: `/tournaments/${tournament.slug}`,
    });
    // Public winner announcement, written in the same transaction as finalisation so it exists exactly when
    // the standings do. Published to the announcements list that the home page shows.
    const podium = standings.filter((s) => s.rank <= 3);
    if (podium.length > 0) {
      const lines = podium.map((s) => `#${s.rank} ${s.entrantName} (${s.totalPoints} points)`);
      run(
        db,
        'INSERT INTO announcements (id, title, body, created_by, created_at) VALUES (?, ?, ?, ?, ?)',
        newId(),
        `Winners: ${tournament.name}`.slice(0, 120),
        `${tournament.name} is complete. ${lines.join('; ')}.`,
        actor.id,
        at,
      );
    }
    for (const winner of standings.filter((s) => s.rank <= 3)) {
      notifyUsers(db, membersNamed(db, winner.registrationId), {
        kind: 'winner',
        title: winner.rank === 1 ? 'Champion!' : `Placed #${winner.rank}`,
        body: `You finished #${winner.rank} in ${tournament.name} with ${winner.totalPoints} points.`,
        link: `/tournaments/${tournament.slug}`,
      });
    }
    recordAudit(db, {
      actorId: actor.id,
      actorRole: actor.role,
      action: 'tournament.finalized',
      entityType: 'tournament',
      entityId: tournamentId,
      detail: { entries: standings.length, prizeAwards: prizeAwards.length },
    });
    return { tournamentId, standings, prizeAwards };
  });
}

/* ------------------------------------------------------------------ */
/* Leaderboards and stats                                              */
/* ------------------------------------------------------------------ */

export interface LeaderboardRow {
  rank: number;
  key: string;
  name: string;
  avatarKey: string | null;
  totalPoints: number;
  kills: number;
  wins: number;
  matchesPlayed: number;
}

/**
 * Cross-tournament leaderboard built only from approved (verified) results. Players are ranked by
 * the individual points of every match they played; team boards credit each team's own results.
 */
export function leaderboard(db: Db, scope: 'players' | 'teams', mode: string | undefined, limit = 50): LeaderboardRow[] {
  const bounded = Math.min(Math.max(limit, 1), 200);
  const modeClause = mode ? 'AND t.mode = ?' : '';
  const modeParams = mode ? [mode] : [];
  let raw: Array<{ key: string; name: string; avatar_key: string | null; pts: number; kills: number; wins: number; matches: number }>;
  if (scope === 'players') {
    raw = getRows(
      db,
      `SELECT rm.user_id AS key, u.display_name AS name, u.avatar_key AS avatar_key,
              SUM(s.total_points) AS pts, SUM(s.kills) AS kills,
              SUM(CASE WHEN s.placement = 1 THEN 1 ELSE 0 END) AS wins, COUNT(s.id) AS matches
       FROM result_submissions s
       JOIN registrations r ON r.id = s.registration_id
       JOIN tournaments t ON t.id = r.tournament_id
       JOIN registration_members rm ON rm.registration_id = s.registration_id
       JOIN users u ON u.id = rm.user_id
       WHERE s.status = 'approved' AND r.status = 'confirmed' ${modeClause}
       GROUP BY rm.user_id`,
      ...modeParams,
    );
  } else {
    raw = getRows(
      db,
      `SELECT r.team_id AS key, r.entrant_name AS name, NULL AS avatar_key,
              SUM(s.total_points) AS pts, SUM(s.kills) AS kills,
              SUM(CASE WHEN s.placement = 1 THEN 1 ELSE 0 END) AS wins, COUNT(s.id) AS matches
       FROM result_submissions s
       JOIN registrations r ON r.id = s.registration_id
       JOIN tournaments t ON t.id = r.tournament_id
       WHERE s.status = 'approved' AND r.kind = 'team' AND r.status = 'confirmed' ${modeClause}
       GROUP BY r.team_id`,
      ...modeParams,
    );
  }
  const entries: EntryTotals[] = raw.map((r) => ({
    registrationId: r.key,
    totalPoints: Number(r.pts),
    kills: Number(r.kills),
    firstPlaces: Number(r.wins),
    bestPlacement: null,
    matchesPlayed: Number(r.matches),
  }));
  const ranked = rankEntries(entries, DEFAULT_TIEBREAK_ORDER);
  const byKey = new Map(raw.map((r) => [r.key, r]));
  return ranked.slice(0, bounded).map((entry) => {
    const row = byKey.get(entry.registrationId)!;
    return {
      rank: entry.rank,
      key: row.key,
      name: row.name,
      avatarKey: row.avatar_key,
      totalPoints: entry.totalPoints,
      kills: entry.kills,
      wins: entry.firstPlaces,
      matchesPlayed: entry.matchesPlayed,
    };
  });
}

export function playerStats(db: Db, userId: string) {
  const row = getRow<{ matches: number; points: number; kills: number; wins: number; tournaments: number }>(
    db,
    `SELECT COUNT(s.id) AS matches, COALESCE(SUM(s.total_points), 0) AS points,
            COALESCE(SUM(s.kills), 0) AS kills,
            COALESCE(SUM(CASE WHEN s.placement = 1 THEN 1 ELSE 0 END), 0) AS wins,
            (SELECT COUNT(DISTINCT r2.tournament_id) FROM registration_members rm2
               JOIN registrations r2 ON r2.id = rm2.registration_id
               WHERE rm2.user_id = ?) AS tournaments
     FROM result_submissions s
     JOIN registration_members rm ON rm.registration_id = s.registration_id
     WHERE rm.user_id = ? AND s.status = 'approved'`,
    userId,
    userId,
  );
  return {
    verifiedMatches: Number(row?.matches ?? 0),
    totalPoints: Number(row?.points ?? 0),
    kills: Number(row?.kills ?? 0),
    wins: Number(row?.wins ?? 0),
    tournamentsEntered: Number(row?.tournaments ?? 0),
  };
}

export function submissionsCountPending(db: Db): number {
  return getRow<{ n: number }>(db, "SELECT COUNT(*) AS n FROM result_submissions WHERE status = 'pending'")?.n ?? 0;
}

export function recentWinners(db: Db, limit = 5) {
  return getRows<{ tournament_name: string; slug: string; entrant_name: string; total_points: number; finalized_at: string; kind: string; registration_id: string }>(
    db,
    `SELECT t.name AS tournament_name, t.slug, r.entrant_name, ts.total_points, t.finalized_at, r.kind, r.id AS registration_id
     FROM tournament_standings ts
     JOIN tournaments t ON t.id = ts.tournament_id
     JOIN registrations r ON r.id = ts.registration_id
     WHERE ts.rank = 1 AND t.status = 'completed'
     ORDER BY t.finalized_at DESC LIMIT ?`,
    Math.min(Math.max(limit, 1), 20),
  ).map((w) => ({
    tournamentName: w.tournament_name,
    tournamentSlug: w.slug,
    winnerName: w.entrant_name,
    kind: w.kind,
    totalPoints: w.total_points,
    finalizedAt: w.finalized_at,
  }));
}
