import { getRow, getRows, run, type Db } from '../db/index.ts';
import { newId } from '../lib/crypto.ts';
import { nowIso } from '../lib/clock.ts';
import { notFound } from '../lib/errors.ts';
import { publishToUsers } from '../lib/events.ts';

/**
 * Persistent in-app notifications. Rows are written to the database first; the live channel is a
 * hint so connected browsers can refresh. Reconnecting clients always recover from the database.
 */

export interface NotifyInput {
  kind: string;
  title: string;
  body: string;
  link?: string | null;
}

export function notifyUsers(db: Db, userIds: readonly string[], input: NotifyInput): void {
  const unique = [...new Set(userIds)];
  if (unique.length === 0) return;
  const at = nowIso();
  for (const userId of unique) {
    run(
      db,
      'INSERT INTO notifications (id, user_id, kind, title, body, link, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      newId(),
      userId,
      input.kind,
      input.title,
      input.body,
      input.link ?? null,
      at,
    );
  }
  publishToUsers(unique, { type: 'notification', data: { kind: input.kind } });
}

export interface NotificationDto {
  id: string;
  kind: string;
  title: string;
  body: string;
  link: string | null;
  read: boolean;
  createdAt: string;
}

interface NotificationRow {
  id: string;
  kind: string;
  title: string;
  body: string;
  link: string | null;
  read_at: string | null;
  created_at: string;
}

export function listNotifications(db: Db, userId: string, limit = 30, before?: string): { items: NotificationDto[]; unread: number } {
  const bounded = Math.min(Math.max(limit, 1), 100);
  const rows = before
    ? getRows<NotificationRow>(
        db,
        'SELECT * FROM notifications WHERE user_id = ? AND created_at < ? ORDER BY created_at DESC LIMIT ?',
        userId,
        before,
        bounded,
      )
    : getRows<NotificationRow>(
        db,
        'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
        userId,
        bounded,
      );
  return { items: rows.map(toDto), unread: unreadCount(db, userId) };
}

export function unreadCount(db: Db, userId: string): number {
  const row = getRow<{ n: number }>(
    db,
    'SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL',
    userId,
  );
  return row?.n ?? 0;
}

export function markNotificationRead(db: Db, userId: string, notificationId: string): number {
  const exists = getRow(db, 'SELECT id FROM notifications WHERE id = ? AND user_id = ?', notificationId, userId);
  if (!exists) throw notFound('That notification could not be found.');
  run(
    db,
    'UPDATE notifications SET read_at = COALESCE(read_at, ?) WHERE id = ? AND user_id = ?',
    nowIso(),
    notificationId,
    userId,
  );
  return unreadCount(db, userId);
}

export function markAllNotificationsRead(db: Db, userId: string): number {
  run(db, 'UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL', nowIso(), userId);
  return unreadCount(db, userId);
}

function toDto(row: NotificationRow): NotificationDto {
  return {
    id: row.id,
    kind: row.kind,
    title: row.title,
    body: row.body,
    link: row.link,
    read: row.read_at !== null,
    createdAt: row.created_at,
  };
}
