import { DEV_SECRET_VALUE, loadConfig } from './lib/config.ts';
import { openDatabase } from './db/index.ts';
import { createHttpApp } from './http/app.ts';
import { buildRoutes } from './http/routes.ts';
import { log } from './lib/log.ts';

const config = loadConfig();
if (config.secret === DEV_SECRET_VALUE) {
  log('warn', 'development_secret_in_use', {
    note: 'Set ARENA_SECRET before handling real room credentials.',
  });
}

const db = openDatabase(config.dbPath);
const server = createHttpApp({ db, config, routes: buildRoutes() });

server.listen(config.port, config.host, () => {
  log('info', 'server_listening', { host: config.host, port: config.port, database: config.dbPath });
});

function shutdown(signal: string): void {
  log('info', 'shutdown_started', { signal });
  server.close(() => {
    db.close();
    log('info', 'shutdown_complete', {});
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 5_000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
