/**
 * Structured JSON logging to stdout. Callers pass only operational fields. Request bodies,
 * cookies, passwords, tokens and room credentials must never be passed in here.
 */

type Level = 'debug' | 'info' | 'warn' | 'error';

const SILENT = process.env.ARENA_LOG === 'silent' || process.env.NODE_ENV === 'test';

export function log(level: Level, message: string, fields: Record<string, unknown> = {}): void {
  if (SILENT && level !== 'error') return;
  const line = JSON.stringify({ time: new Date().toISOString(), level, msg: message, ...fields });
  if (level === 'error') {
    process.stderr.write(line + '\n');
  } else {
    process.stdout.write(line + '\n');
  }
}
