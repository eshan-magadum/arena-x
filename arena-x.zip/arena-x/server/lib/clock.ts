/**
 * Single source of time for the application. Services never call Date.now() directly,
 * which keeps registration windows, room release rules and match timing testable.
 * All persisted timestamps are UTC ISO-8601 strings with millisecond precision.
 */
let overrideMs: number | null = null;

export function now(): Date {
  return new Date(overrideMs ?? Date.now());
}

export function nowIso(): string {
  return now().toISOString();
}

/** Test hook: freeze the clock at a given instant (ms since epoch), or pass null to reset. */
export function setClockForTests(ms: number | null): void {
  overrideMs = ms;
}

export function addMinutesIso(iso: string, minutes: number): string {
  return new Date(Date.parse(iso) + minutes * 60_000).toISOString();
}

/** Normalises any parseable date string to canonical UTC ISO. Returns null if invalid. */
export function toUtcIso(value: string): string | null {
  const ms = Date.parse(value);
  return Number.isNaN(ms) ? null : new Date(ms).toISOString();
}
