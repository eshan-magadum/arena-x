import { join, resolve } from 'node:path';

export interface AppConfig {
  host: string;
  port: number;
  dbPath: string;
  /** Application secret used to encrypt room credentials. Required in production. */
  secret: string;
  isProduction: boolean;
  playerSessionDays: number;
  adminSessionHours: number;
  supportEmail: string;
  publicDir: string;
}

const DEV_SECRET = 'arena-x-development-only-secret-do-not-use-in-production';

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const isProduction = env.NODE_ENV === 'production';
  const secret = env.ARENA_SECRET ?? '';
  if (isProduction && secret.length < 32) {
    throw new Error('ARENA_SECRET must be set to at least 32 characters in production.');
  }
  const root = resolve(import.meta.dirname, '..', '..');
  return {
    host: env.HOST ?? '127.0.0.1',
    port: Number(env.PORT ?? 3000),
    dbPath: resolve(env.ARENA_DB_PATH ?? join(root, 'data', 'arena-x.sqlite')),
    secret: secret || DEV_SECRET,
    isProduction,
    playerSessionDays: 14,
    adminSessionHours: 8,
    supportEmail: env.ARENA_SUPPORT_EMAIL ?? 'support@example.invalid',
    publicDir: join(root, 'public'),
  };
}

export const DEV_SECRET_VALUE = DEV_SECRET;
