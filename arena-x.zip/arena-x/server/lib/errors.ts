/**
 * Application error type. Every expected failure (validation, permission, conflict...)
 * is thrown as an AppError so the HTTP layer can map it to a stable JSON contract:
 *   { error: { code, message, details? } }
 */
export class AppError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export const badRequest = (message: string, details?: unknown) =>
  new AppError(400, 'bad_request', message, details);

export const unauthorized = (message = 'Sign in to continue.') =>
  new AppError(401, 'unauthorized', message);

export const forbidden = (message = 'You do not have permission to do that.', code = 'forbidden') =>
  new AppError(403, code, message);

export const notFound = (message = 'We could not find that.') =>
  new AppError(404, 'not_found', message);

export const conflict = (message: string, code = 'conflict', details?: unknown) =>
  new AppError(409, code, message, details);

export const unprocessable = (message: string, details?: unknown, code = 'validation_failed') =>
  new AppError(422, code, message, details);

export const tooManyRequests = (message = 'Too many attempts. Please wait and try again.') =>
  new AppError(429, 'rate_limited', message);
