import { tooManyRequests } from './errors.ts';

/**
 * Fixed-window rate limiter kept in process memory. Good enough for a single-instance deployment;
 * a shared store (e.g. Redis) would be required to enforce limits across several instances.
 */

interface Window {
  count: number;
  resetAt: number;
}

const windows = new Map<string, Window>();
let lastSweep = 0;

export function consumeRateLimit(key: string, limit: number, windowMs: number, nowMs = Date.now()): boolean {
  if (nowMs - lastSweep > 60_000) {
    for (const [k, w] of windows) {
      if (w.resetAt <= nowMs) windows.delete(k);
    }
    lastSweep = nowMs;
  }
  const current = windows.get(key);
  if (!current || current.resetAt <= nowMs) {
    windows.set(key, { count: 1, resetAt: nowMs + windowMs });
    return true;
  }
  if (current.count >= limit) return false;
  current.count += 1;
  return true;
}

export function assertRateLimit(key: string, limit: number, windowMs: number): void {
  if (!consumeRateLimit(key, limit, windowMs)) {
    throw tooManyRequests();
  }
}

/** Test hook. */
export function resetRateLimits(): void {
  windows.clear();
}
