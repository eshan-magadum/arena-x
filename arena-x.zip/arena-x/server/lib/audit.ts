import { createHash } from 'node:crypto';
import { getRow, getRows, run, type Db } from '../db/index.ts';
import { newId } from './crypto.ts';
import { nowIso } from './clock.ts';
import { stableStringify } from './stableJson.ts';

/**
 * Tamper-evident audit trail.
 * Each event stores SHA-256(prev_hash || canonical event). Changing or deleting an earlier row
 * breaks every later hash, which verifyAuditChain() reports.
 *
 * Limits (documented in docs/SECURITY.md): anyone with write access to the database file can
 * rewrite the whole chain consistently. External anchoring of the latest hash would be needed to
 * detect that, and is not implemented.
 */

const GENESIS_HASH = '0'.repeat(64);
const SENSITIVE_KEY = /password|token|secret|room|credential|cookie|hash/i;

export interface AuditInput {
  actorId: string | null;
  actorRole: string | null;
  action: string;
  entityType: string;
  entityId: string | null;
  detail?: Record<string, unknown>;
}

/** Removes anything that looks like a credential before it is written to the log. */
export function redactDetail(detail: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(detail)) {
    if (SENSITIVE_KEY.test(key)) {
      out[key] = '[redacted]';
    } else if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
      out[key] = redactDetail(value as Record<string, unknown>);
    } else {
      out[key] = value;
    }
  }
  return out;
}

function digest(prevHash: string, fields: Record<string, unknown>): string {
  return createHash('sha256').update(prevHash).update('|').update(stableStringify(fields)).digest('hex');
}

export function recordAudit(db: Db, input: AuditInput): void {
  const last = getRow<{ hash: string }>(db, 'SELECT hash FROM audit_events ORDER BY seq DESC LIMIT 1');
  const prevHash = last?.hash ?? GENESIS_HASH;
  const id = newId();
  const createdAt = nowIso();
  const detail = redactDetail(input.detail ?? {});
  const detailJson = stableStringify(detail);
  const hash = digest(prevHash, {
    id,
    actorId: input.actorId,
    actorRole: input.actorRole,
    action: input.action,
    entityType: input.entityType,
    entityId: input.entityId,
    detail: detailJson,
    createdAt,
  });
  run(
    db,
    `INSERT INTO audit_events (id, actor_id, actor_role, action, entity_type, entity_id, detail, created_at, prev_hash, hash)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id,
    input.actorId,
    input.actorRole,
    input.action,
    input.entityType,
    input.entityId,
    detailJson,
    createdAt,
    prevHash,
    hash,
  );
}

export interface AuditVerification {
  ok: boolean;
  checked: number;
  brokenAtSeq: number | null;
}

export function verifyAuditChain(db: Db): AuditVerification {
  const rows = getRows<{
    seq: number;
    id: string;
    actor_id: string | null;
    actor_role: string | null;
    action: string;
    entity_type: string;
    entity_id: string | null;
    detail: string;
    created_at: string;
    prev_hash: string;
    hash: string;
  }>(db, 'SELECT * FROM audit_events ORDER BY seq ASC');
  let expectedPrev = GENESIS_HASH;
  for (const row of rows) {
    const recomputed = digest(row.prev_hash, {
      id: row.id,
      actorId: row.actor_id,
      actorRole: row.actor_role,
      action: row.action,
      entityType: row.entity_type,
      entityId: row.entity_id,
      detail: row.detail,
      createdAt: row.created_at,
    });
    if (row.prev_hash !== expectedPrev || recomputed !== row.hash) {
      return { ok: false, checked: rows.length, brokenAtSeq: row.seq };
    }
    expectedPrev = row.hash;
  }
  return { ok: true, checked: rows.length, brokenAtSeq: null };
}
