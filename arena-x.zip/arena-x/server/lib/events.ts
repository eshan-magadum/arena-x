import { EventEmitter } from 'node:events';

/**
 * In-process publish/subscribe used to push live updates to connected browsers over Server-Sent
 * Events. Two channels:
 *   - user channels carry private hints (notifications, team chat, team changes) for one player;
 *   - the broadcast channel carries public hints (tournament, registration, match and standings
 *     changes) to every connected browser, guests included. Broadcast data never contains private
 *     fields: only identifiers that the public pages already show.
 * Events are a delivery hint only: the database remains the source of truth, so a client that
 * misses an event recovers by re-reading persisted data.
 * This bus is single-process; multi-instance deployments would need a shared broker.
 */

export type EventType = 'notification' | 'chat' | 'team' | 'registration' | 'match' | 'tournament';

export interface AppEvent {
  type: EventType;
  data: Record<string, unknown>;
}

const bus = new EventEmitter();
bus.setMaxListeners(0);

const BROADCAST = 'broadcast';

export function publishToUsers(userIds: readonly string[], event: AppEvent): void {
  for (const userId of new Set(userIds)) {
    bus.emit(`user:${userId}`, event);
  }
}

/**
 * Sends a public hint to every open stream. Deferred to the next tick so that, when called from
 * inside a synchronous database transaction, clients only refetch after the commit has happened.
 */
export function publishBroadcast(event: AppEvent): void {
  setImmediate(() => bus.emit(BROADCAST, event));
}

export function subscribeToUser(userId: string, listener: (event: AppEvent) => void): () => void {
  const channel = `user:${userId}`;
  bus.on(channel, listener);
  return () => bus.off(channel, listener);
}

export function subscribeToBroadcast(listener: (event: AppEvent) => void): () => void {
  bus.on(BROADCAST, listener);
  return () => bus.off(BROADCAST, listener);
}

export function subscriberCount(): number {
  return bus.eventNames().reduce((total, name) => total + bus.listenerCount(name), 0);
}
