import { z } from 'zod';
import {
  AVATAR_KEYS,
  COVER_STYLES,
  DEFAULT_TIEBREAK_ORDER,
  IN_GAME_ID_PATTERN,
  MAX_ENTRIES_PER_MATCH_LIMIT,
  MODES,
  SUPPORTED_CURRENCIES,
  TIEBREAK_KEYS,
} from '../domain/constants.ts';
import { unprocessable } from './errors.ts';
import { toUtcIso } from './clock.ts';

/**
 * Request-body schemas. All objects are .strict(): unknown keys are rejected, which blocks
 * mass-assignment (for example, a client sending {"role":"admin"} or {"status":"completed"}).
 */

export function parseWith<T extends z.ZodTypeAny>(schema: T, value: unknown): z.infer<T> {
  const result = schema.safeParse(value);
  if (!result.success) {
    const details = result.error.issues.map((issue) => ({
      path: issue.path.join('.') || '(body)',
      message: issue.message,
    }));
    throw unprocessable('Some details need attention.', details);
  }
  return result.data;
}

const trimmedString = (min: number, max: number) => z.string().trim().min(min).max(max);

export const emailSchema = z.string().trim().toLowerCase().email('Enter a valid email address.').max(254);
export const passwordSchema = z
  .string()
  .min(10, 'Use at least 10 characters for your password.')
  .max(128, 'Passwords can be at most 128 characters.');
export const displayNameSchema = z
  .string()
  .trim()
  .min(3, 'Display names need at least 3 characters.')
  .max(24, 'Display names can be at most 24 characters.')
  .regex(/^[\p{L}\p{N} _.-]+$/u, 'Use letters, numbers, spaces, dots, dashes or underscores only.');
export const inGameIdSchema = z
  .string()
  .trim()
  .regex(IN_GAME_ID_PATTERN, 'Your Free Fire MAX in-game ID is 6 to 12 digits.');
export const avatarKeySchema = z.enum(AVATAR_KEYS);
export const uuidParam = z.string().min(8).max(64);

export const registerSchema = z
  .object({
    email: emailSchema,
    password: passwordSchema,
    displayName: displayNameSchema,
    inGameId: inGameIdSchema.optional(),
    avatarKey: avatarKeySchema.optional(),
  })
  .strict();

export const loginSchema = z
  .object({
    email: emailSchema,
    password: z.string().min(1).max(256),
  })
  .strict();

export const profileUpdateSchema = z
  .object({
    displayName: displayNameSchema.optional(),
    inGameId: inGameIdSchema.nullable().optional(),
    avatarKey: avatarKeySchema.optional(),
  })
  .strict();

export const passwordChangeSchema = z
  .object({
    currentPassword: z.string().min(1).max(256),
    newPassword: passwordSchema,
  })
  .strict();

const isoTimestamp = z
  .string()
  .min(1)
  .refine((value) => toUtcIso(value) !== null, 'Enter a valid date and time.')
  .transform((value) => toUtcIso(value) as string);

const placementPoints = z.array(z.number().int().min(0).max(100)).min(1).max(50);
const tiebreakOrder = z
  .array(z.enum(TIEBREAK_KEYS))
  .max(TIEBREAK_KEYS.length)
  .refine((items) => new Set(items).size === items.length, 'Tie-breakers must not repeat.')
  .default([...DEFAULT_TIEBREAK_ORDER]);

/**
 * Accepts any zone the runtime's Intl implementation understands, including aliases such as
 * Asia/Kolkata that are absent from the canonical list returned by supportedValuesOf().
 */
export function isKnownTimeZone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

export const tournamentFieldsSchema = z
  .object({
    name: trimmedString(3, 80),
    description: z.string().trim().max(2000).default(''),
    rulesText: z.string().trim().max(5000).default(''),
    entryRequirements: z.string().trim().max(1000).default(''),
    mode: z.enum(MODES),
    capacity: z.number().int().min(2).max(512),
    approvalMode: z.enum(['auto', 'manual']).default('auto'),
    regOpensAt: isoTimestamp,
    regClosesAt: isoTimestamp,
    startsAt: isoTimestamp,
    timezone: z
      .string()
      .min(3)
      .max(64)
      .refine(isKnownTimeZone, 'Choose a valid IANA time zone.'),
    maxEntriesPerMatch: z.number().int().min(2).max(MAX_ENTRIES_PER_MATCH_LIMIT).default(12),
    killPoint: z.number().int().min(0).max(100).default(1),
    placementPoints: placementPoints.default([12, 9, 8, 7, 6, 5, 4, 3, 2, 1]),
    tiebreakOrder,
    prizePoolMinor: z.number().int().min(0).max(1_000_000_000_000).default(0),
    prizeCurrency: z.enum(SUPPORTED_CURRENCIES).default('INR'),
    prizeShareBps: z.array(z.number().int().min(0).max(10_000)).max(50).default([]),
    roomLeadMinutes: z.number().int().min(0).max(1440).default(15),
    coverStyle: z.enum(COVER_STYLES).default('ember'),
  })
  .strict();

export const tournamentCreateSchema = tournamentFieldsSchema;
export const tournamentUpdateSchema = tournamentFieldsSchema.partial().strict();

export const transitionSchema = z
  .object({
    to: z.enum(['scheduled', 'registration_open', 'registration_closed', 'live', 'completed', 'cancelled']),
    /** Status the admin console believed was current. A mismatch means the screen is stale. */
    expectedStatus: z
      .enum(['draft', 'scheduled', 'registration_open', 'registration_closed', 'live', 'completed', 'cancelled'])
      .optional(),
    note: z.string().trim().max(500).optional(),
  })
  .strict();

export const teamCreateSchema = z
  .object({
    name: trimmedString(3, 24).regex(/^[\p{L}\p{N} _.-]+$/u, 'Use letters, numbers, spaces, dots, dashes or underscores only.'),
    mode: z.enum(['duo', 'squad']),
  })
  .strict();

export const inviteSchema = z.object({ email: emailSchema }).strict();

export const chatMessageSchema = z
  .object({
    body: z.string().trim().min(1, 'Write a message before sending.').max(500, 'Messages can be at most 500 characters.'),
  })
  .strict();

export const registrationCreateSchema = z
  .object({
    teamId: z.string().min(8).max(64).optional(),
  })
  .strict();

export const registrationDecisionSchema = z
  .object({
    decision: z.enum(['approve', 'reject', 'waitlist']),
    reason: z.string().trim().max(500).optional(),
  })
  .strict()
  .refine((value) => value.decision !== 'reject' || (value.reason ?? '').length >= 5, {
    message: 'Give a reason of at least 5 characters when rejecting a registration.',
    path: ['reason'],
  });

export const matchCreateSchema = z
  .object({
    roundLabel: trimmedString(1, 60),
    startsAt: isoTimestamp,
  })
  .strict();

export const matchUpdateSchema = z
  .object({
    roundLabel: trimmedString(1, 60).optional(),
    startsAt: isoTimestamp.optional(),
    state: z.enum(['scheduled', 'live', 'awaiting_results', 'completed', 'cancelled']).optional(),
  })
  .strict();

export const matchEntriesSchema = z
  .object({
    registrationIds: z.array(z.string().min(8).max(64)).min(1).max(50),
  })
  .strict()
  .refine((value) => new Set(value.registrationIds).size === value.registrationIds.length, {
    message: 'Each entry can appear only once in a match.',
    path: ['registrationIds'],
  });

export const roomSchema = z
  .object({
    roomId: z.string().trim().min(3).max(32).regex(/^[A-Za-z0-9_-]+$/, 'Room IDs use letters, numbers, dashes and underscores.'),
    roomPassword: z.string().trim().max(32).nullable().optional(),
  })
  .strict();

export const resultSubmissionSchema = z
  .object({
    kills: z.number().int().min(0).max(99),
    placement: z.number().int().min(1).max(50),
    notes: z.string().trim().max(500).optional(),
    evidenceUrl: z
      .string()
      .trim()
      .max(500)
      .refine((value) => {
        try {
          const url = new URL(value);
          return url.protocol === 'https:' && !url.username && !url.password;
        } catch {
          return false;
        }
      }, 'Evidence must be an https:// link without embedded credentials.')
      .optional(),
  })
  .strict();

export const submissionDecisionSchema = z
  .object({
    decision: z.enum(['approve', 'reject']),
    reason: z.string().trim().max(500).optional(),
  })
  .strict()
  .refine((value) => value.decision === 'approve' || (value.reason ?? '').length >= 5, {
    message: 'Give a reason of at least 5 characters when rejecting a result.',
    path: ['reason'],
  });

export const resultCorrectionSchema = z
  .object({
    kills: z.number().int().min(0).max(99),
    placement: z.number().int().min(1).max(50),
    reason: z.string().trim().min(10, 'Explain the correction in at least 10 characters.').max(500),
  })
  .strict();

export const prizeUpdateSchema = z
  .object({
    status: z.enum(['approved', 'fulfilled', 'failed', 'disputed']),
    note: z.string().trim().max(500).optional(),
    externalReference: z.string().trim().max(120).optional(),
  })
  .strict();

export const moderationSchema = z
  .object({
    action: z.enum(['suspend', 'ban', 'reinstate']),
    reason: z.string().trim().min(5, 'Give a reason of at least 5 characters.').max(500),
    days: z.number().int().min(1).max(365).optional(),
  })
  .strict();

export const announcementSchema = z
  .object({
    title: trimmedString(3, 120),
    body: trimmedString(10, 4000),
  })
  .strict();

export const idSchema = z.string().min(8).max(64);
