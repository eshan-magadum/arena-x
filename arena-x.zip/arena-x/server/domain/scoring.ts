import { DEFAULT_TIEBREAK_ORDER, MAX_KILLS_PER_ENTRY, type TiebreakKey } from './constants.ts';

/**
 * Pure scoring engine.
 *   total points = kills * killPoint + placementPoints[placement - 1]
 * Placements beyond the configured table score zero.
 * Ranking uses configured tie-breakers in order. If every configured tie-breaker is equal the
 * entries share a rank (competition ranking), and tournament finalisation refuses to award prizes
 * across an unresolved tie.
 */

export interface ScoringRules {
  killPoint: number;
  placementPoints: number[];
  tiebreakOrder: TiebreakKey[];
}

export interface ScoreBreakdown {
  killPoints: number;
  placementPoints: number;
  totalPoints: number;
}

export interface ResultValueIssue {
  field: 'kills' | 'placement';
  message: string;
}

export function pointsForPlacement(placement: number, rules: ScoringRules): number {
  return rules.placementPoints[placement - 1] ?? 0;
}

export function scoreResult(input: { kills: number; placement: number }, rules: ScoringRules): ScoreBreakdown {
  const killPoints = input.kills * rules.killPoint;
  const placementPoints = pointsForPlacement(input.placement, rules);
  return { killPoints, placementPoints, totalPoints: killPoints + placementPoints };
}

/**
 * Validates a claimed result against the game's basic rules. `entrantCount` is the number of
 * entries in the match, which bounds the possible placement.
 */
export function validateResultValues(
  input: { kills: unknown; placement: unknown },
  entrantCount: number,
): ResultValueIssue[] {
  const issues: ResultValueIssue[] = [];
  if (!Number.isInteger(input.kills) || (input.kills as number) < 0) {
    issues.push({ field: 'kills', message: 'Kills must be a whole number of zero or more.' });
  } else if ((input.kills as number) > MAX_KILLS_PER_ENTRY) {
    issues.push({ field: 'kills', message: `Kills cannot exceed ${MAX_KILLS_PER_ENTRY}.` });
  }
  if (!Number.isInteger(input.placement) || (input.placement as number) < 1) {
    issues.push({ field: 'placement', message: 'Placement must be a whole number from 1 upwards.' });
  } else if ((input.placement as number) > entrantCount) {
    issues.push({
      field: 'placement',
      message: `Placement cannot exceed the ${entrantCount} entries in this match.`,
    });
  }
  return issues;
}

export interface EntryTotals {
  registrationId: string;
  totalPoints: number;
  kills: number;
  firstPlaces: number;
  bestPlacement: number | null;
  matchesPlayed: number;
}

export interface RankedEntry extends EntryTotals {
  rank: number;
}

function compareKey(a: EntryTotals, b: EntryTotals, key: TiebreakKey): number {
  switch (key) {
    case 'kills':
      return b.kills - a.kills;
    case 'first_places':
      return b.firstPlaces - a.firstPlaces;
    case 'best_placement':
      return (a.bestPlacement ?? Number.MAX_SAFE_INTEGER) - (b.bestPlacement ?? Number.MAX_SAFE_INTEGER);
  }
}

/** Negative when `a` ranks above `b`. Zero means fully tied under the configured rules. */
export function compareEntries(a: EntryTotals, b: EntryTotals, tiebreak: readonly TiebreakKey[] = DEFAULT_TIEBREAK_ORDER): number {
  if (a.totalPoints !== b.totalPoints) return b.totalPoints - a.totalPoints;
  for (const key of tiebreak) {
    const diff = compareKey(a, b, key);
    if (diff !== 0) return diff;
  }
  return 0;
}

export function rankEntries(entries: readonly EntryTotals[], tiebreak: readonly TiebreakKey[] = DEFAULT_TIEBREAK_ORDER): RankedEntry[] {
  const sorted = [...entries].sort((a, b) => {
    const diff = compareEntries(a, b, tiebreak);
    return diff !== 0 ? diff : a.registrationId.localeCompare(b.registrationId);
  });
  const ranked: RankedEntry[] = [];
  sorted.forEach((entry, index) => {
    const previous = ranked[index - 1];
    const sharesRank = previous !== undefined && compareEntries(previous, entry, tiebreak) === 0;
    ranked.push({ ...entry, rank: sharesRank ? previous.rank : index + 1 });
  });
  return ranked;
}

/** Returns the registration IDs that share a rank with another entry at or above `topN`. */
export function unresolvedTiesWithin(ranked: readonly RankedEntry[], topN: number): RankedEntry[][] {
  const groups = new Map<number, RankedEntry[]>();
  for (const entry of ranked) {
    if (entry.rank > topN) continue;
    const group = groups.get(entry.rank) ?? [];
    group.push(entry);
    groups.set(entry.rank, group);
  }
  return [...groups.values()].filter((group) => group.length > 1);
}

export function validateScoringRules(rules: ScoringRules): string[] {
  const issues: string[] = [];
  if (!Number.isInteger(rules.killPoint) || rules.killPoint < 0 || rules.killPoint > 100) {
    issues.push('Kill points must be a whole number from 0 to 100.');
  }
  if (rules.placementPoints.length < 1 || rules.placementPoints.length > 50) {
    issues.push('Placement table must define between 1 and 50 places.');
  }
  if (rules.placementPoints.some((p) => !Number.isInteger(p) || p < 0 || p > 100)) {
    issues.push('Placement points must be whole numbers from 0 to 100.');
  }
  if (new Set(rules.tiebreakOrder).size !== rules.tiebreakOrder.length) {
    issues.push('Tie-breaker order must not repeat a criterion.');
  }
  return issues;
}
