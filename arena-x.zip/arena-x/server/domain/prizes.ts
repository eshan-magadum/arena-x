/**
 * Prize arithmetic uses integer minor units and basis points (1 bp = 0.01%) so no floating-point
 * rounding can create or destroy money. Any remainder from flooring is reported as unallocated.
 */

export const MAX_BASIS_POINTS = 10_000;

export function validatePrizeShares(sharesBps: readonly number[]): string[] {
  const issues: string[] = [];
  if (sharesBps.some((bp) => !Number.isInteger(bp) || bp < 0 || bp > MAX_BASIS_POINTS)) {
    issues.push('Each prize share must be a whole number of basis points from 0 to 10000.');
  }
  const total = sharesBps.reduce((sum, bp) => sum + bp, 0);
  if (total > MAX_BASIS_POINTS) {
    issues.push(`Prize shares total ${total / 100}% but cannot exceed 100%.`);
  }
  return issues;
}

export interface PrizeAllocation {
  placement: number;
  amountMinor: number;
}

/** Splits the pool across placements. Uses BigInt so large pools cannot lose precision. */
export function computeAllocations(poolMinor: number, sharesBps: readonly number[]): PrizeAllocation[] {
  const pool = BigInt(poolMinor);
  return sharesBps.map((bp, index) => ({
    placement: index + 1,
    amountMinor: Number((pool * BigInt(bp)) / BigInt(MAX_BASIS_POINTS)),
  }));
}

export function unallocatedMinor(poolMinor: number, allocations: readonly PrizeAllocation[]): number {
  return poolMinor - allocations.reduce((sum, a) => sum + a.amountMinor, 0);
}

export function formatMinor(amountMinor: number, currency: string): string {
  const major = amountMinor / 100;
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency, maximumFractionDigits: 2 }).format(major);
}

const PRIZE_TRANSITIONS: Record<string, readonly string[]> = {
  allocated: ['approved', 'disputed', 'failed'],
  approved: ['fulfilled', 'disputed', 'failed'],
  disputed: ['approved', 'failed'],
  failed: ['approved'],
  fulfilled: [],
};

export function canMovePrize(from: string, to: string): boolean {
  return PRIZE_TRANSITIONS[from]?.includes(to) ?? false;
}
