import { forbidden } from '../lib/errors.ts';

/**
 * Central permission map. Routes and services call requirePermission(); the frontend hides
 * controls for convenience only and is never trusted. Roles are intentionally coarse today
 * (player, admin) but every privileged capability is named here so finer roles can be added.
 */

export type Role = 'player' | 'admin';

export const PERMISSIONS = [
  'tournaments:manage',
  'registrations:decide',
  'matches:manage',
  'rooms:manage',
  'rooms:read',
  'results:review',
  'prizes:manage',
  'players:moderate',
  'announcements:publish',
  'audit:read',
  'exports:read',
  'chat:moderate',
  'analytics:view',
] as const;
export type Permission = (typeof PERMISSIONS)[number];

const ROLE_PERMISSIONS: Record<Role, ReadonlySet<Permission>> = {
  player: new Set<Permission>(),
  admin: new Set<Permission>(PERMISSIONS),
};

export function hasPermission(role: string, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role as Role]?.has(permission) ?? false;
}

export function requirePermission(actor: { role: string }, permission: Permission): void {
  if (!hasPermission(actor.role, permission)) {
    throw forbidden('You do not have permission to perform this action.', 'permission_denied');
  }
}
