/** Shared, dependency-free domain constants. */

export const MODES = ['solo', 'duo', 'squad'] as const;
export type Mode = (typeof MODES)[number];

/** Team roster sizes per mode. A registered team must have exactly this many members. */
export const ROSTER_SIZE: Record<Mode, number> = { solo: 1, duo: 2, squad: 4 };

/** Team modes are the modes that use a team roster (solo has no team). */
export const TEAM_MODES = ['duo', 'squad'] as const;
export type TeamMode = (typeof TEAM_MODES)[number];

export const TOURNAMENT_STATUSES = [
  'draft',
  'scheduled',
  'registration_open',
  'registration_closed',
  'live',
  'completed',
  'cancelled',
] as const;
export type TournamentStatus = (typeof TOURNAMENT_STATUSES)[number];

export const REGISTRATION_STATUSES = ['pending', 'confirmed', 'waitlisted', 'rejected', 'cancelled'] as const;
export type RegistrationStatus = (typeof REGISTRATION_STATUSES)[number];

/** Registrations that still hold a place in the tournament's participant list. */
export const ACTIVE_REGISTRATION_STATUSES: readonly RegistrationStatus[] = ['pending', 'confirmed', 'waitlisted'];

export const MATCH_STATES = ['scheduled', 'live', 'awaiting_results', 'completed', 'cancelled'] as const;
export type MatchState = (typeof MATCH_STATES)[number];

export const TIEBREAK_KEYS = ['kills', 'first_places', 'best_placement'] as const;
export type TiebreakKey = (typeof TIEBREAK_KEYS)[number];
export const DEFAULT_TIEBREAK_ORDER: TiebreakKey[] = ['kills', 'first_places', 'best_placement'];

/** ARENA X default scoring preset. Administrators may edit it per tournament before registration opens. */
export const DEFAULT_PLACEMENT_POINTS = [12, 9, 8, 7, 6, 5, 4, 3, 2, 1];
export const DEFAULT_KILL_POINT = 1;

export const MAX_KILLS_PER_ENTRY = 99;
export const MAX_ENTRIES_PER_MATCH_LIMIT = 50;

/** Free Fire MAX player IDs are numeric. The exact length rule is a configurable assumption; verify against the live game. */
export const IN_GAME_ID_PATTERN = /^\d{6,12}$/;

export const AVATAR_KEYS = ['bolt', 'falcon', 'ember', 'frost', 'viper', 'nova', 'ghost', 'titan'] as const;
export type AvatarKey = (typeof AVATAR_KEYS)[number];

export const COVER_STYLES = ['ember', 'lime', 'night', 'steel'] as const;
export type CoverStyle = (typeof COVER_STYLES)[number];

export const SUPPORTED_CURRENCIES = ['INR', 'USD'] as const;
export type Currency = (typeof SUPPORTED_CURRENCIES)[number];

export const PRIZE_STATUSES = ['allocated', 'approved', 'fulfilled', 'failed', 'disputed'] as const;
export type PrizeStatus = (typeof PRIZE_STATUSES)[number];
