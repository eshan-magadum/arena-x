import type { TournamentStatus } from './constants.ts';

/**
 * Tournament lifecycle rules. Every status change must pass canTransition(); the service layer
 * never writes a status directly, so a stale client request cannot move a tournament backwards
 * (for example, from completed back to registration_open).
 */

export const TRANSITIONS: Record<TournamentStatus, readonly TournamentStatus[]> = {
  draft: ['scheduled', 'cancelled'],
  scheduled: ['registration_open', 'cancelled'],
  registration_open: ['registration_closed', 'cancelled'],
  registration_closed: ['registration_open', 'live', 'cancelled'],
  live: ['completed', 'cancelled'],
  completed: [],
  cancelled: [],
};

export function canTransition(from: TournamentStatus, to: TournamentStatus): boolean {
  return TRANSITIONS[from].includes(to);
}

export function isTerminal(status: TournamentStatus): boolean {
  return status === 'completed' || status === 'cancelled';
}

/**
 * Registration is open only when the status says so AND the closing instant has not passed.
 * The status is authoritative for admin control; the timestamp protects against a window that
 * was left open after its scheduled close.
 */
export function acceptsRegistrations(status: TournamentStatus, regClosesAtIso: string, now: Date): boolean {
  return status === 'registration_open' && now.getTime() < Date.parse(regClosesAtIso);
}

/** Fields that define competitive fairness. They freeze once players can register. */
const STRUCTURAL_FIELDS = ['mode', 'approvalMode', 'regOpensAt', 'timezone', 'maxEntriesPerMatch'] as const;
const RULE_FIELDS = ['killPoint', 'placementPoints', 'tiebreakOrder', 'prizePoolMinor', 'prizeCurrency', 'prizeShareBps'] as const;
const PRESENTATION_FIELDS = ['name', 'description', 'rulesText', 'entryRequirements', 'coverStyle', 'roomLeadMinutes'] as const;
const SCHEDULE_FIELDS = ['startsAt', 'regClosesAt', 'capacity'] as const;

export function lockedFields(status: TournamentStatus, hasRegistrations: boolean): Set<string> {
  const locked = new Set<string>();
  switch (status) {
    case 'draft':
    case 'scheduled':
      break;
    case 'registration_open':
      STRUCTURAL_FIELDS.forEach((f) => locked.add(f));
      RULE_FIELDS.forEach((f) => locked.add(f));
      break;
    case 'registration_closed':
    case 'live':
      STRUCTURAL_FIELDS.forEach((f) => locked.add(f));
      RULE_FIELDS.forEach((f) => locked.add(f));
      SCHEDULE_FIELDS.forEach((f) => locked.add(f));
      break;
    case 'completed':
    case 'cancelled':
      [...STRUCTURAL_FIELDS, ...RULE_FIELDS, ...SCHEDULE_FIELDS, ...PRESENTATION_FIELDS].forEach((f) => locked.add(f));
      break;
  }
  if (hasRegistrations) locked.add('mode');
  return locked;
}

export interface ScheduleCheckInput {
  regOpensAt: string;
  regClosesAt: string;
  startsAt: string;
}

export function scheduleIssues(input: ScheduleCheckInput): string[] {
  const issues: string[] = [];
  const opens = Date.parse(input.regOpensAt);
  const closes = Date.parse(input.regClosesAt);
  const starts = Date.parse(input.startsAt);
  if (!(closes > opens)) issues.push('Registration must close after it opens.');
  if (!(starts >= closes)) issues.push('The tournament cannot start before registration closes.');
  return issues;
}

/**
 * Whether the tournament may be moved to `to` given its current data.
 * Returns human-readable blocking reasons; an empty array means the transition may proceed.
 */
export function transitionBlockers(input: {
  from: TournamentStatus;
  to: TournamentStatus;
  name: string;
  description: string;
  mode: string;
  capacity: number;
  scheduleIssues: string[];
  matchCount: number;
  now: Date;
  regClosesAt: string;
}): string[] {
  const reasons: string[] = [];
  if (!canTransition(input.from, input.to)) {
    reasons.push(`A tournament cannot move from ${input.from.replace('_', ' ')} to ${input.to.replace('_', ' ')}.`);
    return reasons;
  }
  if (input.to === 'scheduled') {
    if (input.name.trim().length < 3) reasons.push('Add a tournament name before publishing.');
    if (input.description.trim().length < 20) reasons.push('Add a description of at least 20 characters before publishing.');
    reasons.push(...input.scheduleIssues);
  }
  if (input.to === 'registration_open') {
    reasons.push(...input.scheduleIssues);
    // An "open" status with a closing time already in the past would show players a window that
    // registerForTournament() then refuses, so every route into registration_open checks the clock.
    if (input.now.getTime() >= Date.parse(input.regClosesAt)) {
      reasons.push(
        input.from === 'registration_closed'
          ? 'Registration cannot reopen after its closing time. Extend the closing time first.'
          : 'The registration closing time has already passed. Extend the closing time before opening registration.',
      );
    }
  }
  if (input.to === 'live') {
    if (input.matchCount < 1) reasons.push('Schedule at least one match before the tournament goes live.');
  }
  return reasons;
}
