/**
 * Creates or promotes an administrator. There is no way to become an administrator through the
 * public registration form. This command is the bootstrap path and must be run by someone with
 * access to the server and its environment.
 *
 *   ARENA_ADMIN_PASSWORD='<at least 12 characters>' npm run admin:create -- --email ops@example.com --name "ARENA Ops"
 */
import { loadConfig } from '../lib/config.ts';
import { openDatabase, transact } from '../db/index.ts';
import { hashPassword, newId } from '../lib/crypto.ts';
import { nowIso } from '../lib/clock.ts';
import { recordAudit } from '../lib/audit.ts';
import { emailSchema, displayNameSchema } from '../lib/validation.ts';
import { getRow, run } from '../db/index.ts';

function argValue(flag: string): string | undefined {
  const idx = process.argv.indexOf(flag);
  return idx === -1 ? undefined : process.argv[idx + 1];
}

const email = emailSchema.safeParse(argValue('--email'));
const name = displayNameSchema.safeParse(argValue('--name') ?? 'ARENA Admin');
const password = process.env.ARENA_ADMIN_PASSWORD ?? '';

if (!email.success) {
  console.error('Pass a valid --email address.');
  process.exit(1);
}
if (!name.success) {
  console.error('Pass a valid --name (3 to 24 characters).');
  process.exit(1);
}
if (password.length < 12) {
  console.error('Set ARENA_ADMIN_PASSWORD to at least 12 characters in the environment (it is never accepted as a command-line argument).');
  process.exit(1);
}

const config = loadConfig();
const db = openDatabase(config.dbPath);
const passwordHash = await hashPassword(password);
const existing = getRow<{ id: string; role: string }>(db, 'SELECT id, role FROM users WHERE email = ?', email.data);
const at = nowIso();

transact(db, () => {
  if (existing) {
    run(db, "UPDATE users SET role = 'admin', status = 'active', suspended_until = NULL, status_reason = NULL, password_hash = ?, updated_at = ? WHERE id = ?", passwordHash, at, existing.id);
    recordAudit(db, { actorId: null, actorRole: 'system', action: 'admin.promoted', entityType: 'user', entityId: existing.id });
    console.log(`Promoted ${email.data} to administrator and reset their password.`);
  } else {
    const id = newId();
    run(
      db,
      `INSERT INTO users (id, email, password_hash, display_name, avatar_key, role, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'titan', 'admin', 'active', ?, ?)`,
      id,
      email.data,
      passwordHash,
      name.data,
      at,
      at,
    );
    recordAudit(db, { actorId: null, actorRole: 'system', action: 'admin.created', entityType: 'user', entityId: id });
    console.log(`Created administrator ${email.data}.`);
  }
});
db.close();
