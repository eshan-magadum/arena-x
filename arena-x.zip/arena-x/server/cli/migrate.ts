import { loadConfig } from '../lib/config.ts';
import { openDatabase } from '../db/index.ts';

const config = loadConfig();
const db = openDatabase(config.dbPath);
const applied = db.prepare('SELECT version, applied_at FROM schema_migrations ORDER BY version').all() as {
  version: string;
  applied_at: string;
}[];
console.log(`Database: ${config.dbPath}`);
for (const row of applied) {
  console.log(`  ✓ ${row.version} (applied ${row.applied_at})`);
}
db.close();
