/**
 * Development seed. Uses the real service layer so every fixture obeys the same rules as user
 * data. It creates clearly labelled demo tournaments, teams and registrations, but never creates
 * competition results, prize payouts or analytics. Refuses to run in production.
 */
import { randomBytes } from 'node:crypto';
import { loadConfig } from '../lib/config.ts';
import { openDatabase, getRow, run } from '../db/index.ts';
import { hashPassword, newId } from '../lib/crypto.ts';
import { nowIso, addMinutesIso } from '../lib/clock.ts';
import { registerAccount, toViewer, type UserRow, type Viewer } from '../services/accounts.ts';
import { createTournament, transitionTournament } from '../services/tournaments.ts';
import { createTeam, inviteToTeam, respondToInvitation } from '../services/teams.ts';
import { registerForTournament } from '../services/registrations.ts';
import { recordAudit } from '../lib/audit.ts';

const config = loadConfig();
if (config.isProduction) {
  console.error('Refusing to seed demo data in production.');
  process.exit(1);
}

const db = openDatabase(config.dbPath);
const password = randomBytes(12).toString('base64url');
const adminPassword = randomBytes(12).toString('base64url');

const PLAYER_NAMES = ['Rahul Kite', 'Vikram Ash', 'Meera Frost', 'Arjun Viper', 'Kabir Nova', 'Ishaan Ghost', 'Tara Ember', 'Zoya Falcon', 'Dev Titan', 'Aisha Bolt', 'Nikhil Iron', 'Priya Storm'];

function gameId(index: number): string {
  return String(7_100_000_000 + index * 137);
}

async function main(): Promise<void> {
  // Administrator for the demo. Created directly because public registration cannot grant admin.
  const adminId = newId();
  const at = nowIso();
  run(
    db,
    `INSERT INTO users (id, email, password_hash, display_name, avatar_key, role, status, created_at, updated_at)
     VALUES (?, 'seed-admin@arena.test', ?, 'Seed Admin', 'titan', 'admin', 'active', ?, ?)`,
    adminId,
    await hashPassword(adminPassword),
    at,
    at,
  );
  recordAudit(db, { actorId: null, actorRole: 'system', action: 'seed.admin_created', entityType: 'user', entityId: adminId });
  const admin: Viewer = toViewer(getRow<UserRow>(db, 'SELECT * FROM users WHERE id = ?', adminId)!);

  const players: Viewer[] = [];
  for (let i = 0; i < PLAYER_NAMES.length; i++) {
    const viewer = await registerAccount(db, {
      email: `player${String(i + 1).padStart(2, '0')}@arena.test`,
      password,
      displayName: PLAYER_NAMES[i],
      inGameId: gameId(i + 1),
    });
    players.push(viewer);
  }

  const now = Date.now();
  const soloCup = createTournament(db, admin, {
    name: 'Dev Fixture: Weekend Solo Cup',
    description: 'Development fixture. Eight-player solo bracket used to exercise registration, scheduling and results.',
    rulesText: 'Solo entries. Lobby rules as published by the tournament operator.',
    entryRequirements: 'Valid Free Fire MAX in-game ID on your profile.',
    mode: 'solo',
    capacity: 8,
    approvalMode: 'auto',
    regOpensAt: new Date(now - 60 * 60_000).toISOString(),
    regClosesAt: addMinutesIso(new Date(now).toISOString(), 3 * 24 * 60),
    startsAt: addMinutesIso(new Date(now).toISOString(), 4 * 24 * 60),
    timezone: 'Asia/Kolkata',
    maxEntriesPerMatch: 12,
    killPoint: 1,
    placementPoints: [12, 9, 8, 7, 6, 5, 4, 3, 2, 1],
    tiebreakOrder: ['kills', 'first_places', 'best_placement'],
    prizePoolMinor: 500_000,
    prizeCurrency: 'INR',
    prizeShareBps: [5000, 3000, 2000],
    roomLeadMinutes: 15,
    coverStyle: 'ember',
  });
  transitionTournament(db, admin, soloCup.id, { to: 'scheduled' });
  transitionTournament(db, admin, soloCup.id, { to: 'registration_open' });

  const duoClash = createTournament(db, admin, {
    name: 'Dev Fixture: Duo Clash',
    description: 'Development fixture. Two-player teams with captain-led registration.',
    rulesText: 'Duo teams of exactly two players.',
    entryRequirements: 'Both teammates need an in-game ID.',
    mode: 'duo',
    capacity: 4,
    approvalMode: 'manual',
    regOpensAt: new Date(now - 60 * 60_000).toISOString(),
    regClosesAt: addMinutesIso(new Date(now).toISOString(), 5 * 24 * 60),
    startsAt: addMinutesIso(new Date(now).toISOString(), 6 * 24 * 60),
    timezone: 'Asia/Kolkata',
    maxEntriesPerMatch: 12,
    killPoint: 1,
    placementPoints: [12, 9, 8, 7, 6, 5, 4, 3, 2, 1],
    tiebreakOrder: ['kills', 'first_places', 'best_placement'],
    prizePoolMinor: 0,
    prizeCurrency: 'INR',
    prizeShareBps: [],
    roomLeadMinutes: 20,
    coverStyle: 'lime',
  });
  transitionTournament(db, admin, duoClash.id, { to: 'scheduled' });
  transitionTournament(db, admin, duoClash.id, { to: 'registration_open' });

  createTournament(db, admin, {
    name: 'Dev Fixture: Squad Showdown',
    description: 'Development fixture. Draft squad event that is not yet published to players.',
    rulesText: 'Squad teams of four.',
    entryRequirements: 'All four players need an in-game ID.',
    mode: 'squad',
    capacity: 8,
    approvalMode: 'auto',
    regOpensAt: new Date(now + 2 * 24 * 60 * 60_000).toISOString(),
    regClosesAt: new Date(now + 6 * 24 * 60 * 60_000).toISOString(),
    startsAt: new Date(now + 7 * 24 * 60 * 60_000).toISOString(),
    timezone: 'Asia/Kolkata',
    maxEntriesPerMatch: 12,
    killPoint: 1,
    placementPoints: [12, 9, 8, 7, 6, 5, 4, 3, 2, 1],
    tiebreakOrder: ['kills', 'first_places', 'best_placement'],
    prizePoolMinor: 0,
    prizeCurrency: 'INR',
    prizeShareBps: [],
    roomLeadMinutes: 20,
    coverStyle: 'steel',
  });

  // Solo registrations fill part of the solo cup.
  for (const player of players.slice(0, 5)) {
    registerForTournament(db, player, soloCup.slug, {});
  }

  // A duo team: captain forms the team, invites a teammate, both accept, then the captain registers.
  const captain = players[5]!;
  const teammate = players[6]!;
  const teamId = createTeam(db, captain, { name: 'Nova Pair', mode: 'duo' });
  const inviteId = inviteToTeam(db, captain, teamId, { email: teammate.email });
  respondToInvitation(db, teammate, inviteId, true);
  registerForTournament(db, captain, duoClash.slug, { teamId });

  console.log('');
  console.log('ARENA X development seed complete.');
  console.log(`  Tournaments: ${soloCup.name} (${soloCup.capacity} places), ${duoClash.name}, Squad Showdown (draft)`);
  console.log('  Administrator: seed-admin@arena.test');
  console.log(`  Administrator password: ${adminPassword}`);
  console.log('  Player accounts: player01@arena.test ... player12@arena.test');
  console.log(`  Player password (all players): ${password}`);
  console.log('These credentials are for local development only. Do not reuse them anywhere else.');
  db.close();
}

main().catch((error: unknown) => {
  const details = (error as { details?: unknown }).details;
  console.error('Seed failed:', (error as Error).message, details ? JSON.stringify(details) : '');
  db.close();
  process.exit(1);
});

