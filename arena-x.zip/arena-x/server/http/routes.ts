import { playerMatchHistory } from '../services/history.ts';
import { platformAnalytics } from '../services/analytics.ts';
import { getRow } from '../db/index.ts';
import { AppError, notFound, tooManyRequests, badRequest, forbidden } from '../lib/errors.ts';
import { consumeRateLimit } from '../lib/rateLimit.ts';
import { loadTournamentRow } from '../services/tournaments.ts';
import { playerStats } from '../services/results.ts';
import {
  authenticate,
  changePassword,
  createSession,
  destroySession,
  getPublicPlayer,
  getPlayerForAdmin,
  listPlayers,
  moderatePlayer,
  registerAccount,
  updateProfile,
  type SessionPolicy,
} from '../services/accounts.ts';
import {
  assignEntries,
  createMatch,
  getMatchForParticipant,
  getRoomForViewer,
  listAdminMatches,
  publishRoom,
  setRoom,
  updateMatch,
} from '../services/matches.ts';
import {
  cancelRegistration,
  decideRegistration,
  getEntryOptions,
  listRegistrations,
  registerForTournament,
} from '../services/registrations.ts';
import {
  correctApprovedResult,
  finalizeTournament,
  getStandings,
  leaderboard,
  listMySubmissions,
  listSubmissionsForReview,
  reviewSubmission,
  submitResult,
} from '../services/results.ts';
import {
  createTournament,
  getAdminTournament,
  listTournaments,
  transitionTournament,
  updateTournament,
} from '../services/tournaments.ts';
import { listPrizeAwards, updatePrizeAward } from '../services/prizes.ts';
import {
  createTeam,
  disbandTeam,
  getTeamDetail,
  inviteToTeam,
  listMyTeams,
  listTeamMessages,
  moderateTeamMessage,
  postTeamMessage,
  removeMember,
  respondToInvitation,
  revokeInvitation,
} from '../services/teams.ts';
import {
  listNotifications,
  markAllNotificationsRead,
  markNotificationRead,
  unreadCount,
} from '../services/notifications.ts';
import {
  adminDashboard,
  exportDataset,
  homeData,
  listAnnouncements,
  listAuditEvents,
  playerDashboard,
  publishAnnouncement,
  tournamentDetail,
  verifyAudit,
  EXPORT_DATASETS,
  type ExportDataset,
} from '../services/platform.ts';
import { transitionSchema, parseWith, registrationDecisionSchema } from '../lib/validation.ts';
import type { RouteDef, RequestContext, HandlerResult } from './app.ts';
import { withClearedSession, withSession, sseHandler } from './app.ts';
import { requirePermission } from '../domain/permissions.ts';
import { MODES } from '../domain/constants.ts';

/**
 * Route table. Each handler is a thin adapter: it reads the request, delegates to a service
 * (which performs authorisation and validation again) and shapes the response.
 */

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;

function policy(ctx: RequestContext): SessionPolicy {
  return { playerDays: ctx.config.playerSessionDays, adminHours: ctx.config.adminSessionHours };
}

function intParam(value: string | null, fallback: number): number {
  if (value === null || value === '') return fallback;
  const parsed = Number(value);
  if (!Number.isInteger(parsed)) throw badRequest('That value must be a whole number.');
  return parsed;
}

function bodyObject(body: unknown): Record<string, unknown> {
  if (body === undefined || body === null) return {};
  if (typeof body !== 'object' || Array.isArray(body)) throw badRequest('Send a JSON object.');
  return body as Record<string, unknown>;
}

function requireAdmin(ctx: RequestContext) {
  if (!ctx.viewer) throw new AppError(401, 'unauthorized', 'Sign in to continue.');
  requirePermission(ctx.viewer, 'tournaments:manage');
  return ctx.viewer;
}

function stripAdminCounters<T extends { pendingCount?: number }>(items: T[]): T[] {
  return items.map(({ pendingCount: _pending, ...rest }) => rest as T);
}

export function buildRoutes(): RouteDef[] {
  const routes: RouteDef[] = [];
  const add = (route: RouteDef) => routes.push(route);

  /* ---------------- Health and public reads ---------------- */

  add({
    method: 'GET',
    path: '/api/health',
    access: 'public',
    handler: (ctx) => {
      const ok = getRow<{ ok: number }>(ctx.db, 'SELECT 1 AS ok') !== undefined;
      return { json: { ok, service: 'arena-x', time: new Date().toISOString() } };
    },
  });

  add({
    method: 'GET',
    path: '/api/home',
    access: 'public',
    handler: (ctx) => ({ json: homeData(ctx.db) }),
  });

  add({
    method: 'GET',
    path: '/api/tournaments',
    access: 'public',
    handler: (ctx) => {
      const result = listTournaments(ctx.db, ctx.viewer, {
        status: ctx.query.get('status') ?? undefined,
        mode: ctx.query.get('mode') ?? undefined,
        limit: intParam(ctx.query.get('limit'), 20),
        offset: intParam(ctx.query.get('offset'), 0),
      });
      const items = ctx.viewer?.role === 'admin' ? result.items : stripAdminCounters(result.items);
      return { json: { ...result, items } };
    },
  });

  add({
    method: 'GET',
    path: '/api/tournaments/:slug',
    access: 'public',
    handler: (ctx) => ({ json: tournamentDetail(ctx.db, ctx.viewer, ctx.params.slug!) }),
  });

  add({
    method: 'GET',
    path: '/api/leaderboards',
    access: 'public',
    handler: (ctx) => {
      const scope = ctx.query.get('scope') ?? 'players';
      const mode = ctx.query.get('mode') ?? undefined;
      if (scope !== 'players' && scope !== 'teams') throw badRequest('Scope must be players or teams.');
      if (mode !== undefined && !(MODES as readonly string[]).includes(mode)) throw badRequest('Choose solo, duo or squad.');
      if (scope === 'teams' && mode === 'solo') throw badRequest('Team leaderboards are available for duo and squad only.');
      return {
        json: {
          scope,
          mode: mode ?? 'all',
          rows: leaderboard(ctx.db, scope, mode, intParam(ctx.query.get('limit'), 50)),
        },
      };
    },
  });

  add({
    method: 'GET',
    path: '/api/players/:id',
    access: 'public',
    handler: (ctx) => {
      const player = getPublicPlayer(ctx.db, ctx.params.id!);
      return { json: { player, stats: playerStats(ctx.db, player.id) } };
    },
  });

  add({
    method: 'GET',
    path: '/api/announcements',
    access: 'public',
    handler: (ctx) => ({ json: { items: listAnnouncements(ctx.db, 20) } }),
  });

  /* ---------------- Authentication ---------------- */

  add({
    method: 'POST',
    path: '/api/auth/register',
    access: 'public',
    limit: { name: 'register', max: 10, windowMs: HOUR, by: 'ip' },
    handler: async (ctx) => {
      const viewer = await registerAccount(ctx.db, ctx.body);
      const session = createSession(ctx.db, viewer.id, 'player', policy(ctx));
      return withSession({ viewer: session.viewer }, session.token, session.expiresAt, ctx.config);
    },
  });

  add({
    method: 'POST',
    path: '/api/auth/login',
    access: 'public',
    limit: { name: 'login', max: 40, windowMs: 15 * MINUTE, by: 'ip' },
    handler: async (ctx) => {
      const email = typeof bodyObject(ctx.body).email === 'string' ? String(bodyObject(ctx.body).email).trim().toLowerCase() : '';
      if (!consumeRateLimit(`login-account:${email}`, 8, 15 * MINUTE)) {
        throw tooManyRequests('Too many sign-in attempts for this account. Wait 15 minutes and try again.');
      }
      const issued = await authenticate(ctx.db, ctx.body, policy(ctx));
      return withSession({ viewer: issued.viewer }, issued.token, issued.expiresAt, ctx.config);
    },
  });

  add({
    method: 'POST',
    path: '/api/admin/auth/login',
    access: 'public',
    limit: { name: 'admin-login', max: 20, windowMs: 15 * MINUTE, by: 'ip' },
    handler: async (ctx) => {
      const email = typeof bodyObject(ctx.body).email === 'string' ? String(bodyObject(ctx.body).email).trim().toLowerCase() : '';
      if (!consumeRateLimit(`admin-login-account:${email}`, 5, 15 * MINUTE)) {
        throw tooManyRequests('Too many administrator sign-in attempts for this account. Wait 15 minutes and try again.');
      }
      const issued = await authenticate(ctx.db, ctx.body, policy(ctx));
      if (issued.viewer.role !== 'admin') {
        // A correct password for a player account is not enough: no administrator session is kept.
        destroySession(ctx.db, issued.token);
        throw forbidden('This sign-in is for administrators only.', 'not_administrator');
      }
      return withSession({ viewer: issued.viewer }, issued.token, issued.expiresAt, ctx.config);
    },
  });

  add({
    method: 'POST',
    path: '/api/auth/logout',
    access: 'public',
    allowRestricted: true,
    handler: (ctx) => {
      destroySession(ctx.db, ctx.token);
      return withClearedSession({ ok: true }, ctx.config);
    },
  });

  add({
    method: 'GET',
    path: '/api/auth/session',
    access: 'public',
    handler: (ctx) => ({
      json: { viewer: ctx.viewer, unread: ctx.viewer ? unreadCount(ctx.db, ctx.viewer.id) : 0 },
    }),
  });

  add({
    method: 'GET',
    path: '/api/me/matches',
    access: 'player',
    handler: (ctx) => ({ json: { matches: playerMatchHistory(ctx.db, ctx.viewer!) } }),
  });

  /* ---------------- Player account ---------------- */

  add({
    method: 'GET',
    path: '/api/me/dashboard',
    access: 'player',
    handler: (ctx) => ({ json: playerDashboard(ctx.db, ctx.viewer!) }),
  });

  add({
    method: 'GET',
    path: '/api/me/profile',
    access: 'player',
    handler: (ctx) => ({ json: { viewer: ctx.viewer, stats: playerStats(ctx.db, ctx.viewer!.id) } }),
  });

  add({
    method: 'PATCH',
    path: '/api/me/profile',
    access: 'player',
    handler: (ctx) => ({ json: { viewer: updateProfile(ctx.db, ctx.viewer!, ctx.body) } }),
  });

  add({
    method: 'POST',
    path: '/api/me/password',
    access: 'player',
    limit: { name: 'password-change', max: 5, windowMs: HOUR, by: 'user' },
    handler: async (ctx) => {
      await changePassword(ctx.db, ctx.viewer!, ctx.body, ctx.token ?? '');
      return { json: { ok: true, message: 'Password updated. Other signed-in devices have been signed out.' } };
    },
  });

  add({
    method: 'GET',
    path: '/api/me/notifications',
    access: 'player',
    handler: (ctx) =>
      ({
        json: listNotifications(
          ctx.db,
          ctx.viewer!.id,
          intParam(ctx.query.get('limit'), 30),
          ctx.query.get('before') ?? undefined,
        ),
      }),
  });

  add({
    method: 'POST',
    path: '/api/me/notifications/read-all',
    access: 'player',
    handler: (ctx) => ({ json: { unread: markAllNotificationsRead(ctx.db, ctx.viewer!.id) } }),
  });

  add({
    method: 'POST',
    path: '/api/me/notifications/:id/read',
    access: 'player',
    handler: (ctx) => ({ json: { unread: markNotificationRead(ctx.db, ctx.viewer!.id, ctx.params.id!) } }),
  });

  add({
    method: 'GET',
    path: '/api/stream',
    access: 'public',
    handler: (ctx): HandlerResult => sseHandler(ctx),
  });

  /* ---------------- Teams ---------------- */

  add({
    method: 'GET',
    path: '/api/teams/mine',
    access: 'player',
    handler: (ctx) => ({ json: listMyTeams(ctx.db, ctx.viewer!) }),
  });

  add({
    method: 'POST',
    path: '/api/teams',
    access: 'player',
    limit: { name: 'team-create', max: 10, windowMs: HOUR, by: 'user' },
    handler: (ctx) => {
      const teamId = createTeam(ctx.db, ctx.viewer!, ctx.body);
      return { status: 201, json: { team: getTeamDetail(ctx.db, teamId, ctx.viewer) } };
    },
  });

  add({
    method: 'GET',
    path: '/api/teams/:id',
    access: 'public',
    handler: (ctx) => ({ json: { team: getTeamDetail(ctx.db, ctx.params.id!, ctx.viewer) } }),
  });

  add({
    method: 'POST',
    path: '/api/teams/:id/invites',
    access: 'player',
    limit: { name: 'team-invite', max: 30, windowMs: HOUR, by: 'user' },
    handler: (ctx) => {
      const id = inviteToTeam(ctx.db, ctx.viewer!, ctx.params.id!, ctx.body);
      return { status: 201, json: { invitationId: id, team: getTeamDetail(ctx.db, ctx.params.id!, ctx.viewer) } };
    },
  });

  add({
    method: 'DELETE',
    path: '/api/invites/:id',
    access: 'player',
    handler: (ctx) => {
      revokeInvitation(ctx.db, ctx.viewer!, ctx.params.id!);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'POST',
    path: '/api/invites/:id/accept',
    access: 'player',
    handler: (ctx) => {
      respondToInvitation(ctx.db, ctx.viewer!, ctx.params.id!, true);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'POST',
    path: '/api/invites/:id/decline',
    access: 'player',
    handler: (ctx) => {
      respondToInvitation(ctx.db, ctx.viewer!, ctx.params.id!, false);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'DELETE',
    path: '/api/teams/:id/members/:userId',
    access: 'player',
    handler: (ctx) => {
      removeMember(ctx.db, ctx.viewer!, ctx.params.id!, ctx.params.userId!);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'DELETE',
    path: '/api/teams/:id',
    access: 'player',
    handler: (ctx) => {
      disbandTeam(ctx.db, ctx.viewer!, ctx.params.id!);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'GET',
    path: '/api/teams/:id/messages',
    access: 'player',
    handler: (ctx) =>
      ({
        json: listTeamMessages(ctx.db, ctx.viewer!, ctx.params.id!, {
          before: ctx.query.get('before') ? intParam(ctx.query.get('before'), 0) : undefined,
          limit: intParam(ctx.query.get('limit'), 40),
        }),
      }),
  });

  add({
    method: 'POST',
    path: '/api/teams/:id/messages',
    access: 'player',
    limit: { name: 'team-chat', max: 20, windowMs: MINUTE, by: 'user' },
    handler: (ctx) => ({ status: 201, json: { message: postTeamMessage(ctx.db, ctx.viewer!, ctx.params.id!, ctx.body) } }),
  });

  /* ---------------- Tournament participation ---------------- */

  add({
    method: 'GET',
    path: '/api/tournaments/:slug/entry',
    access: 'player',
    handler: (ctx) => ({ json: getEntryOptions(ctx.db, ctx.viewer!, ctx.params.slug!) }),
  });

  add({
    method: 'POST',
    path: '/api/tournaments/:slug/registrations',
    access: 'player',
    limit: { name: 'register-tournament', max: 10, windowMs: MINUTE, by: 'user' },
    handler: (ctx) => {
      const reg = registerForTournament(ctx.db, ctx.viewer!, ctx.params.slug!, ctx.body);
      return { status: 201, json: { registration: reg } };
    },
  });

  add({
    method: 'DELETE',
    path: '/api/registrations/:id',
    access: 'player',
    handler: (ctx) => ({ json: { registration: cancelRegistration(ctx.db, ctx.viewer!, ctx.params.id!) } }),
  });

  /* ---------------- Matches, rooms and results ---------------- */

  add({
    method: 'GET',
    path: '/api/matches/:id',
    access: 'player',
    handler: (ctx) => ({ json: { match: getMatchForParticipant(ctx.db, ctx.viewer!, ctx.params.id!) } }),
  });

  add({
    method: 'GET',
    path: '/api/matches/:id/room',
    access: 'player',
    handler: (ctx) => ({ json: { room: getRoomForViewer(ctx.db, ctx.viewer!, ctx.params.id!, ctx.config.secret) } }),
  });

  add({
    method: 'GET',
    path: '/api/matches/:id/results',
    access: 'player',
    handler: (ctx) => ({ json: { submissions: listMySubmissions(ctx.db, ctx.viewer!, ctx.params.id!) } }),
  });

  add({
    method: 'POST',
    path: '/api/matches/:id/results',
    access: 'player',
    limit: { name: 'submit-result', max: 10, windowMs: MINUTE, by: 'user' },
    handler: (ctx) => ({ status: 201, json: { submission: submitResult(ctx.db, ctx.viewer!, ctx.params.id!, ctx.body) } }),
  });

  /* ---------------- Administration ---------------- */

  add({
    method: 'GET',
    path: '/api/admin/analytics',
    access: 'admin',
    handler: (ctx) => ({ json: { analytics: platformAnalytics(ctx.db, requireAdmin(ctx)) } }),
  });

  add({
    method: 'GET',
    path: '/api/admin/dashboard',
    access: 'admin',
    handler: (ctx) => ({ json: adminDashboard(ctx.db, requireAdmin(ctx)) }),
  });

  add({
    method: 'GET',
    path: '/api/admin/tournaments',
    access: 'admin',
    handler: (ctx) =>
      ({
        json: listTournaments(ctx.db, requireAdmin(ctx), {
          status: ctx.query.get('status') ?? undefined,
          mode: ctx.query.get('mode') ?? undefined,
          limit: intParam(ctx.query.get('limit'), 50),
          offset: intParam(ctx.query.get('offset'), 0),
        }),
      }),
  });

  add({
    method: 'POST',
    path: '/api/admin/tournaments',
    access: 'admin',
    handler: (ctx) => ({ status: 201, json: { tournament: createTournament(ctx.db, requireAdmin(ctx), ctx.body) } }),
  });

  add({
    method: 'GET',
    path: '/api/admin/tournaments/:id',
    access: 'admin',
    handler: (ctx) => ({ json: { tournament: getAdminTournament(ctx.db, requireAdmin(ctx), ctx.params.id!) } }),
  });

  add({
    method: 'PATCH',
    path: '/api/admin/tournaments/:id',
    access: 'admin',
    handler: (ctx) => ({ json: { tournament: updateTournament(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body) } }),
  });

  add({
    method: 'POST',
    path: '/api/admin/tournaments/:id/transition',
    access: 'admin',
    handler: (ctx) => {
      const admin = requireAdmin(ctx);
      const input = parseWith(transitionSchema, ctx.body);
      if (input.to === 'completed') {
        const outcome = finalizeTournament(ctx.db, admin, ctx.params.id!);
        return {
          json: {
            finalized: true,
            tournament: getAdminTournament(ctx.db, admin, ctx.params.id!),
            standings: outcome.standings,
            prizeAwards: outcome.prizeAwards,
          },
        };
      }
      return { json: { tournament: transitionTournament(ctx.db, admin, ctx.params.id!, input) } };
    },
  });

  add({
    method: 'GET',
    path: '/api/admin/tournaments/:id/standings',
    access: 'admin',
    handler: (ctx) => {
      requireAdmin(ctx);
      const tournament = loadTournamentRow(ctx.db, ctx.params.id!);
      return { json: { standings: getStandings(ctx.db, tournament) } };
    },
  });

  add({
    method: 'GET',
    path: '/api/admin/tournaments/:id/registrations',
    access: 'admin',
    handler: (ctx) => ({
      json: { registrations: listRegistrations(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.query.get('status') ?? undefined) },
    }),
  });

  add({
    method: 'POST',
    path: '/api/admin/registrations/:id/decision',
    access: 'admin',
    handler: (ctx) => {
      const admin = requireAdmin(ctx);
      const input = parseWith(registrationDecisionSchema, ctx.body);
      return { json: { registration: decideRegistration(ctx.db, admin, ctx.params.id!, input) } };
    },
  });

  add({
    method: 'POST',
    path: '/api/admin/registrations/:id/cancel',
    access: 'admin',
    handler: (ctx) => ({ json: { registration: cancelRegistration(ctx.db, requireAdmin(ctx), ctx.params.id!) } }),
  });

  add({
    method: 'GET',
    path: '/api/admin/tournaments/:id/matches',
    access: 'admin',
    handler: (ctx) => ({ json: { matches: listAdminMatches(ctx.db, requireAdmin(ctx), ctx.params.id!) } }),
  });

  add({
    method: 'POST',
    path: '/api/admin/tournaments/:id/matches',
    access: 'admin',
    handler: (ctx) => ({ status: 201, json: { matchId: createMatch(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body) } }),
  });

  add({
    method: 'PATCH',
    path: '/api/admin/matches/:id',
    access: 'admin',
    handler: (ctx) => {
      updateMatch(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'PUT',
    path: '/api/admin/matches/:id/entries',
    access: 'admin',
    handler: (ctx) => {
      assignEntries(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'PUT',
    path: '/api/admin/matches/:id/room',
    access: 'admin',
    handler: (ctx) => {
      setRoom(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body, ctx.config.secret);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'POST',
    path: '/api/admin/matches/:id/room/publish',
    access: 'admin',
    handler: (ctx) => ({ json: { releaseAt: publishRoom(ctx.db, requireAdmin(ctx), ctx.params.id!) } }),
  });

  add({
    method: 'GET',
    path: '/api/admin/matches/:id/room',
    access: 'admin',
    handler: (ctx) => ({ json: { room: getRoomForViewer(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.config.secret) } }),
  });

  add({
    method: 'GET',
    path: '/api/admin/submissions',
    access: 'admin',
    handler: (ctx) => ({
      json: {
        submissions: listSubmissionsForReview(ctx.db, requireAdmin(ctx), {
          status: ctx.query.get('status') ?? 'pending',
          tournamentId: ctx.query.get('tournamentId') ?? undefined,
        }),
      },
    }),
  });

  add({
    method: 'POST',
    path: '/api/admin/submissions/:id/decision',
    access: 'admin',
    handler: (ctx) => ({ json: { submission: reviewSubmission(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body) } }),
  });

  add({
    method: 'POST',
    path: '/api/admin/results/:id/correct',
    access: 'admin',
    handler: (ctx) => ({ json: { submission: correctApprovedResult(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body) } }),
  });

  add({
    method: 'GET',
    path: '/api/admin/tournaments/:id/prizes',
    access: 'admin',
    handler: (ctx) => ({ json: { prizes: listPrizeAwards(ctx.db, requireAdmin(ctx), ctx.params.id!) } }),
  });

  add({
    method: 'PATCH',
    path: '/api/admin/prizes/:id',
    access: 'admin',
    handler: (ctx) => ({ json: { prizes: updatePrizeAward(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body) } }),
  });

  add({
    method: 'GET',
    path: '/api/admin/players',
    access: 'admin',
    handler: (ctx) => ({
      json: {
        players: listPlayers(ctx.db, requireAdmin(ctx), {
          q: ctx.query.get('q') ?? undefined,
          limit: intParam(ctx.query.get('limit'), 25),
          offset: intParam(ctx.query.get('offset'), 0),
        }),
      },
    }),
  });

  add({
    method: 'GET',
    path: '/api/admin/players/:id',
    access: 'admin',
    handler: (ctx) => ({ json: getPlayerForAdmin(ctx.db, requireAdmin(ctx), ctx.params.id!) }),
  });

  add({
    method: 'POST',
    path: '/api/admin/players/:id/moderation',
    access: 'admin',
    handler: (ctx) => ({ json: { result: moderatePlayer(ctx.db, requireAdmin(ctx), ctx.params.id!, ctx.body) } }),
  });

  add({
    method: 'POST',
    path: '/api/admin/chat/:messageId/remove',
    access: 'admin',
    handler: (ctx) => {
      const messageId = intParam(ctx.params.messageId!, 0);
      moderateTeamMessage(ctx.db, requireAdmin(ctx), messageId);
      return { json: { ok: true } };
    },
  });

  add({
    method: 'GET',
    path: '/api/admin/announcements',
    access: 'admin',
    handler: (ctx) => ({ json: { items: listAnnouncements(ctx.db, 50) } }),
  });

  add({
    method: 'POST',
    path: '/api/admin/announcements',
    access: 'admin',
    handler: (ctx) => ({ status: 201, json: { announcement: publishAnnouncement(ctx.db, requireAdmin(ctx), ctx.body) } }),
  });

  add({
    method: 'GET',
    path: '/api/admin/audit',
    access: 'admin',
    handler: (ctx) =>
      ({
        json: listAuditEvents(ctx.db, requireAdmin(ctx), {
          before: ctx.query.get('before') ? intParam(ctx.query.get('before'), 0) : undefined,
          limit: intParam(ctx.query.get('limit'), 50),
          entityType: ctx.query.get('entityType') ?? undefined,
        }),
      }),
  });

  add({
    method: 'GET',
    path: '/api/admin/audit/verify',
    access: 'admin',
    handler: (ctx) => ({ json: verifyAudit(ctx.db, requireAdmin(ctx)) }),
  });

  add({
    method: 'GET',
    path: '/api/admin/export/:dataset',
    access: 'admin',
    handler: (ctx) => {
      const admin = requireAdmin(ctx);
      const dataset = ctx.params.dataset as ExportDataset;
      if (!(EXPORT_DATASETS as readonly string[]).includes(dataset)) throw notFound('That export does not exist.');
      const result = exportDataset(ctx.db, admin, dataset, ctx.query.get('tournamentId') ?? undefined);
      return {
        raw: {
          contentType: 'text/csv; charset=utf-8',
          body: result.csv,
          headers: { 'Content-Disposition': `attachment; filename="${result.filename}"` },
        },
      };
    },
  });

  return routes;
}

