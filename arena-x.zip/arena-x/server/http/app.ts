import http from 'node:http';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { randomUUID } from 'node:crypto';
import type { Db } from '../db/index.ts';
import type { AppConfig } from '../lib/config.ts';
import { AppError } from '../lib/errors.ts';
import { consumeRateLimit } from '../lib/rateLimit.ts';
import { resolveSession, type Viewer } from '../services/accounts.ts';
import { publishBroadcast, subscribeToBroadcast, subscribeToUser, type AppEvent } from '../lib/events.ts';

const PUBLIC_WRITE_PREFIXES = ['/api/admin/', '/api/tournaments', '/api/matches/', '/api/registrations/'];
import { log } from '../lib/log.ts';

/**
 * Minimal HTTP application layer built on node:http.
 *   - Route table with access levels: public, player (signed in) and admin.
 *   - CSRF defence: state-changing requests must carry a custom header that a cross-site form
 *     cannot send, and an Origin header (when present) must match the host.
 *   - Strict JSON bodies with a size limit; unknown fields are rejected by the validators.
 *   - Consistent error envelope: { error: { code, message, details? } }.
 *   - Security headers on every response, and no-store caching for API responses.
 */

export const SESSION_COOKIE = 'arenax_session';
export const CSRF_HEADER = 'x-arena-request';
const BODY_LIMIT_BYTES = 64 * 1024;

export type Access = 'public' | 'player' | 'admin';

export interface RequestContext {
  method: string;
  path: string;
  params: Record<string, string>;
  query: URLSearchParams;
  body: unknown;
  viewer: Viewer | null;
  token: string | null;
  ip: string;
  requestId: string;
  db: Db;
  config: AppConfig;
}

export type HandlerResult =
  | { status?: number; json?: unknown; headers?: Record<string, string>; cookies?: string[] }
  | { raw: { contentType: string; body: string; headers?: Record<string, string> } }
  | { stream: (res: http.ServerResponse, req: http.IncomingMessage) => void };

export type Handler = (ctx: RequestContext) => HandlerResult | Promise<HandlerResult>;

export interface RouteDef {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  access: Access;
  handler: Handler;
  /** Allow the route to run for accounts that are currently suspended or banned (e.g. logout). */
  allowRestricted?: boolean;
  /** Optional abuse control applied before the handler runs. */
  limit?: { name: string; max: number; windowMs: number; by: 'ip' | 'user' };
  parseBody?: boolean;
}

interface CompiledRoute extends RouteDef {
  segments: string[];
}

function compile(route: RouteDef): CompiledRoute {
  return { ...route, segments: route.path.split('/').filter(Boolean) };
}

function matchRoute(routes: CompiledRoute[], method: string, pathname: string): { route?: CompiledRoute; params: Record<string, string>; pathExists: boolean } {
  const parts = pathname.split('/').filter(Boolean);
  let pathExists = false;
  for (const route of routes) {
    if (route.segments.length !== parts.length) continue;
    const params: Record<string, string> = {};
    let ok = true;
    for (let i = 0; i < parts.length; i++) {
      const seg = route.segments[i]!;
      if (seg.startsWith(':')) {
        try {
          params[seg.slice(1)] = decodeURIComponent(parts[i]!);
        } catch {
          ok = false;
          break;
        }
      } else if (seg !== parts[i]) {
        ok = false;
        break;
      }
    }
    if (!ok) continue;
    pathExists = true;
    if (route.method === method) return { route, params, pathExists };
  }
  return { params: {}, pathExists };
}

function parseCookies(header: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    if (!key) continue;
    try {
      out[key] = decodeURIComponent(part.slice(idx + 1).trim());
    } catch {
      out[key] = '';
    }
  }
  return out;
}

export function sessionCookie(token: string, expiresAt: string, config: AppConfig): string {
  const maxAge = Math.max(0, Math.floor((Date.parse(expiresAt) - Date.now()) / 1000));
  return [
    `${SESSION_COOKIE}=${encodeURIComponent(token)}`,
    'Path=/',
    `Max-Age=${maxAge}`,
    'HttpOnly',
    'SameSite=Lax',
    config.isProduction ? 'Secure' : '',
  ]
    .filter(Boolean)
    .join('; ');
}

export function clearSessionCookie(config: AppConfig): string {
  return [`${SESSION_COOKIE}=`, 'Path=/', 'Max-Age=0', 'HttpOnly', 'SameSite=Lax', config.isProduction ? 'Secure' : '']
    .filter(Boolean)
    .join('; ');
}

const SECURITY_HEADERS: Record<string, string> = {
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
};

class BodyError extends AppError {}

function readBody(req: http.IncomingMessage): Promise<string> {
  return new Promise((resolveBody, rejectBody) => {
    let size = 0;
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size > BODY_LIMIT_BYTES) {
        rejectBody(new BodyError(413, 'payload_too_large', 'That request is too large.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolveBody(Buffer.concat(chunks).toString('utf8')));
    req.on('error', () => rejectBody(new BodyError(400, 'bad_request', 'The request could not be read.')));
  });
}

function sendJson(res: http.ServerResponse, status: number, body: unknown, extraHeaders: Record<string, string> = {}): void {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
    ...extraHeaders,
  });
  res.end(payload);
}

function sendError(res: http.ServerResponse, error: unknown, requestId: string): number {
  if (error instanceof AppError) {
    sendJson(res, error.status, {
      error: { code: error.code, message: error.message, details: error.details ?? null, requestId },
    });
    return error.status;
  }
  log('error', 'unhandled_error', { requestId, message: (error as Error).message });
  sendJson(res, 500, { error: { code: 'internal_error', message: 'Something went wrong on our side. Please try again.', requestId } });
  return 500;
}

/** A malformed Origin (for example the literal "null") is a mismatch, never a server error. */
function originMatchesHost(origin: string, host: string | undefined): boolean {
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

function clientIp(req: http.IncomingMessage): string {
  return req.socket.remoteAddress ?? 'unknown';
}

function serveStatic(config: AppConfig, pathname: string, res: http.ServerResponse): void {
  const root = resolve(config.publicDir);
  const requested = normalize(decodeURIComponent(pathname)).replace(/^([/\\])+/, '');
  const candidate = resolve(join(root, requested));
  const inside = candidate === root || candidate.startsWith(root + sep);
  let target = inside ? candidate : join(root, 'index.html');
  if (!inside || !existsSync(target) || !statSync(target).isFile()) {
    target = join(root, 'index.html');
  }
  if (!existsSync(target)) {
    res.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('The web application has not been built yet. Run "npm run build:web".');
    return;
  }
  const isHashedAsset = target.includes(`${sep}assets${sep}`);
  res.writeHead(200, {
    'Content-Type': MIME[extname(target)] ?? 'application/octet-stream',
    'Cache-Control': isHashedAsset ? 'public, max-age=31536000, immutable' : 'no-cache',
    ...SECURITY_HEADERS,
  });
  createReadStream(target).pipe(res);
}

export function sseHandler(ctx: RequestContext): HandlerResult {
  return {
    stream: (res, req) => {
      const viewer = ctx.viewer;
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-store',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no',
        ...SECURITY_HEADERS,
      });
      res.write(`event: ready\ndata: ${JSON.stringify({ userId: viewer?.id ?? null })}\n\n`);
      const write = (event: AppEvent) => {
        res.write(`event: ${event.type}\ndata: ${JSON.stringify(event.data)}\n\n`);
      };
      const unsubscribers = [subscribeToBroadcast(write)];
      if (viewer) unsubscribers.push(subscribeToUser(viewer.id, write));
      const heartbeat = setInterval(() => res.write(': keep-alive\n\n'), 25_000);
      heartbeat.unref();
      req.on('close', () => {
        clearInterval(heartbeat);
        for (const unsubscribe of unsubscribers) unsubscribe();
      });
    },
  };
}

export function createHttpApp(deps: { db: Db; config: AppConfig; routes: RouteDef[] }): http.Server {
  const routes = deps.routes.map(compile);
  const { db, config } = deps;

  const server = http.createServer(async (req, res) => {
    const requestId = randomUUID();
    const started = performance.now();
    for (const [name, value] of Object.entries(SECURITY_HEADERS)) res.setHeader(name, value);
    res.setHeader('X-Request-Id', requestId);

    const url = new URL(req.url ?? '/', 'http://localhost');
    const pathname = url.pathname;
    const method = (req.method ?? 'GET').toUpperCase();
    let status = 200;

    try {
      if (!pathname.startsWith('/api/')) {
        if (method !== 'GET' && method !== 'HEAD') {
          status = 405;
          res.writeHead(405, { Allow: 'GET, HEAD' });
          res.end();
          return;
        }
        serveStatic(config, pathname, res);
        status = 200;
        return;
      }

      const match = matchRoute(routes, method, pathname);
      if (!match.route) {
        status = match.pathExists ? 405 : 404;
        sendJson(res, status, { error: { code: status === 405 ? 'method_not_allowed' : 'not_found', message: 'No such endpoint.', requestId } });
        return;
      }
      const route = match.route;

      // Cross-site request forgery defences for state-changing requests.
      if (method !== 'GET' && method !== 'HEAD') {
        if (req.headers[CSRF_HEADER] !== '1') {
          throw new AppError(403, 'csrf_header_missing', 'This request was blocked for your protection. Refresh the page and try again.');
        }
        const origin = req.headers.origin;
        if (origin !== undefined && !originMatchesHost(origin, req.headers.host)) {
          throw new AppError(403, 'origin_mismatch', 'This request was blocked for your protection.');
        }
      }

      const cookies = parseCookies(req.headers.cookie);
      const token = cookies[SESSION_COOKIE] ?? null;
      const viewer = resolveSession(db, token);

      if (route.access !== 'public' && !viewer) {
        throw new AppError(401, 'unauthorized', 'Sign in to continue.');
      }
      if (route.access === 'admin' && viewer?.role !== 'admin') {
        throw new AppError(403, 'permission_denied', 'You do not have permission to open this page.');
      }
      if (viewer?.restriction && method !== 'GET' && !route.allowRestricted) {
        throw new AppError(403, 'account_restricted', 'Your account is restricted, so this action is unavailable.');
      }

      const ip = clientIp(req);
      if (route.limit) {
        const who = route.limit.by === 'user' && viewer ? viewer.id : ip;
        if (!consumeRateLimit(`${route.limit.name}:${who}`, route.limit.max, route.limit.windowMs)) {
          throw new AppError(429, 'rate_limited', 'You are doing that too often. Please wait a moment and try again.');
        }
      }

      let body: unknown = undefined;
      if (route.parseBody !== false && (method === 'POST' || method === 'PUT' || method === 'PATCH' || method === 'DELETE')) {
        const raw = await readBody(req);
        if (raw.trim().length > 0) {
          const contentType = req.headers['content-type'] ?? '';
          if (!contentType.includes('application/json')) {
            throw new AppError(415, 'unsupported_media_type', 'Send the request as JSON.');
          }
          try {
            body = JSON.parse(raw);
          } catch {
            throw new AppError(400, 'invalid_json', 'The request body is not valid JSON.');
          }
        }
      }

      const ctx: RequestContext = {
        method,
        path: pathname,
        params: match.params,
        query: url.searchParams,
        body,
        viewer,
        token,
        ip,
        requestId,
        db,
        config,
      };
      const result = await route.handler(ctx);

      // Public pages (tournaments, registrations, matches, standings) refetch when anything in those
      // areas changes. The hint carries no identifiers, so it reveals nothing a guest cannot already read.
      if (method !== 'GET' && PUBLIC_WRITE_PREFIXES.some((prefix) => pathname.startsWith(prefix))) {
        publishBroadcast({ type: 'tournament', data: { changed: true } });
      }

      if ('stream' in result) {
        status = 200;
        result.stream(res, req);
        return;
      }
      if ('raw' in result) {
        status = 200;
        res.writeHead(200, {
          'Content-Type': result.raw.contentType,
          'Cache-Control': 'no-store',
          ...(result.raw.headers ?? {}),
        });
        res.end(result.raw.body);
        return;
      }
      status = result.status ?? 200;
      const headers: Record<string, string> = { ...(result.headers ?? {}) };
      if (result.cookies?.length) {
        res.setHeader('Set-Cookie', result.cookies);
      }
      sendJson(res, status, result.json ?? { ok: true }, headers);
    } catch (error) {
      status = sendError(res, error, requestId);
    } finally {
      if (pathname.startsWith('/api/')) {
        log('info', 'request', {
          requestId,
          method,
          path: pathname.replace(/[0-9a-f-]{36}/gi, ':id'),
          status,
          ms: Math.round(performance.now() - started),
        });
      }
    }
  });
  server.requestTimeout = 30_000;
  server.headersTimeout = 35_000;
  return server;
}

/** Shared result helper: attaches a session cookie to a JSON response. */
export function withSession(json: unknown, token: string, expiresAt: string, config: AppConfig): HandlerResult {
  return { json, cookies: [sessionCookie(token, expiresAt, config)] };
}

export function withClearedSession(json: unknown, config: AppConfig): HandlerResult {
  return { json, cookies: [clearSessionCookie(config)] };
}
