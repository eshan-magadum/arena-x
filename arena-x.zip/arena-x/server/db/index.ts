import { readdirSync, readFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

export type Db = DatabaseSync;

const MIGRATIONS_DIR = join(dirname(fileURLToPath(import.meta.url)), 'migrations');

/**
 * Opens (creating if necessary) the SQLite database, applies pragmas and runs pending migrations.
 * WAL mode lets reads proceed while a write transaction is open; busy_timeout makes concurrent
 * processes wait for the write lock instead of failing immediately.
 */
export function openDatabase(path: string): Db {
  if (path !== ':memory:') {
    mkdirSync(dirname(path), { recursive: true });
  }
  const db = new DatabaseSync(path);
  db.exec(`
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 10000;
    PRAGMA synchronous = NORMAL;
  `);
  if (path !== ':memory:') {
    db.exec('PRAGMA journal_mode = WAL;');
  }
  migrate(db);
  return db;
}

export function migrate(db: Db): string[] {
  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version    TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL
    );
  `);
  const applied = new Set(
    (db.prepare('SELECT version FROM schema_migrations').all() as { version: string }[]).map((r) => r.version),
  );
  const files = readdirSync(MIGRATIONS_DIR)
    .filter((f) => f.endsWith('.sql'))
    .sort();
  const newlyApplied: string[] = [];
  for (const file of files) {
    if (applied.has(file)) continue;
    const sql = readFileSync(join(MIGRATIONS_DIR, file), 'utf8');
    db.exec('BEGIN IMMEDIATE');
    try {
      db.exec(sql);
      db.prepare('INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)').run(
        file,
        new Date().toISOString(),
      );
      db.exec('COMMIT');
      newlyApplied.push(file);
    } catch (error) {
      db.exec('ROLLBACK');
      throw new Error(`Migration ${file} failed: ${(error as Error).message}`);
    }
  }
  return newlyApplied;
}

/** Transaction nesting depth, tracked per connection so independent databases never interfere. */
const depthByConnection = new WeakMap<Db, number>();

/**
 * Runs `fn` inside a write transaction. BEGIN IMMEDIATE takes the database write lock up front,
 * so read-check-write sequences (capacity counts, duplicate checks, state transitions) cannot
 * interleave with other writers. Nested calls become savepoints.
 */
export function transact<T>(db: Db, fn: () => T): T {
  const depth = depthByConnection.get(db) ?? 0;
  if (depth > 0) {
    const name = `sp_${depth}`;
    db.exec(`SAVEPOINT ${name}`);
    depthByConnection.set(db, depth + 1);
    try {
      const result = fn();
      depthByConnection.set(db, depth);
      db.exec(`RELEASE ${name}`);
      return result;
    } catch (error) {
      depthByConnection.set(db, depth);
      db.exec(`ROLLBACK TO ${name}`);
      db.exec(`RELEASE ${name}`);
      throw error;
    }
  }
  db.exec('BEGIN IMMEDIATE');
  depthByConnection.set(db, 1);
  try {
    const result = fn();
    depthByConnection.set(db, 0);
    db.exec('COMMIT');
    return result;
  } catch (error) {
    depthByConnection.set(db, 0);
    try {
      db.exec('ROLLBACK');
    } catch {
      // The transaction may already be closed by SQLite after a fatal error.
    }
    throw error;
  }
}

/** Typed single-row query helper. Returns undefined when no row matches. */
export function getRow<T>(db: Db, sql: string, ...params: SqlValue[]): T | undefined {
  return db.prepare(sql).get(...params) as T | undefined;
}

export function getRows<T>(db: Db, sql: string, ...params: SqlValue[]): T[] {
  return db.prepare(sql).all(...params) as T[];
}

export function run(db: Db, sql: string, ...params: SqlValue[]): { changes: number; lastInsertRowid: number } {
  const result = db.prepare(sql).run(...params);
  return { changes: Number(result.changes), lastInsertRowid: Number(result.lastInsertRowid) };
}

export type SqlValue = string | number | null | bigint | Uint8Array;
