/**
 * Builds the React client into public/. Output file names carry a content hash, so the server's
 * long-lived caching for /assets/ can never serve a stale bundle after a rebuild.
 */
import { build } from 'esbuild';
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const publicDir = join(root, 'public');
const assetsDir = join(publicDir, 'assets');

// Remove previous output so stale hashed files never accumulate.
await rm(assetsDir, { recursive: true, force: true });
await mkdir(assetsDir, { recursive: true });

const result = await build({
  entryPoints: [join(root, 'web/src/main.tsx')],
  outdir: assetsDir,
  entryNames: 'app-[hash]',
  bundle: true,
  format: 'esm',
  target: ['es2022'],
  jsx: 'automatic',
  minify: true,
  sourcemap: false,
  legalComments: 'none',
  metafile: true,
  logLevel: 'warning',
  define: {
    'process.env.NODE_ENV': '"production"',
  },
  loader: {
    '.svg': 'text',
  },
});

const outputs = Object.keys(result.metafile.outputs).map((file) => file.split(/[\\/]/).pop());
const script = outputs.find((name) => name?.endsWith('.js'));
const style = outputs.find((name) => name?.endsWith('.css'));
if (!script) throw new Error('The client build did not produce a script bundle.');

const template = await readFile(join(root, 'web/index.html'), 'utf8');
const tags = [
  style ? `<link rel="stylesheet" href="/assets/${style}" />` : '',
  `<script type="module" src="/assets/${script}"></script>`,
]
  .filter(Boolean)
  .join('\n    ');
const html = template.replace('<!--ARENA_ASSETS-->', tags);
if (html === template) throw new Error('web/index.html is missing the <!--ARENA_ASSETS--> placeholder.');
await writeFile(join(publicDir, 'index.html'), html, 'utf8');

const sizes = await Promise.all(
  outputs.map(async (name) => {
    const path = join(assetsDir, name);
    return `${name} ${existsSync(path) ? `${Math.round((await readFile(path)).length / 1024)} KB` : ''}`;
  }),
);
console.log(`Client built: ${sizes.join(', ')}`);
console.log(`Wrote ${join('public', 'index.html')}`);
