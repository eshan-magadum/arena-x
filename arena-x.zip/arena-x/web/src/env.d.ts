/// <reference types="node" />

// esbuild bundles stylesheets imported from TypeScript. This declaration tells the type checker they exist.
declare module '*.css';
