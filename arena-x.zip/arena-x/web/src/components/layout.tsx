import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Link, useRouter } from '../lib/router.tsx';
import { useSession, useLiveEvent } from '../lib/session.tsx';
import { api, errorMessage } from '../lib/api.ts';
import { formatDateTime, safeInternalPath } from '../lib/format.ts';
import type { Notification } from '../lib/types.ts';
import { Avatar, LiveRegion } from './ui.tsx';

export function Shell({ children }: { children: ReactNode }) {
  const { location } = useRouter();
  const { viewer, unread } = useSession();
  const isAdminArea = location.pathname.startsWith('/admin');

  // Move focus to the page heading region after each route change so screen-reader users hear the new page.
  // The first load keeps focus at the top of the document so Tab reaches the skip link first.
  const firstRender = useRef(true);
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    document.getElementById('main')?.focus({ preventScroll: true });
  }, [location.pathname]);

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <Header pathname={location.pathname} isAdmin={viewer?.role === 'admin'} signedIn={Boolean(viewer)} unread={unread} />
      <main id="main" tabIndex={-1} style={{ outline: 'none' }} className={isAdminArea ? '' : 'route-enter'}>
        {children}
      </main>
      {isAdminArea ? null : <Footer />}
      <LiveRegion />
    </>
  );
}

function Header({ pathname, isAdmin, signedIn, unread }: { pathname: string; isAdmin: boolean; signedIn: boolean; unread: number }) {
  const { viewer } = useSession();
  const links: Array<{ to: string; label: string }> = [
    { to: '/tournaments', label: 'Tournaments' },
    { to: '/leaderboards', label: 'Leaderboards' },
  ];
  if (signedIn) {
    links.push({ to: '/dashboard', label: 'Dashboard' });
    links.push({ to: '/teams', label: 'Teams' });
  }
  return (
    <header className="site-header">
      <div className="container site-header__inner">
        <Link to="/" className="wordmark" aria-label="ARENA X home">
          <span className="wordmark__x" aria-hidden="true">
            X
          </span>
          <span>Arena</span>
        </Link>
        <nav className="nav" aria-label="Primary">
          {links.map((item) => (
            <Link key={item.to} to={item.to} aria-current={isCurrent(pathname, item.to) ? 'page' : undefined}>
              {item.label}
            </Link>
          ))}
          {isAdmin ? (
            <Link to="/admin" aria-current={pathname.startsWith('/admin') ? 'page' : undefined}>
              Admin
            </Link>
          ) : null}
        </nav>
        <div className="header-actions">
          {signedIn ? (
            <>
              <NotificationBell unread={unread} />
              <AccountMenu name={viewer?.displayName ?? 'Account'} avatarKey={viewer?.avatarKey ?? 'titan'} isAdmin={isAdmin} />
            </>
          ) : (
            <>
              <Link to="/login" className="btn btn--ghost btn--sm">
                Sign in
              </Link>
              <Link to="/register" className="btn btn--primary btn--sm">
                Create account
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

function isCurrent(pathname: string, to: string): boolean {
  return pathname === to || (to !== '/' && pathname.startsWith(`${to}/`));
}

function useOutsideClose(open: boolean, close: () => void) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDown = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) close();
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') close();
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [open, close]);
  return ref;
}

function NotificationBell({ unread }: { unread: number }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notification[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { navigate } = useRouter();
  const { refresh } = useSession();
  const close = () => setOpen(false);
  const ref = useOutsideClose(open, close);

  const load = () => {
    setError(null);
    api<{ items: Notification[] }>('GET', '/api/me/notifications?limit=6')
      .then((data) => setItems(data.items))
      .catch((err: unknown) => setError(errorMessage(err)));
  };

  useLiveEvent(['notification'], () => {
    if (open) load();
  });

  const toggle = () => {
    const next = !open;
    setOpen(next);
    if (next) load();
  };

  const markRead = async (item: Notification) => {
    if (!item.read) {
      await api('POST', `/api/me/notifications/${encodeURIComponent(item.id)}/read`).catch(() => undefined);
      await refresh();
      load();
    }
    const target = safeInternalPath(item.link);
    if (target) {
      setOpen(false);
      navigate(target);
    }
  };

  return (
    <div className="menu" ref={ref}>
      <button
        type="button"
        className="bell"
        aria-label={unread > 0 ? `Notifications, ${unread} unread` : 'Notifications'}
        aria-expanded={open}
        aria-haspopup="true"
        onClick={toggle}
      >
        <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
          <path
            d="M12 3a6 6 0 0 0-6 6v3.5L4.3 15.2A1 1 0 0 0 5.1 17h13.8a1 1 0 0 0 .8-1.8L18 12.5V9a6 6 0 0 0-6-6Zm-2.5 16a2.5 2.5 0 0 0 5 0"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
        </svg>
        {unread > 0 ? <span className="bell__count">{unread > 99 ? '99+' : unread}</span> : null}
      </button>
      {open ? (
        <div className="menu__panel" role="region" aria-label="Recent notifications">
          {error ? <p className="small" style={{ padding: '0.5rem' }}>{error}</p> : null}
          {items === null && !error ? <p className="small" style={{ padding: '0.5rem' }}>Loading…</p> : null}
          {items && items.length === 0 ? <p className="small" style={{ padding: '0.5rem' }}>Nothing new yet.</p> : null}
          {items?.map((item) => (
            <button
              key={item.id}
              type="button"
              className={`menu__item${item.read ? '' : ' menu__item--unread'}`}
              onClick={() => void markRead(item)}
            >
              <span className="menu__title">{item.title}</span>
              <span className="menu__body">{item.body}</span>
              <span className="menu__body faint">{formatDateTime(item.createdAt)}</span>
            </button>
          ))}
          <Link to="/notifications" className="menu__item" onClick={() => setOpen(false)}>
            <span className="menu__title">All notifications</span>
          </Link>
        </div>
      ) : null}
    </div>
  );
}

function AccountMenu({ name, avatarKey, isAdmin }: { name: string; avatarKey: string; isAdmin: boolean }) {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  const ref = useOutsideClose(open, close);
  const { signOut } = useSession();
  const { navigate } = useRouter();
  const [busy, setBusy] = useState(false);

  const logout = async () => {
    setBusy(true);
    try {
      await signOut();
    } finally {
      setBusy(false);
      setOpen(false);
      navigate('/', { replace: true });
    }
  };

  return (
    <div className="menu" ref={ref}>
      <button type="button" className="chip" aria-haspopup="true" aria-expanded={open} onClick={() => setOpen(!open)}>
        <Avatar avatarKey={avatarKey} size="sm" />
        <span className="chip__name">{name}</span>
      </button>
      {open ? (
        <div className="menu__panel" role="menu" aria-label="Account">
          <Link to="/dashboard" className="menu__item" role="menuitem" onClick={close}>
            Dashboard
          </Link>
          <Link to="/profile" className="menu__item" role="menuitem" onClick={close}>
            Profile and security
          </Link>
          <Link to="/teams" className="menu__item" role="menuitem" onClick={close}>
            Teams
          </Link>
          <Link to="/history" className="menu__item" role="menuitem" onClick={close}>
            Match history
          </Link>
          {isAdmin ? (
            <Link to="/admin" className="menu__item" role="menuitem" onClick={close}>
              Admin portal
            </Link>
          ) : null}
          <button type="button" className="menu__item" role="menuitem" onClick={() => void logout()} disabled={busy}>
            {busy ? 'Signing out…' : 'Sign out'}
          </button>
        </div>
      ) : null}
    </div>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer__grid">
          <div>
            <Link to="/" className="wordmark" style={{ fontSize: '1.2rem' }}>
              <span className="wordmark__x" aria-hidden="true">
                X
              </span>
              <span>Arena</span>
            </Link>
            <p className="small" style={{ marginTop: 12, maxWidth: '36ch' }}>
              Independent tournament operations for Free Fire MAX players. Results are verified before they count.
            </p>
          </div>
          <div>
            <span className="eyebrow">Compete</span>
            <Link to="/tournaments">Tournaments</Link>
            <Link to="/leaderboards">Leaderboards</Link>
          </div>
          <div>
            <span className="eyebrow">Account</span>
            <Link to="/register">Create account</Link>
            <Link to="/login">Sign in</Link>
          </div>
          <div>
            <span className="eyebrow">Policy</span>
            <Link to="/legal">Rules, data and fair play</Link>
          </div>
        </div>
        <p className="footer__legal">
          ARENA X is an independent platform. It is not affiliated with, endorsed by, or sponsored by the makers of Free Fire MAX,
          and it does not process payments. Prize records track what the operator has delivered outside the app.
        </p>
      </div>
    </footer>
  );
}
