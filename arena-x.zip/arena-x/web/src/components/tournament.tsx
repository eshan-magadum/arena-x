import { useMemo, useState, type FormEvent } from 'react';
import { api, errorMessage, fieldErrors } from '../lib/api.ts';
import { formatDateTime, formatMoney, formatZoneLabel, isoToZonedLocal, label, zonedLocalToIso } from '../lib/format.ts';
import { Link } from '../lib/router.tsx';
import type { TournamentRecord } from '../lib/types.ts';
import { Field, Notice, StatusBadge } from './ui.tsx';

const TIEBREAK_LABELS: Record<string, string> = {
  kills: 'Total kills',
  first_places: 'Number of first places',
  best_placement: 'Best single placement',
};

export function TournamentCard({ tournament: t, linkTo }: { tournament: TournamentRecord; linkTo?: string }) {
  const percent = t.capacity > 0 ? Math.min(100, Math.round((t.confirmedCount / t.capacity) * 100)) : 0;
  return (
    <Link to={linkTo ?? `/tournaments/${t.slug}`} className="t-card">
      <span className={`t-card__art cover--${t.coverStyle}`} aria-hidden="true" />
      <div className="t-card__body">
        <div className="row row--between" style={{ alignItems: 'flex-start' }}>
          <StatusBadge status={t.status} />
          <span className="badge">{label(t.mode)}</span>
        </div>
        <h3 className="t-card__title">{t.name}</h3>
        <div className="t-card__meta">
          <span>Starts {formatDateTime(t.startsAt, t.timezone)}</span>
          <span>{formatZoneLabel(t.timezone)}</span>
        </div>
        <p className="small" style={{ margin: 0, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
          {t.description}
        </p>
      </div>
      <div className="t-card__foot">
        <div style={{ display: 'grid', gap: 6, minWidth: 0, flex: 1 }}>
          <span className="num">
            {t.confirmedCount} / {t.capacity} places confirmed
          </span>
          <div className="meter" aria-hidden="true">
            <span style={{ width: `${percent}%` }} />
          </div>
        </div>
        {t.prize.poolMinor > 0 ? (
          <span className="num" style={{ color: 'var(--text)', fontWeight: 600 }}>
            {formatMoney(t.prize.poolMinor, t.prize.currency)}
          </span>
        ) : (
          <span className="faint">No prize pool</span>
        )}
      </div>
    </Link>
  );
}

export function ScoringSummary({ t }: { t: TournamentRecord }) {
  const placements = t.scoring.placementPoints;
  return (
    <dl className="kv">
      <dt>Kill points</dt>
      <dd className="num">{t.scoring.killPoint} per elimination</dd>
      <dt>Placement points</dt>
      <dd className="num">
        {placements.map((points, index) => `${index + 1}: ${points}`).join(' · ')}
        {placements.length > 0 ? ' · beyond that, 0' : ''}
      </dd>
      <dt>Tie-breakers</dt>
      <dd>
        {t.scoring.tiebreakOrder.length
          ? t.scoring.tiebreakOrder.map((key, i) => `${i + 1}. ${TIEBREAK_LABELS[key] ?? key}`).join('  ')
          : 'None configured. Ties share a rank.'}
      </dd>
      <dt>Scoring version</dt>
      <dd className="num">v{t.scoring.version}</dd>
    </dl>
  );
}

export function PrizeTable({ t }: { t: TournamentRecord }) {
  if (t.prize.poolMinor <= 0) {
    return <p className="muted">No prize pool is listed for this tournament.</p>;
  }
  return (
    <div className="table-wrap">
      <table className="data">
        <thead>
          <tr>
            <th scope="col">Placement</th>
            <th scope="col" className="num">
              Share
            </th>
            <th scope="col" className="num">
              Amount
            </th>
          </tr>
        </thead>
        <tbody>
          {t.prize.shares.map((share) => (
            <tr key={share.placement}>
              <td>{share.placement === 1 ? '1st' : share.placement === 2 ? '2nd' : share.placement === 3 ? '3rd' : `${share.placement}th`}</td>
              <td className="num">{(share.basisPoints / 100).toFixed(share.basisPoints % 100 === 0 ? 0 : 2)}%</td>
              <td className="num">{formatMoney(share.amountMinor, t.prize.currency)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {t.prize.unallocatedMinor > 0 ? (
        <p className="small" style={{ marginTop: 10 }}>
          {formatMoney(t.prize.unallocatedMinor, t.prize.currency)} of the pool is not allocated to a placement.
        </p>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Create and edit form                                               */
/* ------------------------------------------------------------------ */

interface FormValues {
  name: string;
  description: string;
  rulesText: string;
  entryRequirements: string;
  mode: string;
  capacity: string;
  approvalMode: string;
  timezone: string;
  regOpensAt: string;
  regClosesAt: string;
  startsAt: string;
  maxEntriesPerMatch: string;
  killPoint: string;
  placementPoints: string;
  tiebreakKeys: string[];
  prizePoolMajor: string;
  prizeCurrency: string;
  prizeSharePercent: string;
  roomLeadMinutes: string;
  coverStyle: string;
}

const DEFAULT_TIEBREAK = ['kills', 'first_places', 'best_placement'];

/** Canonical zone names the browser offers. Aliases such as Asia/Kolkata are added where needed. */
function supportedZones(): string[] {
  try {
    return Intl.supportedValuesOf('timeZone');
  } catch {
    return ['UTC'];
  }
}

function browserZone(): string {
  const zones = supportedZones();
  const zone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  if (zone && zones.includes(zone)) return zone;
  return zones.find((z) => z === 'Asia/Kolkata' || z === 'Asia/Calcutta') ?? zones[0] ?? 'UTC';
}

function valuesFromRecord(t: TournamentRecord): FormValues {
  return {
    name: t.name,
    description: t.description,
    rulesText: t.rulesText,
    entryRequirements: t.entryRequirements,
    mode: t.mode,
    capacity: String(t.capacity),
    approvalMode: t.approvalMode,
    timezone: t.timezone,
    regOpensAt: isoToZonedLocal(t.regOpensAt, t.timezone),
    regClosesAt: isoToZonedLocal(t.regClosesAt, t.timezone),
    startsAt: isoToZonedLocal(t.startsAt, t.timezone),
    maxEntriesPerMatch: String(t.maxEntriesPerMatch),
    killPoint: String(t.scoring.killPoint),
    placementPoints: t.scoring.placementPoints.join(', '),
    tiebreakKeys: [...t.scoring.tiebreakOrder],
    prizePoolMajor: String(t.prize.poolMinor / 100),
    prizeCurrency: t.prize.currency,
    prizeSharePercent: t.prize.shares.map((s) => s.basisPoints / 100).join(', '),
    roomLeadMinutes: String(t.roomLeadMinutes),
    coverStyle: t.coverStyle,
  };
}

function emptyValues(): FormValues {
  const zone = browserZone();
  const inOneDay = (days: number, hour: number) => {
    const date = new Date(Date.now() + days * 86_400_000);
    return isoToZonedLocal(date.toISOString(), zone).replace(/T.*$/, `T${String(hour).padStart(2, '0')}:00`);
  };
  return {
    name: '',
    description: '',
    rulesText: '',
    entryRequirements: '',
    mode: 'solo',
    capacity: '16',
    approvalMode: 'auto',
    timezone: zone,
    regOpensAt: inOneDay(0, 9),
    regClosesAt: inOneDay(2, 18),
    startsAt: inOneDay(3, 19),
    maxEntriesPerMatch: '12',
    killPoint: '1',
    placementPoints: '12, 9, 8, 7, 6, 5, 4, 3, 2, 1',
    tiebreakKeys: [...DEFAULT_TIEBREAK],
    prizePoolMajor: '0',
    prizeCurrency: 'INR',
    prizeSharePercent: '50, 30, 20',
    roomLeadMinutes: '15',
    coverStyle: 'ember',
  };
}

/** Builds the API payload, or a list of local errors when the form cannot be converted. */
function buildPayload(values: FormValues): { payload: Record<string, unknown>; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  const toIso = (field: 'regOpensAt' | 'regClosesAt' | 'startsAt') => {
    const iso = zonedLocalToIso(values[field], values.timezone);
    if (!iso) errors[field] = 'Enter a valid date and time.';
    return iso ?? '';
  };
  const placements = values.placementPoints
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean)
    .map(Number);
  if (placements.some((n) => !Number.isInteger(n) || n < 0 || n > 100)) {
    errors.placementPoints = 'Use whole numbers from 0 to 100, separated by commas.';
  }
  const shares = values.prizeSharePercent
    .split(',')
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part) => Math.round(Number(part) * 100));
  if (shares.some((n) => !Number.isFinite(n) || n < 0)) {
    errors.prizeSharePercent = 'Use percentages separated by commas, for example 50, 30, 20.';
  }
  const pool = Math.round(Number(values.prizePoolMajor) * 100);
  if (!Number.isFinite(pool) || pool < 0) errors.prizePoolMajor = 'Enter a prize pool of zero or more.';

  const payload: Record<string, unknown> = {
    name: values.name,
    description: values.description,
    rulesText: values.rulesText,
    entryRequirements: values.entryRequirements,
    mode: values.mode,
    capacity: Number(values.capacity),
    approvalMode: values.approvalMode,
    timezone: values.timezone,
    regOpensAt: toIso('regOpensAt'),
    regClosesAt: toIso('regClosesAt'),
    startsAt: toIso('startsAt'),
    maxEntriesPerMatch: Number(values.maxEntriesPerMatch),
    killPoint: Number(values.killPoint),
    placementPoints: placements,
    tiebreakOrder: DEFAULT_TIEBREAK.filter((key) => values.tiebreakKeys.includes(key)),
    prizePoolMinor: Number.isFinite(pool) ? pool : 0,
    prizeCurrency: values.prizeCurrency,
    prizeShareBps: shares.filter((n) => Number.isFinite(n)),
    roomLeadMinutes: Number(values.roomLeadMinutes),
    coverStyle: values.coverStyle,
  };
  return { payload, errors };
}

export function TournamentForm({
  initial,
  onSaved,
  onCancel,
}: {
  initial?: TournamentRecord;
  onSaved: (tournament: TournamentRecord) => void;
  onCancel?: () => void;
}) {
  const baseline = useMemo(() => (initial ? valuesFromRecord(initial) : emptyValues()), [initial]);
  const [values, setValues] = useState<FormValues>(baseline);
  const [serverErrors, setServerErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const locked = new Set(initial?.lockedFields ?? []);
  const isEdit = Boolean(initial);
  // Keep the stored zone selectable even when it is an alias the browser's canonical list omits.
  const zones = useMemo(() => {
    const list = supportedZones();
    return list.includes(values.timezone) ? list : [values.timezone, ...list];
  }, [values.timezone]);

  const set = <K extends keyof FormValues>(key: K, value: FormValues[K]) => {
    setValues((previous) => ({ ...previous, [key]: value }));
  };

  const isLocked = (field: string) => locked.has(field);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setFormError(null);
    setServerErrors({});
    const { payload, errors } = buildPayload(values);
    if (Object.keys(errors).length) {
      setServerErrors(errors);
      setFormError('Check the highlighted fields.');
      return;
    }
    let body: Record<string, unknown> = payload;
    if (isEdit) {
      const previous = buildPayload(baseline).payload;
      const dateFields = ['regOpensAt', 'regClosesAt', 'startsAt'] as const;
      const zoneChanged = values.timezone !== baseline.timezone;
      body = {};
      for (const key of Object.keys(payload)) {
        const dateKey = dateFields.find((field) => field === key);
        if (dateKey) {
          // Compare the text the admin sees, so untouched timestamps are never resent with rounding.
          if (zoneChanged || values[dateKey] !== baseline[dateKey]) body[key] = payload[key];
        } else if (JSON.stringify(payload[key]) !== JSON.stringify(previous[key])) {
          body[key] = payload[key];
        }
      }
      if (Object.keys(body).length === 0) {
        setFormError('No changes to save.');
        return;
      }
    }
    setSaving(true);
    try {
      const data = isEdit
        ? await api<{ tournament: TournamentRecord }>('PATCH', `/api/admin/tournaments/${initial!.id}`, body)
        : await api<{ tournament: TournamentRecord }>('POST', '/api/admin/tournaments', body);
      onSaved(data.tournament);
    } catch (error) {
      setServerErrors(fieldErrors(error));
      setFormError(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const err = (field: string) => serverErrors[field];

  return (
    <form onSubmit={submit} noValidate aria-describedby={formError ? 'form-error' : undefined}>
      {formError ? (
        <Notice tone="error">
          <span id="form-error">{formError}</span>
        </Notice>
      ) : null}

      <fieldset style={{ border: 0, padding: 0, margin: '0 0 1.5rem' }}>
        <legend className="eyebrow" style={{ marginBottom: 12 }}>
          Presentation
        </legend>
        <div className="form-grid">
          <div className="span-2">
            <Field id="f-name" label="Tournament name" hint="3 to 80 characters. Shown publicly." error={err('name')}>
              <input id="f-name" className="input" value={values.name} disabled={isLocked('name')} onChange={(e) => set('name', e.target.value)} aria-invalid={Boolean(err('name'))} />
            </Field>
          </div>
          <div className="span-2">
            <Field id="f-description" label="Description" hint="Up to 2,000 characters." error={err('description')}>
              <textarea id="f-description" className="textarea" value={values.description} disabled={isLocked('description')} onChange={(e) => set('description', e.target.value)} />
            </Field>
          </div>
          <div className="span-2">
            <Field id="f-rules" label="Rules" error={err('rulesText')}>
              <textarea id="f-rules" className="textarea" value={values.rulesText} disabled={isLocked('rulesText')} onChange={(e) => set('rulesText', e.target.value)} />
            </Field>
          </div>
          <div className="span-2">
            <Field id="f-entry" label="Entry requirements" error={err('entryRequirements')}>
              <input id="f-entry" className="input" value={values.entryRequirements} disabled={isLocked('entryRequirements')} onChange={(e) => set('entryRequirements', e.target.value)} />
            </Field>
          </div>
          <Field id="f-cover" label="Cover style" error={err('coverStyle')}>
            <select id="f-cover" className="select" value={values.coverStyle} disabled={isLocked('coverStyle')} onChange={(e) => set('coverStyle', e.target.value)}>
              <option value="ember">Ember</option>
              <option value="lime">Lime</option>
              <option value="night">Night</option>
              <option value="steel">Steel</option>
            </select>
          </Field>
          <Field id="f-room-lead" label="Room release lead time (minutes)" hint="Room details unlock this many minutes before the match starts." error={err('roomLeadMinutes')}>
            <input id="f-room-lead" className="input num" type="number" min={0} max={1440} value={values.roomLeadMinutes} disabled={isLocked('roomLeadMinutes')} onChange={(e) => set('roomLeadMinutes', e.target.value)} />
          </Field>
        </div>
      </fieldset>

      <fieldset style={{ border: 0, padding: 0, margin: '0 0 1.5rem' }}>
        <legend className="eyebrow" style={{ marginBottom: 12 }}>
          Format and schedule
        </legend>
        <div className="form-grid">
          <Field id="f-mode" label="Mode" hint={isEdit && isLocked('mode') ? 'Locked after registration opens.' : undefined} error={err('mode')}>
            <select id="f-mode" className="select" value={values.mode} disabled={isEdit && isLocked('mode')} onChange={(e) => set('mode', e.target.value)}>
              <option value="solo">Solo</option>
              <option value="duo">Duo (2 players)</option>
              <option value="squad">Squad (4 players)</option>
            </select>
          </Field>
          <Field id="f-capacity" label="Capacity (places)" hint="Between 2 and 512." error={err('capacity')}>
            <input id="f-capacity" className="input num" type="number" min={2} max={512} value={values.capacity} disabled={isLocked('capacity')} onChange={(e) => set('capacity', e.target.value)} />
          </Field>
          <Field id="f-approval" label="Approval" hint={isEdit && isLocked('approvalMode') ? 'Locked after registration opens.' : 'Auto-approve fills places first come, first served. Manual lets you review each entry.'} error={err('approvalMode')}>
            <select id="f-approval" className="select" value={values.approvalMode} disabled={isEdit && isLocked('approvalMode')} onChange={(e) => set('approvalMode', e.target.value)}>
              <option value="auto">Auto-approve</option>
              <option value="manual">Manual approval</option>
            </select>
          </Field>
          <Field id="f-tz" label="Time zone" hint="All times below are wall-clock times in this zone." error={err('timezone')}>
            <select id="f-tz" className="select" value={values.timezone} disabled={isEdit && isLocked('timezone')} onChange={(e) => set('timezone', e.target.value)}>
              {zones.map((zone) => (
                <option key={zone} value={zone}>
                  {formatZoneLabel(zone)}
                </option>
              ))}
            </select>
          </Field>
          <Field id="f-opens" label="Registration opens" error={err('regOpensAt')}>
            <input id="f-opens" className="input" type="datetime-local" value={values.regOpensAt} disabled={isEdit && isLocked('regOpensAt')} onChange={(e) => set('regOpensAt', e.target.value)} />
          </Field>
          <Field id="f-closes" label="Registration closes" error={err('regClosesAt')}>
            <input id="f-closes" className="input" type="datetime-local" value={values.regClosesAt} disabled={isEdit && isLocked('regClosesAt')} onChange={(e) => set('regClosesAt', e.target.value)} />
          </Field>
          <Field id="f-starts" label="Starts" error={err('startsAt')}>
            <input id="f-starts" className="input" type="datetime-local" value={values.startsAt} disabled={isEdit && isLocked('startsAt')} onChange={(e) => set('startsAt', e.target.value)} />
          </Field>
          <Field id="f-max-entries" label="Maximum entries per match" hint="Between 2 and 50." error={err('maxEntriesPerMatch')}>
            <input id="f-max-entries" className="input num" type="number" min={2} max={50} value={values.maxEntriesPerMatch} disabled={isEdit && isLocked('maxEntriesPerMatch')} onChange={(e) => set('maxEntriesPerMatch', e.target.value)} />
          </Field>
        </div>
      </fieldset>

      <fieldset style={{ border: 0, padding: 0, margin: '0 0 1.5rem' }}>
        <legend className="eyebrow" style={{ marginBottom: 12 }}>
          Scoring
        </legend>
        <div className="form-grid">
          <Field id="f-kill" label="Points per kill" error={err('killPoint')}>
            <input id="f-kill" className="input num" type="number" min={0} max={100} value={values.killPoint} disabled={isEdit && isLocked('killPoint')} onChange={(e) => set('killPoint', e.target.value)} />
          </Field>
          <Field id="f-placements" label="Placement points" hint="Comma-separated. Position 1 first, for example 12, 9, 8." error={err('placementPoints') ?? serverErrors.placementPoints}>
            <input id="f-placements" className="input num" value={values.placementPoints} disabled={isEdit && isLocked('placementPoints')} onChange={(e) => set('placementPoints', e.target.value)} />
          </Field>
          <div className="span-2">
            <fieldset style={{ border: 0, padding: 0, margin: 0 }}>
              <legend className="field__label" style={{ marginBottom: 8 }}>
                Tie-breakers
              </legend>
              <div className="row" style={{ gap: '1rem 1.5rem' }}>
                {DEFAULT_TIEBREAK.map((key) => (
                  <label key={key} className="checkbox" style={{ marginBottom: 0 }}>
                    <input
                      type="checkbox"
                      checked={values.tiebreakKeys.includes(key)}
                      disabled={isEdit && isLocked('tiebreakOrder')}
                      onChange={(e) =>
                        set(
                          'tiebreakKeys',
                          e.target.checked ? DEFAULT_TIEBREAK.filter((k) => k === key || values.tiebreakKeys.includes(k)) : values.tiebreakKeys.filter((k) => k !== key),
                        )
                      }
                    />
                    <span>{TIEBREAK_LABELS[key]}</span>
                  </label>
                ))}
              </div>
              <span className="field__hint">Applied in this order when entries are level on points.</span>
              {err('tiebreakOrder') ? <span className="field__error">{err('tiebreakOrder')}</span> : null}
            </fieldset>
          </div>
        </div>
      </fieldset>

      <fieldset style={{ border: 0, padding: 0, margin: '0 0 1.5rem' }}>
        <legend className="eyebrow" style={{ marginBottom: 12 }}>
          Prizes
        </legend>
        <div className="form-grid">
          <Field id="f-pool" label="Prize pool (major units)" hint="Enter 0 for no prize pool. Amounts are recorded, not paid by this app." error={err('prizePoolMinor') ?? serverErrors.prizePoolMajor}>
            <input id="f-pool" className="input num" type="number" min={0} step="0.01" value={values.prizePoolMajor} disabled={isEdit && isLocked('prizePoolMinor')} onChange={(e) => set('prizePoolMajor', e.target.value)} />
          </Field>
          <Field id="f-currency" label="Currency" error={err('prizeCurrency')}>
            <select id="f-currency" className="select" value={values.prizeCurrency} disabled={isEdit && isLocked('prizeCurrency')} onChange={(e) => set('prizeCurrency', e.target.value)}>
              <option value="INR">INR</option>
              <option value="USD">USD</option>
            </select>
          </Field>
          <div className="span-2">
            <Field id="f-shares" label="Share per placement (percent)" hint="Comma-separated, first place first. The total may not exceed 100." error={err('prizeShareBps') ?? serverErrors.prizeSharePercent}>
              <input id="f-shares" className="input num" value={values.prizeSharePercent} disabled={isEdit && isLocked('prizeShareBps')} onChange={(e) => set('prizeSharePercent', e.target.value)} />
            </Field>
          </div>
        </div>
      </fieldset>

      <div className="btn-row" style={{ justifyContent: 'flex-end' }}>
        {onCancel ? (
          <button type="button" className="btn btn--ghost" onClick={onCancel}>
            Cancel
          </button>
        ) : null}
        <button type="submit" className="btn btn--primary" disabled={saving}>
          {saving ? 'Saving…' : isEdit ? 'Save changes' : 'Create tournament'}
        </button>
      </div>
      <p className="small" style={{ marginTop: 12 }}>
        Status: <StatusBadge status={initial?.status ?? 'draft'} /> New tournaments start as drafts and stay hidden from players until you publish them.
      </p>
    </form>
  );
}
