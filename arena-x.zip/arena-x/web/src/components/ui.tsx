import { useEffect, useId, useRef, type KeyboardEvent, type ReactNode } from 'react';
import { badgeTone, label } from '../lib/format.ts';
import type { AvatarKey } from '../lib/types.ts';

/** Original geometric marks, one per avatar key. They are not game artwork or logos. */
const AVATAR_PATHS: Record<AvatarKey, string> = {
  bolt: 'M13 2 L4 14 H11 L10 22 L20 9 H13 Z',
  falcon: 'M2 16 L12 6 L22 16 L17 16 L12 11 L7 16 Z',
  ember: 'M12 3 A9 9 0 1 0 12 21 A9 9 0 1 0 12 3 Z M12 8 A4 4 0 1 1 12 16 A4 4 0 1 1 12 8 Z',
  frost: 'M12 2 L21 7 V17 L12 22 L3 17 V7 Z',
  viper: 'M3 5 L12 3 L21 5 L12 21 Z',
  nova: 'M12 1 L14.5 9.5 L23 12 L14.5 14.5 L12 23 L9.5 14.5 L1 12 L9.5 9.5 Z',
  ghost: 'M5 22 V11 A7 7 0 0 1 19 11 V22 L15.5 19.5 L12 22 L8.5 19.5 Z',
  titan: 'M4 4 H20 V15 L12 21 L4 15 Z',
};

export function Avatar({ avatarKey, size = 'md' }: { avatarKey: string; size?: 'sm' | 'md' | 'lg' }) {
  const key = (avatarKey in AVATAR_PATHS ? avatarKey : 'titan') as AvatarKey;
  const sizeClass = size === 'sm' ? ' avatar--sm' : size === 'lg' ? ' avatar--lg' : '';
  return (
    <span className={`avatar${sizeClass}`} aria-hidden="true">
      <svg viewBox="0 0 24 24" focusable="false">
        <path d={AVATAR_PATHS[key]} fill="var(--accent)" fillRule="evenodd" />
      </svg>
    </span>
  );
}

export function StatusBadge({ status, text }: { status: string; text?: string }) {
  return <span className={`badge badge--${badgeTone(status)}`}>{text ?? label(status)}</span>;
}

export function Notice({ tone = 'info', title, children }: { tone?: 'info' | 'error' | 'success'; title?: string; children: ReactNode }) {
  return (
    <div className={`notice notice--${tone}`} role={tone === 'error' ? 'alert' : 'status'}>
      <div>
        {title ? <strong style={{ display: 'block', color: 'var(--text)', marginBottom: 2 }}>{title}</strong> : null}
        {children}
      </div>
    </div>
  );
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <strong>{title}</strong>
      {children}
    </div>
  );
}

export function Spinner({ label: text = 'Loading' }: { label?: string }) {
  return (
    <span className="row" role="status" style={{ color: 'var(--muted)', fontSize: '0.9rem' }}>
      <span className="spinner" aria-hidden="true" />
      <span>{text}…</span>
    </span>
  );
}

export function LoadingBlock({ rows = 3 }: { rows?: number }) {
  return (
    <div className="stack" aria-busy="true" aria-label="Loading">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="skeleton" />
      ))}
    </div>
  );
}

export function PageHead({ eyebrow, title, actions, children }: { eyebrow?: string; title: string; actions?: ReactNode; children?: ReactNode }) {
  return (
    <header className="section__head" style={{ alignItems: 'flex-end' }}>
      <div style={{ display: 'grid', gap: 6, minWidth: 0 }}>
        {eyebrow ? <span className="eyebrow">{eyebrow}</span> : null}
        <h1 style={{ fontSize: 'clamp(1.7rem, 3.4vw, 2.4rem)' }}>{title}</h1>
        {children}
      </div>
      {actions ? <div className="btn-row">{actions}</div> : null}
    </header>
  );
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const titleId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);

  useEffect(() => {
    closeRef.current = onClose;
  }, [onClose]);

  useEffect(() => {
    const returnFocusTo = document.activeElement as HTMLElement | null;
    const focusable = () =>
      Array.from(
        dialogRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), [href], input:not([disabled]), select, textarea') ?? [],
      );
    focusable()[0]?.focus();
    const onKey = (event: globalThis.KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        closeRef.current();
        return;
      }
      if (event.key !== 'Tab') return;
      const items = focusable();
      if (items.length === 0) return;
      const first = items[0]!;
      const last = items[items.length - 1]!;
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      returnFocusTo?.focus?.();
    };
  }, []);

  return (
    <div
      className="scrim"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby={titleId} ref={dialogRef}>
        <h2 id={titleId} style={{ fontSize: '1.25rem', marginBottom: '0.9rem' }}>
          {title}
        </h2>
        {children}
      </div>
    </div>
  );
}

export interface TabItem<T extends string> {
  id: T;
  label: string;
}

export function Tabs<T extends string>({
  items,
  value,
  onChange,
  name,
}: {
  items: TabItem<T>[];
  value: T;
  onChange: (id: T) => void;
  name: string;
}) {
  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key !== 'ArrowRight' && event.key !== 'ArrowLeft') return;
    const index = items.findIndex((item) => item.id === value);
    const delta = event.key === 'ArrowRight' ? 1 : -1;
    const next = items[(index + delta + items.length) % items.length];
    if (next) {
      onChange(next.id);
      document.getElementById(`tab-${name}-${next.id}`)?.focus();
    }
  };
  return (
    <div className="tabs" role="tablist" aria-label={name} onKeyDown={onKeyDown}>
      {items.map((item) => (
        <button
          key={item.id}
          id={`tab-${name}-${item.id}`}
          role="tab"
          type="button"
          aria-selected={item.id === value}
          aria-controls={`panel-${name}`}
          tabIndex={item.id === value ? 0 : -1}
          onClick={() => onChange(item.id)}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

export function Field({
  id,
  label: text,
  hint,
  error,
  children,
}: {
  id: string;
  label: string;
  hint?: string;
  error?: string;
  children: ReactNode;
}) {
  const hintId = `${id}-hint`;
  const errorId = `${id}-error`;
  return (
    <div className="field">
      <label htmlFor={id}>{text}</label>
      {children}
      {hint ? (
        <span className="field__hint" id={hintId}>
          {hint}
        </span>
      ) : null}
      {error ? (
        <span className="field__error" id={errorId}>
          {error}
        </span>
      ) : null}
    </div>
  );
}

/** Describes the aria attributes a control needs to point at its hint and error text. */
export function describedBy(id: string, hint?: string, error?: string): string | undefined {
  const parts = [hint ? `${id}-hint` : '', error ? `${id}-error` : ''].filter(Boolean);
  return parts.length ? parts.join(' ') : undefined;
}

/* ---- Announcements for assistive technology ---- */

export function LiveRegion() {
  return <div id="announcer" role="status" aria-live="polite" className="sr-only" />;
}

export function announce(message: string): void {
  const node = document.getElementById('announcer');
  if (!node) return;
  node.textContent = '';
  window.setTimeout(() => {
    node.textContent = message;
  }, 30);
}

export function formatCount(value: number, singular: string, plural = `${singular}s`): string {
  return `${value} ${value === 1 ? singular : plural}`;
}
