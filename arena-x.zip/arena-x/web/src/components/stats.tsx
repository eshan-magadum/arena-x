import { formatNumber } from '../lib/format.ts';
import type { PlayerStats as PlayerStatsData } from '../lib/types.ts';

export function PlayerStats({ stats, compact = false }: { stats: PlayerStatsData; compact?: boolean }) {
  const items: Array<{ value: number; label: string }> = [
    { value: stats.verifiedMatches, label: 'Verified matches' },
    { value: stats.totalPoints, label: 'Points' },
    { value: stats.kills, label: 'Kills' },
    { value: stats.wins, label: 'First places' },
    { value: stats.tournamentsEntered, label: 'Tournaments' },
  ];
  const shown = compact ? items.slice(0, 4) : items;
  return (
    <div className="stat-row" role="list" aria-label="Your record">
      {shown.map((item) => (
        <div key={item.label} className="stat" role="listitem">
          <span className="stat__value">{formatNumber(item.value)}</span>
          <span className="stat__label">{item.label}</span>
        </div>
      ))}
    </div>
  );
}
