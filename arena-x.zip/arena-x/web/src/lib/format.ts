/**
 * Formatting helpers. Tournament times are always shown in the tournament's own time zone, and
 * admin inputs are converted from that zone to UTC before they are sent, because the server
 * parses timestamps as instants.
 */

const LABELS: Record<string, string> = {
  draft: 'Draft',
  scheduled: 'Scheduled',
  registration_open: 'Registration open',
  registration_closed: 'Registration closed',
  live: 'Live',
  completed: 'Completed',
  cancelled: 'Cancelled',
  pending: 'Pending',
  confirmed: 'Confirmed',
  waitlisted: 'Waitlisted',
  rejected: 'Rejected',
  approved: 'Approved',
  superseded: 'Superseded',
  allocated: 'Allocated',
  fulfilled: 'Fulfilled',
  failed: 'Failed',
  disputed: 'Disputed',
  awaiting_results: 'Awaiting results',
  active: 'Active',
  suspended: 'Suspended',
  banned: 'Banned',
  not_set: 'Not set',
  not_published: 'Not published',
  not_released: 'Not yet released',
  published: 'Published',
  available: 'Available',
  player: 'Player',
  admin: 'Admin',
  captain: 'Captain',
  member: 'Member',
  solo: 'Solo',
  duo: 'Duo',
  squad: 'Squad',
  auto: 'Auto-approve',
  manual: 'Manual approval',
  player_result: 'Player',
};

export function label(value: string | null | undefined): string {
  if (!value) return '';
  return LABELS[value] ?? value.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
}

/** Maps a status onto one of the badge tones defined in the stylesheet. */
export function badgeTone(status: string): string {
  const map: Record<string, string> = {
    registration_open: 'open',
    registration_closed: 'closed',
    scheduled: 'scheduled',
    live: 'live',
    completed: 'completed',
    cancelled: 'cancelled',
    draft: 'draft',
    pending: 'pending',
    confirmed: 'confirmed',
    waitlisted: 'waitlisted',
    rejected: 'rejected',
    approved: 'approved',
    superseded: 'superseded',
    allocated: 'allocated',
    fulfilled: 'fulfilled',
    failed: 'failed',
    disputed: 'disputed',
    awaiting_results: 'warn',
    not_released: 'warn',
    active: 'ok',
    suspended: 'suspended',
    banned: 'banned',
    published: 'ok',
    available: 'ok',
    not_set: 'muted',
    not_published: 'muted',
  };
  return map[status] ?? 'muted';
}

const TZ_CACHE = new Map<string, Intl.DateTimeFormat>();

function formatterFor(timeZone: string): Intl.DateTimeFormat {
  let formatter = TZ_CACHE.get(timeZone);
  if (!formatter) {
    formatter = new Intl.DateTimeFormat('en-GB', {
      dateStyle: 'medium',
      timeStyle: 'short',
      timeZone,
    });
    TZ_CACHE.set(timeZone, formatter);
  }
  return formatter;
}

export function formatDateTime(iso: string | null | undefined, timeZone?: string): string {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  try {
    return formatterFor(timeZone ?? 'UTC').format(date);
  } catch {
    return formatterFor('UTC').format(date);
  }
}

export function formatZoneLabel(timeZone: string): string {
  return timeZone.replace(/_/g, ' ');
}

export function formatMoney(minor: number, currency: string): string {
  try {
    return new Intl.NumberFormat(currency === 'INR' ? 'en-IN' : 'en-US', { style: 'currency', currency }).format(minor / 100);
  } catch {
    return `${(minor / 100).toFixed(2)} ${currency}`;
  }
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('en-IN').format(value);
}

export function ordinal(n: number): string {
  const suffix = n % 100 >= 11 && n % 100 <= 13 ? 'th' : ['th', 'st', 'nd', 'rd'][n % 10] ?? 'th';
  return `${n}${suffix}`;
}

/* ---- Time zone conversion (wall clock in a named zone <-> UTC instant) ---- */

function zonedParts(date: Date, timeZone: string): Record<string, number> {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone,
    hourCycle: 'h23',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  const out: Record<string, number> = {};
  for (const part of formatter.formatToParts(date)) {
    if (part.type !== 'literal') out[part.type] = Number(part.value);
  }
  return out;
}

function zoneOffsetMs(date: Date, timeZone: string): number {
  const p = zonedParts(date, timeZone);
  const asUtc = Date.UTC(p.year!, p.month! - 1, p.day!, p.hour! % 24, p.minute!, p.second!);
  return asUtc - (date.getTime() - date.getUTCMilliseconds());
}

/** Converts "YYYY-MM-DDTHH:mm" read as wall-clock time in timeZone to a UTC ISO instant. */
export function zonedLocalToIso(local: string, timeZone: string): string | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(local);
  if (!match) return null;
  const [y, mo, d, h, mi] = match.slice(1).map(Number) as [number, number, number, number, number];
  const wallAsUtc = Date.UTC(y, mo - 1, d, h, mi);
  try {
    const first = wallAsUtc - zoneOffsetMs(new Date(wallAsUtc), timeZone);
    const second = wallAsUtc - zoneOffsetMs(new Date(first), timeZone);
    return new Date(second).toISOString();
  } catch {
    return null;
  }
}

/** The inverse: a UTC instant rendered as a "YYYY-MM-DDTHH:mm" value in timeZone, for inputs. */
export function isoToZonedLocal(iso: string, timeZone: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  try {
    const p = zonedParts(date, timeZone);
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${p.year}-${pad(p.month!)}-${pad(p.day!)}T${pad(p.hour! % 24)}:${pad(p.minute!)}`;
  } catch {
    return '';
  }
}

export function safeInternalPath(value: string | null | undefined): string | null {
  if (!value) return null;
  return value.startsWith('/') && !value.startsWith('//') ? value : null;
}
