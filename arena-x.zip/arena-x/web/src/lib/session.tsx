import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { api } from './api.ts';
import type { Viewer } from './types.ts';

/**
 * Session state for the signed-in user, plus the live update channel. The server pushes hints
 * over Server-Sent Events; pages re-read persisted data when they receive one, so a dropped
 * event never leaves the UI wrong for long.
 */

type LiveListener = (type: string, data: unknown) => void;
const liveListeners = new Set<LiveListener>();

export function subscribeLive(listener: LiveListener): () => void {
  liveListeners.add(listener);
  return () => {
    liveListeners.delete(listener);
  };
}

interface SessionValue {
  ready: boolean;
  viewer: Viewer | null;
  unread: number;
  refresh: () => Promise<void>;
  setSession: (viewer: Viewer | null, unread?: number) => void;
  signOut: () => Promise<void>;
}

const SessionContext = createContext<SessionValue | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [viewer, setViewer] = useState<Viewer | null>(null);
  const [unread, setUnread] = useState(0);
  const sourceRef = useRef<EventSource | null>(null);

  const refresh = useCallback(async () => {
    try {
      const data = await api<{ viewer: Viewer | null; unread: number }>('GET', '/api/auth/session');
      setViewer(data.viewer);
      setUnread(data.unread);
    } catch {
      setViewer(null);
      setUnread(0);
    } finally {
      setReady(true);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const viewerId = viewer?.id ?? null;

  // Every visitor gets the public stream. A signed-in visitor also gets their private channel, and the
  // server chooses that channel when the stream connects, so the stream reopens when the viewer changes.
  useEffect(() => {
    if (typeof EventSource === 'undefined') return;
    const source = new EventSource('/api/stream', { withCredentials: true });
    sourceRef.current = source;
    const forward = (type: string) => (event: MessageEvent<string>) => {
      let data: unknown = null;
      try {
        data = JSON.parse(event.data);
      } catch {
        data = null;
      }
      if (type === 'notification' && viewerId) {
        api<{ viewer: Viewer | null; unread: number }>('GET', '/api/auth/session')
          .then((session) => setUnread(session.unread))
          .catch(() => undefined);
      }
      for (const listener of liveListeners) listener(type, data);
    };
    const types = ['notification', 'chat', 'team', 'registration', 'match', 'tournament'];
    const handlers = types.map((type) => [type, forward(type)] as const);
    for (const [type, handler] of handlers) source.addEventListener(type, handler as EventListener);
    return () => {
      for (const [type, handler] of handlers) source.removeEventListener(type, handler as EventListener);
      source.close();
      sourceRef.current = null;
    };
  }, [viewerId]);

  const setSession = useCallback((next: Viewer | null, count = 0) => {
    setViewer(next);
    setUnread(count);
    setReady(true);
  }, []);

  const signOut = useCallback(async () => {
    try {
      await api('POST', '/api/auth/logout');
    } finally {
      sourceRef.current?.close();
      setViewer(null);
      setUnread(0);
    }
  }, []);

  const value = useMemo<SessionValue>(
    () => ({ ready, viewer, unread, refresh, setSession, signOut }),
    [ready, viewer, unread, refresh, setSession, signOut],
  );
  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): SessionValue {
  const value = useContext<SessionValue | null>(SessionContext);
  if (!value) throw new Error('useSession must be used inside SessionProvider');
  return value;
}

/** Runs the listener for any of the named live event types while the component is mounted. */
export function useLiveEvent(types: readonly string[], onEvent: (data: unknown) => void): void {
  const handlerRef = useRef(onEvent);
  useEffect(() => {
    handlerRef.current = onEvent;
  }, [onEvent]);
  const key = types.join(',');
  useEffect(() => {
    const wanted = new Set(key.split(','));
    return subscribeLive((type, data) => {
      if (wanted.has(type)) handlerRef.current(data);
    });
  }, [key]);
}
