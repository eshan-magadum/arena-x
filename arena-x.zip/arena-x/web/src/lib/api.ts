/**
 * Thin fetch wrapper. Every mutation carries the CSRF header the server requires, and every
 * failure is normalised into an ApiError so screens can show the server's own wording.
 */

export interface ApiErrorDetail {
  path: string;
  message: string;
}

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details: unknown;

  constructor(status: number, code: string, message: string, details: unknown = null) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export async function api<T>(method: Method, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  if (method !== 'GET') headers['x-arena-request'] = '1';
  const init: RequestInit = { method, credentials: 'same-origin', headers };
  if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    init.body = JSON.stringify(body);
  }

  let response: Response;
  try {
    response = await fetch(path, init);
  } catch {
    throw new ApiError(0, 'network', 'Could not reach ARENA X. Check your connection and try again.');
  }

  const text = await response.text();
  let payload: unknown = null;
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = null;
    }
  }

  if (!response.ok) {
    const envelope = (payload as { error?: { code?: string; message?: string; details?: unknown } } | null)?.error;
    if (envelope && typeof envelope.message === 'string') {
      throw new ApiError(response.status, envelope.code ?? 'error', envelope.message, envelope.details ?? null);
    }
    throw new ApiError(
      response.status,
      'error',
      response.status === 503 ? 'The service is unavailable right now. Try again shortly.' : 'Something went wrong. Please try again.',
    );
  }
  return payload as T;
}

/** Maps zod-style field issues (path to message) so forms can show each message beside its field. */
export function fieldErrors(error: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  if (!(error instanceof ApiError) || !Array.isArray(error.details)) return out;
  for (const item of error.details as Partial<ApiErrorDetail>[]) {
    if (item && typeof item.path === 'string' && typeof item.message === 'string' && !(item.path in out)) {
      out[item.path] = item.message;
    }
  }
  return out;
}

export function errorMessage(error: unknown): string {
  if (error instanceof ApiError) return error.message;
  return 'Something went wrong. Please try again.';
}

export function isAuthError(error: unknown): boolean {
  return error instanceof ApiError && error.status === 401;
}
