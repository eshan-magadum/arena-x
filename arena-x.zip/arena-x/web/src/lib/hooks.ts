import { useCallback, useEffect, useRef, useState } from 'react';

export interface AsyncState<T> {
  data: T | null;
  error: unknown;
  loading: boolean;
  reload: () => void;
  setData: (next: T | null) => void;
}

/**
 * Loads data when the dependencies change and exposes reload(). Stale responses are discarded,
 * so a slow earlier request can never overwrite the result of a newer one.
 */
export function useAsync<T>(load: () => Promise<T>, deps: readonly unknown[]): AsyncState<T> {
  const [state, setState] = useState<{ data: T | null; error: unknown; loading: boolean }>({
    data: null,
    error: null,
    loading: true,
  });
  const [tick, setTick] = useState(0);
  const loaderRef = useRef(load);
  useEffect(() => {
    loaderRef.current = load;
  }, [load]);

  useEffect(() => {
    let active = true;
    setState((previous) => ({ ...previous, loading: true }));
    loaderRef
      .current()
      .then(
        (data) => {
          if (active) setState({ data, error: null, loading: false });
        },
        (error: unknown) => {
          if (active) setState({ data: null, error, loading: false });
        },
      );
    return () => {
      active = false;
    };
    // The loader is intentionally keyed by the caller's dependency list and the reload counter.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tick, ...deps]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  const setData = useCallback((next: T | null) => setState((previous) => ({ ...previous, data: next })), []);
  return { data: state.data, error: state.error, loading: state.loading, reload, setData };
}

/** Sets the browser tab title for the current screen. */
export function useDocumentTitle(title: string): void {
  useEffect(() => {
    document.title = title === 'ARENA X' ? 'ARENA X' : `${title} · ARENA X`;
  }, [title]);
}
