/** Shapes returned by the ARENA X API. Mirrors the server read models; keep in step with services. */

export type Mode = 'solo' | 'duo' | 'squad';
export type TournamentStatus =
  | 'draft'
  | 'scheduled'
  | 'registration_open'
  | 'registration_closed'
  | 'live'
  | 'completed'
  | 'cancelled';
export type RegistrationStatus = 'pending' | 'confirmed' | 'waitlisted' | 'rejected' | 'cancelled';
export type MatchState = 'scheduled' | 'live' | 'awaiting_results' | 'completed' | 'cancelled';
export type AvatarKey = 'bolt' | 'falcon' | 'ember' | 'frost' | 'viper' | 'nova' | 'ghost' | 'titan';
export type TiebreakKey = 'kills' | 'first_places' | 'best_placement';
export type CoverStyle = 'ember' | 'lime' | 'night' | 'steel';
export type Role = 'player' | 'admin';
export type TeamMode = 'duo' | 'squad';

export interface Restriction {
  kind: 'suspended' | 'banned';
  until: string | null;
  reason: string | null;
}

export interface Viewer {
  id: string;
  email: string;
  displayName: string;
  inGameId: string | null;
  avatarKey: AvatarKey;
  role: Role;
  restriction: Restriction | null;
  createdAt: string;
}

export interface TournamentRecord {
  id: string;
  slug: string;
  name: string;
  description: string;
  rulesText: string;
  entryRequirements: string;
  mode: Mode;
  rosterSize: number;
  status: TournamentStatus;
  capacity: number;
  approvalMode: 'auto' | 'manual';
  confirmedCount: number;
  pendingCount?: number;
  activeRegistrationCount?: number;
  matchCount?: number;
  lockedFields?: string[];
  regOpensAt: string;
  regClosesAt: string;
  startsAt: string;
  timezone: string;
  maxEntriesPerMatch: number;
  scoring: {
    killPoint: number;
    placementPoints: number[];
    tiebreakOrder: TiebreakKey[];
    version: number;
  };
  prize: {
    poolMinor: number;
    currency: string;
    shares: Array<{ placement: number; basisPoints: number; amountMinor: number }>;
    unallocatedMinor: number;
  };
  roomLeadMinutes: number;
  coverStyle: CoverStyle;
  finalizedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PublicMatch {
  id: string;
  matchNumber: number;
  roundLabel: string;
  startsAt: string;
  state: MatchState;
  entries: number;
}

export interface StandingRow {
  rank: number;
  registrationId?: string;
  entrantName: string;
  kind: string;
  members: string[];
  totalPoints: number;
  kills: number;
  firstPlaces: number;
  bestPlacement: number | null;
  matchesPlayed: number;
  pendingSubmissions?: number;
}

export interface TournamentDetail {
  tournament: TournamentRecord;
  matches: PublicMatch[];
  standings: {
    provisional: boolean;
    finalizedAt: string | null;
    rows: StandingRow[];
  };
}

export interface TournamentList {
  items: TournamentRecord[];
  total: number;
  limit: number;
  offset: number;
}

export interface RegistrationMember {
  userId: string;
  displayName: string;
  inGameId?: string | null;
}

export interface Registration {
  id: string;
  tournamentId: string;
  kind: 'solo' | 'team';
  teamId: string | null;
  entrantName: string;
  status: RegistrationStatus;
  statusReason: string | null;
  createdAt: string;
  members: RegistrationMember[];
}

export interface EntryOptions {
  tournamentId: string;
  mode: Mode;
  open: boolean;
  canRegister: boolean;
  reasons: string[];
  myEntries: Array<{ id: string; status: RegistrationStatus; entrantName: string }>;
  teams: Array<{ id: string; name: string; memberCount: number; rosterSize: number; eligible: boolean; issues: string[] }>;
}

export interface Submission {
  id: string;
  matchId: string;
  registrationId: string;
  entrantName: string;
  kills: number;
  placement: number;
  evidenceUrl: string | null;
  notes: string | null;
  source: string;
  status: 'pending' | 'approved' | 'rejected' | 'superseded';
  killPoints: number | null;
  placementPoints: number | null;
  totalPoints: number | null;
  reviewReason: string | null;
  reviewedAt: string | null;
  createdAt: string;
  tournamentId?: string;
  tournamentName?: string;
  matchRound?: string;
  mode?: string;
  supersedesId?: string | null;
}

export interface MatchSubmissionSummary {
  id: string;
  registrationId: string;
  status: string;
  kills: number;
  placement: number;
  totalPoints: number | null;
  reviewReason: string | null;
  createdAt: string;
}

export interface ParticipantMatch {
  id: string;
  tournamentId: string;
  tournamentName: string;
  tournamentSlug: string;
  matchNumber: number;
  roundLabel: string;
  startsAt: string;
  state: MatchState;
  room: { status: 'not_set' | 'not_published' | 'not_released' | 'available'; releaseAt: string };
  submissions: MatchSubmissionSummary[];
  canSubmitResult: boolean;
}

export type RoomView =
  | { state: 'not_set' }
  | { state: 'not_published' }
  | { state: 'not_released'; releaseAt: string }
  | { state: 'available'; roomId: string; roomPassword: string | null; releaseAt: string };

export interface AdminMatch {
  id: string;
  matchNumber: number;
  roundLabel: string;
  startsAt: string;
  state: MatchState;
  roomStatus: 'not_set' | 'draft' | 'published';
  entries: Array<{ registrationId: string; entrantName: string; status: string }>;
}

export interface Notification {
  id: string;
  kind: string;
  title: string;
  body: string;
  link: string | null;
  read: boolean;
  createdAt: string;
}

export interface LeaderboardRow {
  rank: number;
  key: string;
  name: string;
  avatarKey: string | null;
  totalPoints: number;
  kills: number;
  wins: number;
  matchesPlayed: number;
}

export interface PlayerStats {
  verifiedMatches: number;
  totalPoints: number;
  kills: number;
  wins: number;
  tournamentsEntered: number;
}

export interface Announcement {
  id: string;
  title: string;
  body: string;
  createdAt: string;
}

export interface TeamSummary {
  id: string;
  name: string;
  mode: TeamMode;
  role: 'captain' | 'member';
  memberCount: number;
  rosterSize: number;
}

export interface TeamInvitation {
  id: string;
  teamId: string;
  teamName: string;
  mode: TeamMode;
  inviterName: string;
  createdAt: string;
}

export interface TeamDetail {
  id: string;
  name: string;
  mode: TeamMode;
  rosterSize: number;
  createdAt: string;
  viewer: { isMember: boolean; isCaptain: boolean };
  members: Array<{
    userId: string;
    displayName: string;
    avatarKey: string;
    role: 'captain' | 'member';
    inGameId: string | null;
  }>;
  invitations: Array<{ id: string; inviteeName: string; createdAt: string }>;
  registrations: Array<{ id: string; tournamentId: string; tournamentName: string; status: string; createdAt: string }>;
}

export interface ChatMessage {
  id: number;
  authorId: string;
  authorName: string;
  body: string;
  createdAt: string;
  removed: boolean;
}

export interface Dashboard {
  profile: { id: string; displayName: string; inGameId: string | null; avatarKey: AvatarKey; needsInGameId: boolean };
  stats: PlayerStats;
  registrations: Array<{
    id: string;
    status: RegistrationStatus;
    entrantName: string;
    kind: string;
    tournamentId: string;
    tournamentName: string;
    tournamentSlug: string;
    tournamentStatus: TournamentStatus;
    startsAt: string;
    mode: Mode;
  }>;
  matches: Array<{ id: string; roundLabel: string; startsAt: string; state: MatchState; tournamentName: string; tournamentSlug: string }>;
  pendingResults: Array<{ id: string; matchId: string; roundLabel: string; kills: number; placement: number; createdAt: string }>;
  teams: { teams: TeamSummary[]; invitations: TeamInvitation[] };
  notifications: { unread: number; items: Notification[] };
  announcements: Announcement[];
}

export interface PrizeAward {
  id: string;
  placement: number;
  entrantName: string;
  registrationId: string;
  amountMinor: number;
  currency: string;
  display: string;
  status: 'allocated' | 'approved' | 'fulfilled' | 'failed' | 'disputed';
  externalReference: string | null;
  statusNote: string | null;
  updatedAt: string;
}

export interface AdminPlayer {
  id: string;
  email: string;
  displayName: string;
  inGameId: string | null;
  role: Role;
  status: string;
  suspendedUntil: string | null;
  createdAt: string;
}

export interface AuditEvent {
  seq: number;
  id: string;
  action: string;
  actorId: string | null;
  actorRole: string | null;
  entityType: string;
  entityId: string | null;
  detail: Record<string, unknown>;
  createdAt: string;
  hash: string;
}

export interface AdminDashboardData {
  users: { total: number; restricted: number; admins: number };
  tournaments: Record<string, number>;
  registrations: { createdLast7Days: number; pendingApproval: number };
  results: { pendingReview: number };
  matches: { liveOrAwaitingResults: number };
  prizes: unknown;
  recentAudit: Array<{ seq: number; action: string; entityType: string; entityId: string | null; actorRole: string | null; createdAt: string }>;
}

export interface HomeData {
  featured: TournamentRecord[];
  winners: Array<{ tournamentName: string; tournamentSlug: string; winnerName: string; kind: string; totalPoints: number; finalizedAt: string }>;
  topPlayers: LeaderboardRow[];
  announcements: Announcement[];
  stats: { verifiedResults: number; finishedTournaments: number };
}

export interface MatchHistoryItem {
  matchId: string;
  roundLabel: string;
  startsAt: string;
  matchState: string;
  tournamentName: string;
  tournamentSlug: string;
  entrantName: string;
  resultStatus: 'none' | 'pending' | 'approved' | 'rejected';
  kills: number | null;
  placement: number | null;
  totalPoints: number | null;
}

export interface AnalyticsSnapshot {
  generatedAt: string;
  players: { total: number; active: number; suspended: number; banned: number; newLast14Days: number };
  teams: { total: number };
  tournaments: { byStatus: Record<string, number> };
  registrations: { byStatus: Record<string, number>; newLast14Days: number };
  matches: { byState: Record<string, number> };
  results: { byStatus: Record<string, number> };
  prizes: { byStatus: Record<string, { count: number; amountMinor: number }>; currency: string | null };
  dailyRegistrations: Array<{ day: string; count: number }>;
}
