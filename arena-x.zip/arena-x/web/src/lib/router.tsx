import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type AnchorHTMLAttributes,
  type MouseEvent,
  type ReactNode,
} from 'react';

/**
 * A small History API router. Routes are plain path patterns with :params. Navigation is
 * client-side, and the server falls back to index.html for every non-API path, so deep links work.
 */

interface Location {
  pathname: string;
  search: string;
}

interface RouterValue {
  location: Location;
  navigate: (to: string, options?: { replace?: boolean }) => void;
}

const RouterContext = createContext<RouterValue | null>(null);

function readLocation(): Location {
  return { pathname: window.location.pathname, search: window.location.search };
}

export function RouterProvider({ children }: { children: ReactNode }) {
  const [location, setLocation] = useState<Location>(readLocation);

  useEffect(() => {
    const onPop = () => setLocation(readLocation());
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const navigate = useCallback((to: string, options?: { replace?: boolean }) => {
    const url = new URL(to, window.location.origin);
    const next = `${url.pathname}${url.search}${url.hash}`;
    const current = `${window.location.pathname}${window.location.search}${window.location.hash}`;
    if (next !== current) {
      if (options?.replace) window.history.replaceState(null, '', next);
      else window.history.pushState(null, '', next);
    }
    setLocation({ pathname: url.pathname, search: url.search });
    window.scrollTo({ top: 0 });
  }, []);

  const value = useMemo(() => ({ location, navigate }), [location, navigate]);
  return <RouterContext.Provider value={value}>{children}</RouterContext.Provider>;
}

export function useRouter(): RouterValue {
  const value = useContext<RouterValue | null>(RouterContext);
  if (!value) throw new Error('useRouter must be used inside RouterProvider');
  return value;
}

export function useSearchParams(): URLSearchParams {
  const { location } = useRouter();
  return useMemo(() => new URLSearchParams(location.search), [location.search]);
}

/** Updates query parameters on the current path without adding history entries for each keystroke. */
export function useSetSearchParams(): (next: Record<string, string | undefined>) => void {
  const { location, navigate } = useRouter();
  return useCallback(
    (next) => {
      const params = new URLSearchParams(location.search);
      for (const [key, value] of Object.entries(next)) {
        if (value === undefined || value === '') params.delete(key);
        else params.set(key, value);
      }
      const query = params.toString();
      navigate(`${location.pathname}${query ? `?${query}` : ''}`, { replace: true });
    },
    [location.pathname, location.search, navigate],
  );
}

interface LinkProps extends Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
  to: string;
}

export function Link({ to, onClick, ...rest }: LinkProps) {
  const { navigate } = useRouter();
  const external = /^[a-z][a-z0-9+.-]*:/i.test(to) || to.startsWith('//');
  return (
    <a
      href={to}
      {...rest}
      onClick={(event: MouseEvent<HTMLAnchorElement>) => {
        onClick?.(event);
        if (
          external ||
          event.defaultPrevented ||
          event.button !== 0 ||
          event.metaKey ||
          event.ctrlKey ||
          event.shiftKey ||
          event.altKey
        ) {
          return;
        }
        event.preventDefault();
        navigate(to);
      }}
    />
  );
}

export function matchPattern(pattern: string, pathname: string): Record<string, string> | null {
  const expected = pattern.split('/').filter(Boolean);
  const actual = pathname.split('/').filter(Boolean);
  if (expected.length !== actual.length) return null;
  const params: Record<string, string> = {};
  for (let i = 0; i < expected.length; i++) {
    const segment = expected[i]!;
    if (segment.startsWith(':')) {
      try {
        params[segment.slice(1)] = decodeURIComponent(actual[i]!);
      } catch {
        return null;
      }
    } else if (segment !== actual[i]) {
      return null;
    }
  }
  return params;
}
