/** Client-side mirrors of server constants. The server remains the authority for every rule. */

export const AVATAR_KEYS = ['bolt', 'falcon', 'ember', 'frost', 'viper', 'nova', 'ghost', 'titan'] as const;

export const MODE_OPTIONS = [
  { id: 'solo', label: 'Solo', roster: 1 },
  { id: 'duo', label: 'Duo', roster: 2 },
  { id: 'squad', label: 'Squad', roster: 4 },
] as const;

export const ADMIN_NAV = [
  { to: '/admin', label: 'Overview' },
  { to: '/admin/tournaments', label: 'Tournaments' },
  { to: '/admin/submissions', label: 'Result review' },
  { to: '/admin/players', label: 'Players' },
  { to: '/admin/announcements', label: 'Announcements' },
  { to: '/admin/analytics', label: 'Analytics' },
  { to: '/admin/audit', label: 'Audit and exports' },
] as const;
