import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { api, errorMessage, fieldErrors } from '../lib/api.ts';
import { ADMIN_NAV } from '../lib/constants.ts';
import { badgeTone, formatDateTime, formatZoneLabel, label } from '../lib/format.ts';
import { Link, useRouter, useSearchParams, useSetSearchParams } from '../lib/router.tsx';
import { useAsync, useDocumentTitle } from '../lib/hooks.ts';
import { useSession } from '../lib/session.tsx';
import type { AdminDashboardData, AdminPlayer, AnalyticsSnapshot, AuditEvent, Submission, TournamentList, TournamentRecord } from '../lib/types.ts';
import { TournamentForm } from '../components/tournament.tsx';
import { Empty, Field, LoadingBlock, Modal, Notice, PageHead, StatusBadge, Tabs, announce } from '../components/ui.tsx';

/* ------------------------------------------------------------------ */
/* Layout                                                              */
/* ------------------------------------------------------------------ */

export function AdminLayout({ children }: { children: ReactNode }) {
  const { viewer, ready } = useSession();
  const { location } = useRouter();
  if (!ready) return <div className="container" style={{ padding: '2.4rem 0' }}><LoadingBlock rows={3} /></div>;
  if (!viewer) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <Notice tone="error">Sign in with an administrator account to open the admin portal.</Notice>
        <Link to="/admin/login?next=/admin" className="btn btn--primary">
          Sign in
        </Link>
      </div>
    );
  }
  if (viewer.role !== 'admin') {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <Notice tone="error" title="Permission required">
          Your account does not have access to the admin portal. Administrator accounts are created by the operator, not through sign-up.
        </Notice>
      </div>
    );
  }
  return (
    <div className="admin-shell">
      <aside className="admin-side" aria-label="Admin navigation">
        <div className="admin-side__label">Operations</div>
        {ADMIN_NAV.map((item) => {
          const current = item.to === '/admin' ? location.pathname === '/admin' : location.pathname.startsWith(item.to);
          return (
            <Link key={item.to} to={item.to} aria-current={current ? 'page' : undefined}>
              {item.label}
            </Link>
          );
        })}
        <div className="admin-side__label">Site</div>
        <Link to="/">Public site</Link>
      </aside>
      <div className="admin-main">{children}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Overview                                                            */
/* ------------------------------------------------------------------ */

export function AdminOverviewPage() {
  useDocumentTitle('Admin overview');
  const dash = useAsync(() => api<AdminDashboardData>('GET', '/api/admin/dashboard'), []);
  if (dash.loading && !dash.data) return <LoadingBlock rows={4} />;
  if (dash.error || !dash.data) return <Notice tone="error">{errorMessage(dash.error)}</Notice>;
  const d = dash.data;
  const tournamentStatuses = ['draft', 'scheduled', 'registration_open', 'registration_closed', 'live', 'completed', 'cancelled'];
  return (
    <>
      <PageHead eyebrow="Administration" title="Overview">
        <Link to="/admin/tournaments" className="btn btn--primary">
          Manage tournaments
        </Link>
      </PageHead>

      <div className="stat-row" style={{ marginBottom: 20 }}>
        <div className="stat">
          <span className="stat__value">{d.users.total}</span>
          <span className="stat__label">Accounts</span>
        </div>
        <div className="stat">
          <span className="stat__value">{d.users.restricted}</span>
          <span className="stat__label">Suspended or banned</span>
        </div>
        <Link to="/admin/submissions" className="stat" style={{ textDecoration: 'none' }}>
          <span className="stat__value" style={{ color: d.results.pendingReview > 0 ? 'var(--accent)' : undefined }}>
            {d.results.pendingReview}
          </span>
          <span className="stat__label">Results to review</span>
        </Link>
        <div className="stat">
          <span className="stat__value">{d.registrations.pendingApproval}</span>
          <span className="stat__label">Entries awaiting approval</span>
        </div>
      </div>

      <div className="grid-2">
        <section className="panel" aria-labelledby="by-status">
          <h2 id="by-status" style={{ fontSize: '1.1rem', marginBottom: 12 }}>
            Tournaments by status
          </h2>
          <table className="data">
            <tbody>
              {tournamentStatuses.map((status) => (
                <tr key={status}>
                  <td>
                    <StatusBadge status={status} />
                  </td>
                  <td className="num" style={{ textAlign: 'right' }}>
                    {d.tournaments[status] ?? 0}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="small" style={{ marginTop: 12 }}>
            {d.registrations.createdLast7Days} entries in the last 7 days · {d.matches.liveOrAwaitingResults} matches live or awaiting results
          </p>
        </section>

        <section className="panel" aria-labelledby="recent-audit">
          <div className="panel__head">
            <h2 id="recent-audit" style={{ fontSize: '1.1rem' }}>
              Recent activity
            </h2>
            <Link to="/admin/audit" className="small">
              Full audit log
            </Link>
          </div>
          {d.recentAudit.length === 0 ? (
            <p className="muted">No activity recorded yet.</p>
          ) : (
            <ul className="list">
              {d.recentAudit.map((a) => (
                <li key={a.seq} className="row row--between">
                  <span>
                    <span className="num small faint">#{a.seq}</span> {a.action.replace(/[._]/g, ' ')}
                  </span>
                  <span className="small faint">{formatDateTime(a.createdAt)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Tournament list and creation                                        */
/* ------------------------------------------------------------------ */

export function AdminTournamentsPage() {
  useDocumentTitle('Tournaments · Admin');
  const { navigate } = useRouter();
  const params = useSearchParams();
  const setParams = useSetSearchParams();
  const status = params.get('status') ?? '';
  const creating = params.get('new') === '1';
  const list = useAsync(() => {
    const query = new URLSearchParams({ limit: '100' });
    if (status) query.set('status', status);
    return api<TournamentList>('GET', `/api/admin/tournaments?${query.toString()}`);
  }, [status]);

  return (
    <>
      <PageHead eyebrow="Operations" title="Tournaments">
        <div className="btn-row">
          <select className="select" aria-label="Filter by status" value={status} onChange={(e) => setParams({ status: e.target.value || undefined })} style={{ minWidth: 180 }}>
            <option value="">All statuses</option>
            {['draft', 'scheduled', 'registration_open', 'registration_closed', 'live', 'completed', 'cancelled'].map((s) => (
              <option key={s} value={s}>
                {label(s)}
              </option>
            ))}
          </select>
          <button type="button" className="btn btn--primary" aria-expanded={creating} onClick={() => setParams({ new: creating ? undefined : '1' })}>
            {creating ? 'Close' : 'New tournament'}
          </button>
        </div>
      </PageHead>

      {creating ? (
        <section className="panel" style={{ marginBottom: 20 }} aria-labelledby="create-title">
          <h2 id="create-title" style={{ fontSize: '1.2rem', marginBottom: 16 }}>
            New tournament
          </h2>
          <TournamentForm
            onSaved={(t) => {
              announce('Tournament created as a draft.');
              navigate(`/admin/tournaments/${t.id}`);
            }}
            onCancel={() => setParams({ new: undefined })}
          />
        </section>
      ) : null}

      {list.error ? <Notice tone="error">{errorMessage(list.error)}</Notice> : null}
      {list.loading && !list.data ? <LoadingBlock rows={3} /> : null}
      {list.data && list.data.items.length === 0 ? <Empty title="No tournaments">Create one to start the lifecycle.</Empty> : null}
      {list.data && list.data.items.length > 0 ? (
        <div className="panel panel--flush">
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th scope="col">Tournament</th>
                  <th scope="col">Status</th>
                  <th scope="col">Mode</th>
                  <th scope="col">Starts</th>
                  <th scope="col" className="num">
                    Confirmed
                  </th>
                  <th scope="col" className="num">
                    Pending
                  </th>
                </tr>
              </thead>
              <tbody>
                {list.data.items.map((t: TournamentRecord) => (
                  <tr key={t.id}>
                    <td>
                      <Link to={`/admin/tournaments/${t.id}`} style={{ fontWeight: 600, textDecoration: 'none' }}>
                        {t.name}
                      </Link>
                      <div className="small faint">{t.slug}</div>
                    </td>
                    <td>
                      <StatusBadge status={t.status} />
                    </td>
                    <td>{label(t.mode)}</td>
                    <td>
                      {formatDateTime(t.startsAt, t.timezone)}
                      <div className="small faint">{formatZoneLabel(t.timezone)}</div>
                    </td>
                    <td className="num">
                      {t.confirmedCount}/{t.capacity}
                    </td>
                    <td className="num">{t.pendingCount ?? 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Result review queue (also used per tournament)                      */
/* ------------------------------------------------------------------ */

const REVIEW_STATUSES = ['pending', 'approved', 'rejected', 'superseded'] as const;

export function SubmissionQueue({ tournamentId, showTournament = true }: { tournamentId?: string; showTournament?: boolean }) {
  const [status, setStatus] = useState<(typeof REVIEW_STATUSES)[number]>('pending');
  const [action, setAction] = useState<null | { kind: 'reject' | 'correct'; item: Submission }>(null);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const queue = useAsync(() => {
    const query = new URLSearchParams({ status });
    if (tournamentId) query.set('tournamentId', tournamentId);
    return api<{ submissions: Submission[] }>('GET', `/api/admin/submissions?${query.toString()}`);
  }, [status, tournamentId]);

  const approve = async (item: Submission) => {
    setBusyId(item.id);
    setError(null);
    try {
      await api('POST', `/api/admin/submissions/${encodeURIComponent(item.id)}/decision`, { decision: 'approve' });
      setMessage(`Approved ${item.entrantName}: ${item.totalPoints ?? ''} points.`);
      announce('Result approved.');
      queue.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div>
      <Tabs
        name={`queue-${tournamentId ?? 'all'}`}
        items={REVIEW_STATUSES.map((s) => ({ id: s, label: label(s) }))}
        value={status}
        onChange={setStatus}
      />
      {message ? <Notice tone="success">{message}</Notice> : null}
      {error ? <Notice tone="error">{error}</Notice> : null}
      {queue.error ? <Notice tone="error">{errorMessage(queue.error)}</Notice> : null}
      {queue.loading && !queue.data ? <LoadingBlock rows={3} /> : null}
      {queue.data && queue.data.submissions.length === 0 ? (
        <Empty title={status === 'pending' ? 'Nothing to review' : 'No results here'}>
          {status === 'pending' ? 'Player submissions appear here as matches finish.' : 'Change the filter to see other results.'}
        </Empty>
      ) : null}
      {queue.data && queue.data.submissions.length > 0 ? (
        <div className="panel panel--flush">
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th scope="col">Entrant</th>
                  {showTournament ? <th scope="col">Tournament and round</th> : null}
                  <th scope="col" className="num">
                    Kills
                  </th>
                  <th scope="col" className="num">
                    Place
                  </th>
                  <th scope="col">Evidence</th>
                  <th scope="col">Submitted</th>
                  <th scope="col">Status</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                {queue.data.submissions.map((s) => (
                  <tr key={s.id}>
                    <td>
                      <strong>{s.entrantName}</strong>
                      {s.notes ? <div className="small muted">{s.notes}</div> : null}
                    </td>
                    {showTournament ? (
                      <td>
                        {s.tournamentName}
                        <div className="small faint">{s.matchRound}</div>
                      </td>
                    ) : null}
                    <td className="num">{s.kills}</td>
                    <td className="num">{s.placement}</td>
                    <td>
                      {s.evidenceUrl ? (
                        <a href={s.evidenceUrl} target="_blank" rel="noopener noreferrer">
                          Open link
                        </a>
                      ) : (
                        <span className="faint">None</span>
                      )}
                    </td>
                    <td className="small">{formatDateTime(s.createdAt)}</td>
                    <td>
                      <StatusBadge status={s.status} />
                      {s.reviewReason ? <div className="small muted">{s.reviewReason}</div> : null}
                      {s.totalPoints !== null ? <div className="small num">{s.totalPoints} pts</div> : null}
                    </td>
                    <td>
                      {s.status === 'pending' ? (
                        <div className="btn-row">
                          <button type="button" className="btn btn--sm btn--primary" disabled={busyId === s.id} onClick={() => void approve(s)}>
                            Approve
                          </button>
                          <button type="button" className="btn btn--sm btn--danger" disabled={busyId === s.id} onClick={() => setAction({ kind: 'reject', item: s })}>
                            Reject
                          </button>
                        </div>
                      ) : null}
                      {s.status === 'approved' ? (
                        <button type="button" className="btn btn--sm" onClick={() => setAction({ kind: 'correct', item: s })}>
                          Correct
                        </button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}

      {action?.kind === 'reject' ? (
        <ReasonModal
          title={`Reject ${action.item.entrantName}'s result?`}
          label="Reason shown to the player"
          minLength={5}
          submitLabel="Reject result"
          danger
          onClose={() => setAction(null)}
          onSubmit={async (reason) => {
            await api('POST', `/api/admin/submissions/${encodeURIComponent(action.item.id)}/decision`, { decision: 'reject', reason });
            setMessage(`Rejected ${action.item.entrantName}'s result. They can submit again.`);
            announce('Result rejected.');
            setAction(null);
            queue.reload();
          }}
        />
      ) : null}
      {action?.kind === 'correct' ? (
        <CorrectionModal
          item={action.item}
          onClose={() => setAction(null)}
          onDone={() => {
            setMessage('Correction recorded. The earlier result is kept in the audit trail.');
            announce('Correction recorded.');
            setAction(null);
            queue.reload();
          }}
        />
      ) : null}
    </div>
  );
}

export function ReasonModal({
  title,
  label: text,
  minLength,
  submitLabel,
  danger = false,
  onClose,
  onSubmit,
}: {
  title: string;
  label: string;
  minLength: number;
  submitLabel: string;
  danger?: boolean;
  onClose: () => void;
  onSubmit: (reason: string) => Promise<void>;
}) {
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (reason.trim().length < minLength) {
      setError(`Give a reason of at least ${minLength} characters.`);
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await onSubmit(reason.trim());
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={title} onClose={onClose}>
      {error ? <Notice tone="error">{error}</Notice> : null}
      <form onSubmit={submit} noValidate>
        <Field id="reason" label={text} hint={`At least ${minLength} characters.`}>
          <textarea id="reason" className="textarea" style={{ minHeight: 90 }} value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} />
        </Field>
        <div className="btn-row" style={{ justifyContent: 'flex-end' }}>
          <button type="button" className="btn btn--ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className={`btn ${danger ? 'btn--danger' : 'btn--primary'}`} disabled={busy}>
            {busy ? 'Saving…' : submitLabel}
          </button>
        </div>
      </form>
    </Modal>
  );
}

function CorrectionModal({ item, onClose, onDone }: { item: Submission; onClose: () => void; onDone: () => void }) {
  const [kills, setKills] = useState(String(item.kills));
  const [placement, setPlacement] = useState(String(item.placement));
  const [reason, setReason] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setBusy(true);
    setErrors({});
    setFormError(null);
    try {
      await api('POST', `/api/admin/results/${encodeURIComponent(item.id)}/correct`, {
        kills: Number(kills),
        placement: Number(placement),
        reason: reason.trim(),
      });
      onDone();
    } catch (err) {
      setErrors(fieldErrors(err));
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title={`Correct ${item.entrantName}'s result`} onClose={onClose}>
      <p className="small">The earlier approved result is replaced and kept in the audit trail. Standings update immediately, unless the tournament is finalised.</p>
      {formError ? <Notice tone="error">{formError}</Notice> : null}
      <form onSubmit={submit} noValidate>
        <div className="form-grid">
          <Field id="corr-kills" label="Kills" error={errors.kills}>
            <input id="corr-kills" className="input num" type="number" min={0} max={99} value={kills} onChange={(e) => setKills(e.target.value)} />
          </Field>
          <Field id="corr-place" label="Placement" error={errors.placement}>
            <input id="corr-place" className="input num" type="number" min={1} max={50} value={placement} onChange={(e) => setPlacement(e.target.value)} />
          </Field>
          <div className="span-2">
            <Field id="corr-reason" label="Why is this correction needed?" hint="At least 10 characters." error={errors.reason}>
              <textarea id="corr-reason" className="textarea" style={{ minHeight: 80 }} value={reason} onChange={(e) => setReason(e.target.value)} />
            </Field>
          </div>
        </div>
        <div className="btn-row" style={{ justifyContent: 'flex-end' }}>
          <button type="button" className="btn btn--ghost" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn--primary" disabled={busy}>
            {busy ? 'Saving…' : 'Record correction'}
          </button>
        </div>
      </form>
    </Modal>
  );
}

/* ------------------------------------------------------------------ */
/* Result review page                                                  */
/* ------------------------------------------------------------------ */

export function AdminSubmissionsPage() {
  useDocumentTitle('Result review · Admin');
  return (
    <>
      <PageHead eyebrow="Verification" title="Result review">
        <p className="muted" style={{ margin: 0 }}>
          Approved results feed standings. Each approval stores the scoring rules in force at that moment.
        </p>
      </PageHead>
      <SubmissionQueue />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Players and moderation                                              */
/* ------------------------------------------------------------------ */

export function AdminPlayersPage() {
  useDocumentTitle('Players · Admin');
  const [q, setQ] = useState('');
  const [query, setQuery] = useState('');
  const [offset, setOffset] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const players = useAsync(() => {
    const params = new URLSearchParams({ limit: '25', offset: String(offset) });
    if (query) params.set('q', query);
    return api<{ players: AdminPlayer[] }>('GET', `/api/admin/players?${params.toString()}`);
  }, [query, offset]);

  return (
    <>
      <PageHead eyebrow="Community" title="Players" />
      <form
        className="toolbar"
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          setOffset(0);
          setQuery(q.trim());
        }}
      >
        <label htmlFor="player-q" className="sr-only">
          Search by email, name or in-game ID
        </label>
        <input id="player-q" className="input" placeholder="Search email, name or in-game ID" value={q} onChange={(e) => setQ(e.target.value)} style={{ minWidth: 280 }} />
        <button type="submit" className="btn">
          Search
        </button>
      </form>
      <div className="grid-2">
        <div>
          {players.error ? <Notice tone="error">{errorMessage(players.error)}</Notice> : null}
          {players.loading && !players.data ? <LoadingBlock rows={3} /> : null}
          {players.data && players.data.players.length === 0 ? <Empty title="No players found" /> : null}
          {players.data && players.data.players.length > 0 ? (
            <div className="panel panel--flush">
              <div className="table-wrap">
                <table className="data">
                  <thead>
                    <tr>
                      <th scope="col">Player</th>
                      <th scope="col">In-game ID</th>
                      <th scope="col">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {players.data.players.map((p) => (
                      <tr key={p.id} className={selected === p.id ? 'is-first' : undefined}>
                        <td>
                          <button
                            type="button"
                            className="btn btn--ghost btn--sm"
                            style={{ padding: 0, minHeight: 0, justifyContent: 'flex-start', textAlign: 'left' }}
                            aria-pressed={selected === p.id}
                            onClick={() => setSelected(p.id)}
                          >
                            <span>
                              <strong>{p.displayName}</strong>
                              <div className="small faint">{p.email}</div>
                            </span>
                          </button>
                        </td>
                        <td className="num">{p.inGameId ?? '–'}</td>
                        <td>
                          <StatusBadge status={p.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : null}
          <div className="btn-row" style={{ marginTop: 12 }}>
            <button type="button" className="btn btn--sm" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - 25))}>
              Previous
            </button>
            <button type="button" className="btn btn--sm" disabled={!players.data || players.data.players.length < 25} onClick={() => setOffset(offset + 25)}>
              Next
            </button>
          </div>
        </div>
        <div>{selected ? <PlayerDetail id={selected} /> : <Empty title="Select a player">Their registrations and moderation history appear here.</Empty>}</div>
      </div>
    </>
  );
}

function PlayerDetail({ id }: { id: string }) {
  const { viewer } = useSession();
  const detail = useAsync(
    () =>
      api<{
        player: AdminPlayer & { updatedAt: string };
        moderation: Array<{ id: string; action: string; reason: string; until: string | null; createdAt: string }>;
        registrations: Array<{ id: string; tournamentId: string; tournamentName: string; status: string; kind: string; createdAt: string }>;
      }>('GET', `/api/admin/players/${encodeURIComponent(id)}`),
    [id],
  );
  const [action, setAction] = useState<'suspend' | 'ban' | 'reinstate'>('suspend');
  const [days, setDays] = useState('7');
  const [reason, setReason] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const isSelf = viewer?.id === id;

  const moderate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setMessage(null);
    if (reason.trim().length < 5) {
      setError('Give a reason of at least 5 characters.');
      return;
    }
    setBusy(true);
    try {
      const body: Record<string, unknown> = { action, reason: reason.trim() };
      if (action === 'suspend') body.days = Number(days);
      const data = await api<{ result: { status: string } }>('POST', `/api/admin/players/${encodeURIComponent(id)}/moderation`, body);
      setMessage(`Done. The account is now ${label(data.result.status).toLowerCase()}. Their sessions were signed out.`);
      announce('Moderation action recorded.');
      setReason('');
      detail.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  if (detail.loading && !detail.data) return <LoadingBlock rows={3} />;
  if (detail.error || !detail.data) return <Notice tone="error">{errorMessage(detail.error)}</Notice>;
  const d = detail.data;

  return (
    <div className="stack">
      <section className="panel">
        <div className="row row--between">
          <div>
            <h2 style={{ fontSize: '1.2rem', textTransform: 'none', fontFamily: 'var(--font-body)' }}>{d.player.displayName}</h2>
            <div className="small muted">{d.player.email}</div>
            <div className="small num">In-game ID {d.player.inGameId ?? 'not set'}</div>
          </div>
          <StatusBadge status={d.player.status} />
        </div>
        {d.player.suspendedUntil ? <p className="small" style={{ marginTop: 8 }}>Suspended until {formatDateTime(d.player.suspendedUntil)}</p> : null}
      </section>

      <section className="panel">
        <h3 style={{ fontSize: '1rem', marginBottom: 10 }}>Moderate account</h3>
        {isSelf ? <Notice tone="info">You cannot moderate your own account.</Notice> : null}
        {message ? <Notice tone="success">{message}</Notice> : null}
        {error ? <Notice tone="error">{error}</Notice> : null}
        <form onSubmit={moderate} noValidate>
          <fieldset style={{ border: 0, padding: 0, margin: '0 0 12px' }} disabled={isSelf}>
            <legend className="field__label" style={{ marginBottom: 8 }}>
              Action
            </legend>
            <div className="row" style={{ gap: 14 }}>
              {(['suspend', 'ban', 'reinstate'] as const).map((a) => (
                <label key={a} className="checkbox" style={{ marginBottom: 0 }}>
                  <input type="radio" name="mod-action" checked={action === a} onChange={() => setAction(a)} />
                  <span>{label(a)}</span>
                </label>
              ))}
            </div>
          </fieldset>
          {action === 'suspend' ? (
            <Field id="mod-days" label="Suspension length (days)" hint="1 to 365 days.">
              <input id="mod-days" className="input num" type="number" min={1} max={365} value={days} onChange={(e) => setDays(e.target.value)} />
            </Field>
          ) : null}
          <Field id="mod-reason" label="Reason (recorded and shown to the player)" hint="At least 5 characters.">
            <textarea id="mod-reason" className="textarea" style={{ minHeight: 80 }} value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} />
          </Field>
          <button type="submit" className={`btn ${action === 'reinstate' ? 'btn--primary' : 'btn--danger'}`} disabled={busy || isSelf}>
            {busy ? 'Saving…' : `Apply: ${label(action)}`}
          </button>
        </form>
      </section>

      <section className="panel">
        <h3 style={{ fontSize: '1rem', marginBottom: 10 }}>Moderation history</h3>
        {d.moderation.length === 0 ? <p className="muted">No actions recorded.</p> : null}
        <ul className="list">
          {d.moderation.map((m) => (
            <li key={m.id}>
              <strong>{label(m.action)}</strong> <span className="small faint">{formatDateTime(m.createdAt)}</span>
              <div className="small">{m.reason}</div>
            </li>
          ))}
        </ul>
      </section>

      <section className="panel">
        <h3 style={{ fontSize: '1rem', marginBottom: 10 }}>Entries</h3>
        {d.registrations.length === 0 ? <p className="muted">No entries yet.</p> : null}
        <ul className="list">
          {d.registrations.map((r) => (
            <li key={r.id} className="row row--between">
              <Link to={`/admin/tournaments/${r.tournamentId}`} style={{ textDecoration: 'none' }}>
                {r.tournamentName}
              </Link>
              <span className="row" style={{ gap: 6 }}>
                <span className={`badge badge--${badgeTone(r.status)}`}>{label(r.kind)}</span>
                <StatusBadge status={r.status} />
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Announcements                                                       */
/* ------------------------------------------------------------------ */

export function AdminAnnouncementsPage() {
  useDocumentTitle('Announcements · Admin');
  const items = useAsync(() => api<{ items: Array<{ id: string; title: string; body: string; createdAt: string }> }>('GET', '/api/admin/announcements'), []);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const publish = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setFormError(null);
    setMessage(null);
    setBusy(true);
    try {
      await api('POST', '/api/admin/announcements', { title: title.trim(), body: body.trim() });
      setTitle('');
      setBody('');
      setMessage('Published. Every active player has been notified.');
      announce('Announcement published.');
      items.reload();
    } catch (err) {
      setErrors(fieldErrors(err));
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHead eyebrow="Communications" title="Announcements" />
      <div className="grid-2">
        <section className="panel" aria-labelledby="new-ann">
          <h2 id="new-ann" style={{ fontSize: '1.1rem', marginBottom: 12 }}>
            Publish an announcement
          </h2>
          {message ? <Notice tone="success">{message}</Notice> : null}
          {formError ? <Notice tone="error">{formError}</Notice> : null}
          <form onSubmit={publish} noValidate>
            <Field id="ann-title" label="Title" hint="3 to 120 characters." error={errors.title}>
              <input id="ann-title" className="input" value={title} onChange={(e) => setTitle(e.target.value)} aria-invalid={Boolean(errors.title)} />
            </Field>
            <Field id="ann-body" label="Message" hint="10 to 4,000 characters. Notifications show the first 240." error={errors.body}>
              <textarea id="ann-body" className="textarea" value={body} onChange={(e) => setBody(e.target.value)} aria-invalid={Boolean(errors.body)} />
            </Field>
            <button type="submit" className="btn btn--primary" disabled={busy}>
              {busy ? 'Publishing…' : 'Publish to all players'}
            </button>
          </form>
        </section>
        <section className="panel" aria-labelledby="past-ann">
          <h2 id="past-ann" style={{ fontSize: '1.1rem', marginBottom: 12 }}>
            Published
          </h2>
          {items.loading && !items.data ? <LoadingBlock rows={2} /> : null}
          {items.data && items.data.items.length === 0 ? <p className="muted">Nothing published yet.</p> : null}
          <ul className="list">
            {items.data?.items.map((a) => (
              <li key={a.id}>
                <strong>{a.title}</strong> <span className="small faint">{formatDateTime(a.createdAt)}</span>
                <p className="small" style={{ margin: '4px 0 0', whiteSpace: 'pre-wrap' }}>
                  {a.body}
                </p>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Audit and exports                                                   */
/* ------------------------------------------------------------------ */

const EXPORTS = [
  { id: 'registrations', label: 'Registrations', note: 'Entries with member names and in-game IDs' },
  { id: 'results', label: 'Results', note: 'Every submission, its status and points' },
  { id: 'leaderboard', label: 'Leaderboard', note: 'Ranking built from approved results' },
  { id: 'players', label: 'Players', note: 'Accounts without email addresses' },
  { id: 'audit', label: 'Audit log', note: 'The complete event trail' },
] as const;

export function AdminAuditPage() {
  useDocumentTitle('Audit and exports · Admin');
  const [events, setEvents] = useState<AuditEvent[] | null>(null);
  const [cursor, setCursor] = useState<number | null>(null);
  const [entity, setEntity] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [verify, setVerify] = useState<null | { ok: boolean; checked: number; brokenAtSeq: number | null }>(null);
  const [loading, setLoading] = useState(false);

  const load = async (before?: number) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ limit: '50' });
      if (before) params.set('before', String(before));
      if (entity) params.set('entityType', entity);
      const data = await api<{ items: AuditEvent[]; nextCursor: number | null }>('GET', `/api/admin/audit?${params.toString()}`);
      setEvents((previous) => (before && previous ? [...previous, ...data.items] : data.items));
      setCursor(data.nextCursor);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const runVerify = async () => {
    setError(null);
    try {
      setVerify(await api<{ ok: boolean; checked: number; brokenAtSeq: number | null }>('GET', '/api/admin/audit/verify'));
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  useEffect(() => {
    void load();
    // Reload the first page whenever the entity filter changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entity]);

  return (
    <>
      <PageHead eyebrow="Accountability" title="Audit and exports">
        <button type="button" className="btn" onClick={() => void runVerify()}>
          Verify audit chain
        </button>
      </PageHead>

      {verify ? (
        <Notice tone={verify.ok ? 'success' : 'error'} title={verify.ok ? 'Chain intact' : 'Chain broken'}>
          {verify.ok
            ? `${verify.checked} events checked. Every hash links to the one before it.`
            : `The chain breaks at event #${verify.brokenAtSeq}. Treat the log as altered until investigated.`}
        </Notice>
      ) : null}
      {error ? <Notice tone="error">{error}</Notice> : null}

      <section className="panel" style={{ marginBottom: 20 }} aria-labelledby="exports">
        <h2 id="exports" style={{ fontSize: '1.1rem', marginBottom: 12 }}>
          CSV exports
        </h2>
        <p className="small" style={{ marginBottom: 12 }}>
          Exports are recorded in the audit log. Values starting with = + - or @ are neutralised so spreadsheets will not run them.
        </p>
        <div className="grid-3">
          {EXPORTS.map((e) => (
            <a key={e.id} href={`/api/admin/export/${e.id}`} className="panel" download style={{ textDecoration: 'none' }}>
              <strong style={{ color: 'var(--text)' }}>{e.label}.csv</strong>
              <div className="small muted">{e.note}</div>
            </a>
          ))}
        </div>
      </section>

      <section className="panel panel--flush" aria-labelledby="events">
        <div className="panel__head">
          <h2 id="events" style={{ fontSize: '1.1rem' }}>
            Events
          </h2>
          <label className="small">
            Entity type{' '}
            <select className="select" style={{ minWidth: 160, marginLeft: 6 }} value={entity} onChange={(e) => setEntity(e.target.value)}>
              <option value="">All</option>
              <option value="tournament">Tournament</option>
              <option value="registration">Registration</option>
              <option value="result_submission">Result</option>
              <option value="user">User</option>
              <option value="prize_award">Prize</option>
              <option value="room">Room</option>
              <option value="announcement">Announcement</option>
            </select>
          </label>
        </div>
        {loading && !events ? <LoadingBlock rows={3} /> : null}
        {events && events.length === 0 ? <div style={{ padding: '0 1.25rem 1.25rem' }}><Empty title="No events">Activity will be recorded here.</Empty></div> : null}
        {events && events.length > 0 ? (
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th scope="col" className="num">
                    #
                  </th>
                  <th scope="col">When</th>
                  <th scope="col">Action</th>
                  <th scope="col">Actor</th>
                  <th scope="col">Detail</th>
                  <th scope="col">Hash</th>
                </tr>
              </thead>
              <tbody>
                {events.map((e) => (
                  <tr key={e.seq}>
                    <td className="num">{e.seq}</td>
                    <td className="small">{formatDateTime(e.createdAt)}</td>
                    <td>
                      <code>{e.action}</code>
                      <div className="small faint">{e.entityType}</div>
                    </td>
                    <td className="small">{e.actorRole ?? 'system'}</td>
                    <td className="small" style={{ maxWidth: 360, wordBreak: 'break-word' }}>
                      {Object.keys(e.detail).length ? JSON.stringify(e.detail) : '–'}
                    </td>
                    <td>
                      <code className="small faint">{e.hash}</code>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
        {cursor !== null ? (
          <div style={{ textAlign: 'center', padding: '1rem' }}>
            <button type="button" className="btn btn--sm" disabled={loading} onClick={() => void load(cursor)}>
              {loading ? 'Loading…' : 'Load older events'}
            </button>
          </div>
        ) : null}
      </section>
    </>
  );
}


/* ------------------------------------------------------------------ */
/* Analytics                                                           */
/* ------------------------------------------------------------------ */

export function AdminAnalyticsPage() {
  useDocumentTitle('Analytics');
  const data = useAsync(() => api<{ analytics: AnalyticsSnapshot }>('GET', '/api/admin/analytics').then((r) => r.analytics), []);
  if (data.loading && !data.data) return <LoadingBlock rows={4} />;
  if (data.error || !data.data) return <Notice tone="error">{errorMessage(data.error)}</Notice>;
  const a = data.data;
  const maxDaily = Math.max(1, ...a.dailyRegistrations.map((d) => d.count));
  const prizeRows = Object.entries(a.prizes.byStatus);

  return (
    <>
      <PageHead eyebrow="Administration" title="Analytics" actions={<span className="small faint">Generated {formatDateTime(a.generatedAt)}</span>}>
        <p className="small">Counts come straight from the database at the moment of this request. Prize figures are records for the operator, not payments.</p>
      </PageHead>

      <div className="stat-row" style={{ marginBottom: 20 }}>
        <div className="stat">
          <span className="stat__value">{a.players.total}</span>
          <span className="stat__label">Players ({a.players.newLast14Days} new in 14 days)</span>
        </div>
        <div className="stat">
          <span className="stat__value">{a.players.active}</span>
          <span className="stat__label">Active accounts</span>
        </div>
        <div className="stat">
          <span className="stat__value">{a.teams.total}</span>
          <span className="stat__label">Teams</span>
        </div>
        <div className="stat">
          <span className="stat__value">{a.registrations.newLast14Days}</span>
          <span className="stat__label">Registrations in 14 days</span>
        </div>
      </div>

      <div className="grid-2" style={{ marginBottom: 20 }}>
        <section className="panel" aria-labelledby="daily-title">
          <h2 id="daily-title" className="h3">Registrations per day</h2>
          <p className="small faint">Last 14 days, oldest first.</p>
          <table className="data" style={{ marginTop: 10 }}>
            <caption className="sr-only">Registrations per day, last 14 days</caption>
            <thead>
              <tr>
                <th scope="col">Day</th>
                <th scope="col">Registrations</th>
              </tr>
            </thead>
            <tbody>
              {a.dailyRegistrations.map((d) => (
                <tr key={d.day}>
                  <td className="small">{d.day}</td>
                  <td>
                    <div className="bar-row">
                      <div className="bar" style={{ width: `${Math.round((d.count / maxDaily) * 100)}%` }} aria-hidden="true" />
                      <span className="num">{d.count}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>

        <section className="panel" aria-labelledby="status-title">
          <h2 id="status-title" className="h3">Pipeline</h2>
          <dl className="kv" style={{ marginTop: 10 }}>
            <dt>Tournaments</dt>
            <dd>{formatCountsInline(a.tournaments.byStatus)}</dd>
            <dt>Registrations</dt>
            <dd>{formatCountsInline(a.registrations.byStatus)}</dd>
            <dt>Matches</dt>
            <dd>{formatCountsInline(a.matches.byState)}</dd>
            <dt>Result claims</dt>
            <dd>{formatCountsInline(a.results.byStatus)}</dd>
            <dt>Accounts</dt>
            <dd>
              {a.players.suspended} suspended, {a.players.banned} banned
            </dd>
          </dl>
        </section>
      </div>

      <section className="panel" aria-labelledby="prize-title">
        <h2 id="prize-title" className="h3">Prize records</h2>
        <p className="small faint">Recorded amounts only. No money has moved through this platform.</p>
        {prizeRows.length === 0 ? (
          <Empty title="No prize records yet">Prize records appear here once a tournament is finalised.</Empty>
        ) : (
          <div className="table-wrap" style={{ marginTop: 10 }}>
            <table className="data">
              <thead>
                <tr>
                  <th scope="col">Status</th>
                  <th scope="col" className="num">Count</th>
                  <th scope="col" className="num">Amount ({a.prizes.currency ?? 'mixed'})</th>
                </tr>
              </thead>
              <tbody>
                {prizeRows.map(([status, v]) => (
                  <tr key={status}>
                    <td>
                      <StatusBadge status={status} text={label(status)} />
                    </td>
                    <td className="num">{v.count}</td>
                    <td className="num">{formatMinorAmount(v.amountMinor, a.prizes.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  );
}

function formatCountsInline(counts: Record<string, number>): string {
  const entries = Object.entries(counts).filter(([, n]) => n > 0);
  if (entries.length === 0) return 'None yet';
  return entries.map(([key, n]) => `${label(key)} ${n}`).join(' · ');
}

function formatMinorAmount(amountMinor: number, currency: string | null): string {
  const major = amountMinor / 100;
  if (!currency) return major.toFixed(2);
  try {
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency }).format(major);
  } catch {
    return `${major.toFixed(2)} ${currency}`;
  }
}
