import { useState, type FormEvent } from 'react';
import { api, errorMessage, fieldErrors } from '../lib/api.ts';
import { safeInternalPath } from '../lib/format.ts';
import { Link, useRouter, useSearchParams } from '../lib/router.tsx';
import { useDocumentTitle } from '../lib/hooks.ts';
import { useSession } from '../lib/session.tsx';
import { AVATAR_KEYS } from '../lib/constants.ts';
import type { Viewer } from '../lib/types.ts';
import { Avatar, Field, Notice } from '../components/ui.tsx';

function afterSignInPath(viewer: Viewer, next: string | null): string {
  const safe = safeInternalPath(next);
  if (safe) return safe;
  return viewer.role === 'admin' ? '/admin' : '/dashboard';
}

export function LoginPage() {
  useDocumentTitle('Sign in');
  const { navigate } = useRouter();
  const params = useSearchParams();
  const { refresh } = useSession();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setFormError(null);
    if (!email.trim() || !password) {
      setErrors({ email: email.trim() ? '' : 'Enter the email on your account.', password: password ? '' : 'Enter your password.' });
      setFormError('Enter your email and password.');
      return;
    }
    setBusy(true);
    try {
      const data = await api<{ viewer: Viewer }>('POST', '/api/auth/login', { email: email.trim(), password });
      await refresh();
      navigate(afterSignInPath(data.viewer, params.get('next')), { replace: true });
    } catch (error) {
      setErrors(fieldErrors(error));
      setFormError(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  const next = params.get('next');
  return (
    <div className="container auth">
      <section aria-labelledby="login-title">
        <span className="eyebrow">Welcome back</span>
        <h1 id="login-title" style={{ margin: '0.6rem 0 1rem' }}>
          Sign in to ARENA X
        </h1>
        <p style={{ maxWidth: '44ch' }}>Check your room details, track your entries and report results from one place.</p>
        <p className="small">
          New here? <Link to={next ? `/register?next=${encodeURIComponent(next)}` : '/register'}>Create an account</Link>
        </p>
      </section>

      <section className="auth__panel" aria-label="Sign-in form">
        {formError ? <Notice tone="error">{formError}</Notice> : null}
        <form onSubmit={submit} noValidate>
          <Field id="login-email" label="Email" error={errors.email || undefined}>
            <input
              id="login-email"
              className="input"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? 'login-email-error' : undefined}
              required
            />
          </Field>
          <Field id="login-password" label="Password" error={errors.password || undefined}>
            <input
              id="login-password"
              className="input"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              aria-invalid={Boolean(errors.password)}
              required
            />
          </Field>
          <button type="submit" className="btn btn--primary btn--block" disabled={busy}>
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
        <p className="small" style={{ marginTop: 14 }}>
          Forgotten your password? Password recovery is not available yet. Ask the operator of this installation to reset it.
        </p>
      </section>
    </div>
  );
}

export function RegisterPage() {
  useDocumentTitle('Create account');
  const { navigate } = useRouter();
  const params = useSearchParams();
  const { refresh } = useSession();
  const [values, setValues] = useState({ displayName: '', email: '', password: '', inGameId: '', avatarKey: 'titan' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (key: keyof typeof values, value: string) => setValues((previous) => ({ ...previous, [key]: value }));

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setFormError(null);
    const body: Record<string, string> = {
      displayName: values.displayName.trim(),
      email: values.email.trim(),
      password: values.password,
      avatarKey: values.avatarKey,
    };
    if (values.inGameId.trim()) body.inGameId = values.inGameId.trim();
    setBusy(true);
    try {
      await api<{ viewer: Viewer }>('POST', '/api/auth/register', body);
      await refresh();
      navigate(safeInternalPath(params.get('next')) ?? '/dashboard', { replace: true });
    } catch (error) {
      const fields = fieldErrors(error);
      setErrors(fields);
      setFormError(Object.keys(fields).length ? 'Check the highlighted fields.' : errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container auth">
      <section aria-labelledby="register-title">
        <span className="eyebrow">Create account</span>
        <h1 id="register-title" style={{ margin: '0.6rem 0 1rem' }}>
          Join the arena
        </h1>
        <p style={{ maxWidth: '46ch' }}>
          Your Free Fire MAX in-game ID is what tournaments use to identify you. You can add it now or later, but you need it before you can
          enter a tournament.
        </p>
        <ul className="small" style={{ paddingLeft: 18, display: 'grid', gap: 6 }}>
          <li>Passwords are stored as salted hashes, never in plain text.</li>
          <li>Room details are only shown to players entered in a match.</li>
          <li>Administrator access is never granted through this form.</li>
        </ul>
      </section>

      <section className="auth__panel" aria-label="Registration form">
        {formError ? <Notice tone="error">{formError}</Notice> : null}
        <form onSubmit={submit} noValidate>
          <Field id="reg-name" label="Display name" hint="3 to 24 characters: letters, numbers, spaces, dots, dashes or underscores." error={errors.displayName}>
            <input id="reg-name" className="input" autoComplete="nickname" value={values.displayName} onChange={(e) => set('displayName', e.target.value)} aria-invalid={Boolean(errors.displayName)} required />
          </Field>
          <Field id="reg-email" label="Email" error={errors.email}>
            <input id="reg-email" className="input" type="email" autoComplete="email" value={values.email} onChange={(e) => set('email', e.target.value)} aria-invalid={Boolean(errors.email)} required />
          </Field>
          <Field id="reg-password" label="Password" hint="At least 10 characters." error={errors.password}>
            <input id="reg-password" className="input" type="password" autoComplete="new-password" value={values.password} onChange={(e) => set('password', e.target.value)} aria-invalid={Boolean(errors.password)} required />
          </Field>
          <Field id="reg-ingame" label="Free Fire MAX in-game ID (optional for now)" hint="6 to 12 digits, found in your game profile." error={errors.inGameId}>
            <input id="reg-ingame" className="input num" inputMode="numeric" autoComplete="off" value={values.inGameId} onChange={(e) => set('inGameId', e.target.value)} aria-invalid={Boolean(errors.inGameId)} />
          </Field>
          <fieldset style={{ border: 0, padding: 0, margin: '0 0 1.2rem' }}>
            <legend className="field__label" style={{ marginBottom: 8 }}>
              Avatar
            </legend>
            <div className="row" style={{ gap: 8 }}>
              {AVATAR_KEYS.map((key) => (
                <label key={key} className="chip" style={{ padding: 4, cursor: 'pointer' }}>
                  <input type="radio" name="avatar" value={key} checked={values.avatarKey === key} onChange={() => set('avatarKey', key)} className="sr-only" />
                  <Avatar avatarKey={key} size="sm" />
                  <span className="sr-only">{key}</span>
                </label>
              ))}
            </div>
          </fieldset>
          <button type="submit" className="btn btn--primary btn--block" disabled={busy}>
            {busy ? 'Creating account…' : 'Create account'}
          </button>
        </form>
        <p className="small" style={{ marginTop: 14 }}>
          Already registered? <Link to="/login">Sign in</Link>
        </p>
      </section>
    </div>
  );
}

/**
 * Separate administrator sign-in. Uses its own endpoint, which refuses player accounts even when the
 * password is correct, so a player cannot reach administrator screens through this door.
 */
export function AdminLoginPage() {
  useDocumentTitle('Administrator sign-in');
  const { navigate } = useRouter();
  const { refresh } = useSession();
  const params = useSearchParams();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setFormError(null);
    if (!email.trim() || !password) {
      setErrors({ email: email.trim() ? '' : 'Enter the administrator email.', password: password ? '' : 'Enter the password.' });
      setFormError('Enter the administrator email and password.');
      return;
    }
    setBusy(true);
    try {
      await api('POST', '/api/admin/auth/login', { email: email.trim(), password });
      await refresh();
      navigate(safeInternalPath(params.get('next')) ?? '/admin', { replace: true });
    } catch (error) {
      setErrors(fieldErrors(error));
      setFormError(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container auth">
      <section aria-labelledby="admin-login-title">
        <span className="eyebrow">Operations</span>
        <h1 id="admin-login-title" style={{ margin: '0.6rem 0 1rem' }}>
          Administrator sign-in
        </h1>
        <p style={{ maxWidth: '44ch' }}>Tournaments, results, prizes and moderation. Player accounts cannot sign in here.</p>
        <p className="small">
          Player? <Link to="/login">Use the player sign-in</Link>
        </p>
      </section>

      <section className="auth__panel" aria-label="Administrator sign-in form">
        {formError ? <Notice tone="error">{formError}</Notice> : null}
        <form onSubmit={submit} noValidate>
          <Field id="admin-login-email" label="Administrator email" error={errors.email || undefined}>
            <input
              id="admin-login-email"
              className="input"
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              aria-invalid={Boolean(errors.email)}
              required
            />
          </Field>
          <Field id="admin-login-password" label="Password" error={errors.password || undefined}>
            <input
              id="admin-login-password"
              className="input"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              aria-invalid={Boolean(errors.password)}
              required
            />
          </Field>
          <button type="submit" className="btn btn--primary btn--block" disabled={busy}>
            {busy ? 'Signing in…' : 'Sign in as administrator'}
          </button>
        </form>
        <p className="small" style={{ marginTop: 14 }}>
          Administrator sessions end after 8 hours of use. Sign out when you leave a shared computer.
        </p>
      </section>
    </div>
  );
}
