import { useState, type FormEvent } from 'react';
import { api, errorMessage, fieldErrors } from '../lib/api.ts';
import { formatDateTime, formatMoney, formatZoneLabel, isoToZonedLocal, label, zonedLocalToIso } from '../lib/format.ts';
import { Link } from '../lib/router.tsx';
import { useAsync, useDocumentTitle } from '../lib/hooks.ts';
import { useLiveEvent } from '../lib/session.tsx';
import type { AdminMatch, PrizeAward, Registration, RoomView, StandingRow, TournamentRecord, TournamentStatus } from '../lib/types.ts';
import { TournamentForm } from '../components/tournament.tsx';
import { Empty, Field, LoadingBlock, Modal, Notice, PageHead, StatusBadge, Tabs, announce } from '../components/ui.tsx';
import { ReasonModal, SubmissionQueue } from './admin.tsx';

type Tab = 'overview' | 'registrations' | 'matches' | 'results' | 'standings' | 'prizes';

interface LifecycleAction {
  to: TournamentStatus;
  label: string;
  danger?: boolean;
  confirm?: string;
}

const LIFECYCLE: Record<TournamentStatus, LifecycleAction[]> = {
  draft: [
    { to: 'scheduled', label: 'Publish schedule', confirm: 'Publish this tournament? Players can see it once it is scheduled.' },
    { to: 'cancelled', label: 'Cancel', danger: true, confirm: 'Cancel this tournament? This cannot be undone.' },
  ],
  scheduled: [
    { to: 'registration_open', label: 'Open registration' },
    { to: 'cancelled', label: 'Cancel', danger: true, confirm: 'Cancel this tournament? Registered entries will be cancelled and players notified.' },
  ],
  registration_open: [
    { to: 'registration_closed', label: 'Close registration' },
    { to: 'cancelled', label: 'Cancel', danger: true, confirm: 'Cancel this tournament? Registered entries will be cancelled and players notified.' },
  ],
  registration_closed: [
    { to: 'registration_open', label: 'Reopen registration' },
    { to: 'live', label: 'Start tournament', confirm: 'Start the tournament? Matches can then go live and results can be submitted.' },
    { to: 'cancelled', label: 'Cancel', danger: true, confirm: 'Cancel this tournament? Registered entries will be cancelled and players notified.' },
  ],
  live: [
    {
      to: 'completed',
      label: 'Finalise standings',
      confirm: 'Finalise? Every match must be completed or cancelled and no results may be pending. Standings are then frozen and prize records are created.',
    },
    { to: 'cancelled', label: 'Cancel', danger: true, confirm: 'Cancel this live tournament? This cannot be undone.' },
  ],
  completed: [],
  cancelled: [],
};

const MATCH_NEXT: Record<string, string[]> = {
  scheduled: ['live', 'cancelled'],
  live: ['awaiting_results', 'cancelled'],
  awaiting_results: ['live', 'completed', 'cancelled'],
  completed: [],
  cancelled: [],
};

const PRIZE_NEXT: Record<string, string[]> = {
  allocated: ['approved', 'disputed', 'failed'],
  approved: ['fulfilled', 'disputed', 'failed'],
  disputed: ['approved', 'failed'],
  failed: ['approved'],
  fulfilled: [],
};

export function AdminTournamentManagePage({ id }: { id: string }) {
  const tournament = useAsync(() => api<{ tournament: TournamentRecord & { lockedFields: string[] } }>('GET', `/api/admin/tournaments/${encodeURIComponent(id)}`), [id]);
  const [tab, setTab] = useState<Tab>('overview');
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<LifecycleAction | null>(null);
  const [busy, setBusy] = useState(false);
  useDocumentTitle(tournament.data?.tournament.name ?? 'Manage tournament');
  useLiveEvent(['tournament', 'registration', 'match'], () => tournament.reload());

  if (tournament.loading && !tournament.data) return <LoadingBlock rows={4} />;
  if (tournament.error || !tournament.data) {
    return (
      <>
        <Notice tone="error">{errorMessage(tournament.error)}</Notice>
        <Link to="/admin/tournaments">Back to tournaments</Link>
      </>
    );
  }
  const t = tournament.data.tournament;
  const actions = LIFECYCLE[t.status];

  const transition = async (action: LifecycleAction) => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const data = await api<{ tournament?: TournamentRecord; finalized?: boolean; standings?: StandingRow[]; prizeAwards?: unknown[] }>(
        'POST',
        `/api/admin/tournaments/${encodeURIComponent(t.id)}/transition`,
        { to: action.to, expectedStatus: t.status },
      );
      if (data.finalized) {
        setMessage(`Finalised. ${data.standings?.length ?? 0} standings recorded and ${data.prizeAwards?.length ?? 0} prize records created.`);
      } else {
        setMessage(`Status is now ${label(action.to)}.`);
      }
      announce(`Tournament status changed to ${label(action.to)}.`);
      setConfirm(null);
      tournament.reload();
    } catch (err) {
      setError(errorMessage(err));
      setConfirm(null);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHead
        eyebrow={`${label(t.mode)} · ${formatZoneLabel(t.timezone)}`}
        title={t.name}
        actions={
          <>
            {actions.map((action) => (
              <button
                key={action.to}
                type="button"
                className={`btn btn--sm ${action.danger ? 'btn--danger' : action.to === 'completed' || action.to === 'scheduled' ? 'btn--primary' : ''}`}
                disabled={busy}
                onClick={() => (action.confirm ? setConfirm(action) : void transition(action))}
              >
                {action.label}
              </button>
            ))}
            <Link to={`/tournaments/${t.slug}`} className="btn btn--sm btn--ghost">
              View public page
            </Link>
          </>
        }
      >
        <div className="row" style={{ gap: 10 }}>
          <StatusBadge status={t.status} />
          <span className="small muted">
            {t.confirmedCount}/{t.capacity} confirmed · starts {formatDateTime(t.startsAt, t.timezone)}
          </span>
        </div>
      </PageHead>

      {message ? <Notice tone="success">{message}</Notice> : null}
      {error ? <Notice tone="error">{error}</Notice> : null}
      <Tabs
        name="admin-tournament"
        items={[
          { id: 'overview', label: 'Overview' },
          { id: 'registrations', label: 'Registrations' },
          { id: 'matches', label: `Matches (${t.matchCount ?? 0})` },
          { id: 'results', label: 'Results' },
          { id: 'standings', label: 'Standings' },
          { id: 'prizes', label: 'Prizes' },
        ]}
        value={tab}
        onChange={setTab}
      />
      <div id="panel-admin-tournament" role="tabpanel">
        {tab === 'overview' ? (
          <section className="panel">
            <div className="panel__head">
              <h2 style={{ fontSize: '1.15rem' }}>Settings</h2>
              <TournamentExports tournamentId={t.id} />
            </div>
            {t.lockedFields.length > 0 ? (
              <p className="small" style={{ marginBottom: 16 }}>
                Some fields are locked for this status because players may already have entered. Locked fields are greyed out.
              </p>
            ) : null}
            <TournamentForm
              key={t.updatedAt}
              initial={t}
              onSaved={() => {
                setMessage('Settings saved.');
                announce('Settings saved.');
                tournament.reload();
              }}
            />
          </section>
        ) : null}
        {tab === 'registrations' ? <RegistrationsTab tournament={t} /> : null}
        {tab === 'matches' ? <MatchesTab tournament={t} /> : null}
        {tab === 'results' ? <SubmissionQueue tournamentId={t.id} showTournament={false} /> : null}
        {tab === 'standings' ? <StandingsAdmin tournamentId={t.id} /> : null}
        {tab === 'prizes' ? <PrizesTab tournament={t} /> : null}
      </div>

      {confirm ? (
        <Modal title={`${confirm.label}?`} onClose={() => setConfirm(null)}>
          <p>{confirm.confirm}</p>
          <div className="btn-row" style={{ justifyContent: 'flex-end', marginTop: 16 }}>
            <button type="button" className="btn btn--ghost" onClick={() => setConfirm(null)}>
              Back
            </button>
            <button type="button" className={`btn ${confirm.danger ? 'btn--danger' : 'btn--primary'}`} disabled={busy} onClick={() => void transition(confirm)}>
              {busy ? 'Working…' : confirm.label}
            </button>
          </div>
        </Modal>
      ) : null}
    </>
  );
}

/* ---- Registrations ---- */

function RegistrationsTab({ tournament: t }: { tournament: TournamentRecord }) {
  const [status, setStatus] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [rejecting, setRejecting] = useState<Registration | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const list = useAsync(() => {
    const query = status ? `?status=${encodeURIComponent(status)}` : '';
    return api<{ registrations: Registration[] }>('GET', `/api/admin/tournaments/${encodeURIComponent(t.id)}/registrations${query}`);
  }, [status, t.id]);

  const decide = async (r: Registration, decision: 'approve' | 'waitlist' | 'reject', reason?: string) => {
    setBusyId(r.id);
    setError(null);
    setMessage(null);
    try {
      await api('POST', `/api/admin/registrations/${encodeURIComponent(r.id)}/decision`, reason ? { decision, reason } : { decision });
      setMessage(`${r.entrantName}: ${decision === 'approve' ? 'approved' : decision === 'waitlist' ? 'moved to waitlist' : 'rejected'}.`);
      announce('Registration updated.');
      list.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const cancel = async (r: Registration) => {
    setBusyId(r.id);
    setError(null);
    try {
      await api('POST', `/api/admin/registrations/${encodeURIComponent(r.id)}/cancel`);
      setMessage(`Cancelled ${r.entrantName}.`);
      list.reload();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <section>
      <div className="toolbar">
        <label className="small" htmlFor="reg-status">
          Show
        </label>
        <select id="reg-status" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Every status</option>
          {['pending', 'confirmed', 'waitlisted', 'rejected', 'cancelled'].map((s) => (
            <option key={s} value={s}>
              {label(s)}
            </option>
          ))}
        </select>
        <span className="small muted">Confirmed places: {t.confirmedCount} of {t.capacity}</span>
      </div>
      {message ? <Notice tone="success">{message}</Notice> : null}
      {error ? <Notice tone="error">{error}</Notice> : null}
      {list.loading && !list.data ? <LoadingBlock rows={3} /> : null}
      {list.error ? <Notice tone="error">{errorMessage(list.error)}</Notice> : null}
      {list.data && list.data.registrations.length === 0 ? <Empty title="No entries">Entries appear here as players register.</Empty> : null}
      {list.data && list.data.registrations.length > 0 ? (
        <div className="panel panel--flush">
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th scope="col">Entrant</th>
                  <th scope="col">Members and in-game IDs</th>
                  <th scope="col">Status</th>
                  <th scope="col">Entered</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.data.registrations.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <strong>{r.entrantName}</strong>
                      <div className="small faint">{label(r.kind)}</div>
                    </td>
                    <td className="small">
                      {r.members.map((m) => (
                        <div key={m.userId}>
                          {m.displayName} <span className="num faint">{m.inGameId ?? ''}</span>
                        </div>
                      ))}
                    </td>
                    <td>
                      <StatusBadge status={r.status} />
                      {r.statusReason ? <div className="small muted">{r.statusReason}</div> : null}
                    </td>
                    <td className="small">{formatDateTime(r.createdAt, t.timezone)}</td>
                    <td>
                      <div className="btn-row">
                        {r.status === 'pending' || r.status === 'waitlisted' ? (
                          <button type="button" className="btn btn--sm btn--primary" disabled={busyId === r.id} onClick={() => void decide(r, 'approve')}>
                            Approve
                          </button>
                        ) : null}
                        {r.status === 'pending' ? (
                          <button type="button" className="btn btn--sm" disabled={busyId === r.id} onClick={() => void decide(r, 'waitlist')}>
                            Waitlist
                          </button>
                        ) : null}
                        {r.status === 'pending' || r.status === 'waitlisted' || r.status === 'confirmed' ? (
                          <>
                            <button type="button" className="btn btn--sm btn--danger" disabled={busyId === r.id} onClick={() => setRejecting(r)}>
                              Reject
                            </button>
                            <button type="button" className="btn btn--sm btn--ghost" disabled={busyId === r.id} onClick={() => void cancel(r)}>
                              Cancel
                            </button>
                          </>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}
      {rejecting ? (
        <ReasonModal
          title={`Reject ${rejecting.entrantName}?`}
          label="Reason shown to the entrant"
          minLength={5}
          submitLabel="Reject entry"
          danger
          onClose={() => setRejecting(null)}
          onSubmit={async (reason) => {
            await decide(rejecting, 'reject', reason);
            setRejecting(null);
          }}
        />
      ) : null}
    </section>
  );
}

/* ---- Matches, entries and rooms ---- */

function MatchesTab({ tournament: t }: { tournament: TournamentRecord }) {
  const matches = useAsync(() => api<{ matches: AdminMatch[] }>('GET', `/api/admin/tournaments/${encodeURIComponent(t.id)}/matches`), [t.id]);
  const [roundLabel, setRoundLabel] = useState('');
  const [startsLocal, setStartsLocal] = useState(isoToZonedLocal(new Date(Date.now() + 3_600_000).toISOString(), t.timezone));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [entriesFor, setEntriesFor] = useState<AdminMatch | null>(null);
  const [openRoom, setOpenRoom] = useState<string | null>(null);
  const canAddMatches = ['scheduled', 'registration_open', 'registration_closed', 'live'].includes(t.status);

  const create = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setFormError(null);
    const iso = zonedLocalToIso(startsLocal, t.timezone);
    if (!iso) {
      setErrors({ startsAt: 'Enter a valid date and time.' });
      return;
    }
    try {
      await api('POST', `/api/admin/tournaments/${encodeURIComponent(t.id)}/matches`, { roundLabel: roundLabel.trim(), startsAt: iso });
      setRoundLabel('');
      setMessage('Match added.');
      announce('Match added.');
      matches.reload();
    } catch (err) {
      setErrors(fieldErrors(err));
      setFormError(errorMessage(err));
    }
  };

  const setState = async (m: AdminMatch, state: string) => {
    setError(null);
    setMessage(null);
    try {
      await api('PATCH', `/api/admin/matches/${encodeURIComponent(m.id)}`, { state });
      setMessage(`Match ${m.matchNumber} is now ${label(state).toLowerCase()}.`);
      matches.reload();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  return (
    <section className="stack">
      {canAddMatches ? (
        <form className="panel" onSubmit={create} noValidate aria-labelledby="add-match">
          <h2 id="add-match" style={{ fontSize: '1.05rem', marginBottom: 12 }}>
            Add a match
          </h2>
          {formError ? <Notice tone="error">{formError}</Notice> : null}
          <div className="form-grid">
            <Field id="m-round" label="Round label" hint="For example, Round 1 or Grand Final." error={errors.roundLabel}>
              <input id="m-round" className="input" value={roundLabel} onChange={(e) => setRoundLabel(e.target.value)} aria-invalid={Boolean(errors.roundLabel)} />
            </Field>
            <Field id="m-starts" label={`Starts (${formatZoneLabel(t.timezone)})`} error={errors.startsAt}>
              <input id="m-starts" className="input" type="datetime-local" value={startsLocal} onChange={(e) => setStartsLocal(e.target.value)} />
            </Field>
          </div>
          <button type="submit" className="btn btn--primary" disabled={!roundLabel.trim()}>
            Add match
          </button>
        </form>
      ) : (
        <Notice tone="info">Matches can be added once the tournament is scheduled.</Notice>
      )}

      {message ? <Notice tone="success">{message}</Notice> : null}
      {error ? <Notice tone="error">{error}</Notice> : null}
      {matches.loading && !matches.data ? <LoadingBlock rows={2} /> : null}
      {matches.data && matches.data.matches.length === 0 ? <Empty title="No matches yet">Add the first match above.</Empty> : null}
      {matches.data?.matches.map((m) => (
        <article key={m.id} className="panel" aria-label={`Match ${m.matchNumber}, ${m.roundLabel}`}>
          <div className="row row--between" style={{ alignItems: 'flex-start' }}>
            <div>
              <div className="eyebrow">Match {m.matchNumber}</div>
              <h3 style={{ textTransform: 'none', fontFamily: 'var(--font-body)', fontSize: '1.05rem', letterSpacing: 0 }}>{m.roundLabel}</h3>
              <div className="small muted">
                {formatDateTime(m.startsAt, t.timezone)} · {m.entries.length} entries · room {label(m.roomStatus).toLowerCase()}
              </div>
            </div>
            <div className="btn-row">
              <StatusBadge status={m.state} />
              {MATCH_NEXT[m.state]?.length ? (
                <select
                  className="select"
                  aria-label={`Change state of match ${m.matchNumber}`}
                  value=""
                  style={{ minWidth: 170, minHeight: 34 }}
                  onChange={(e) => e.target.value && void setState(m, e.target.value)}
                >
                  <option value="">Change state…</option>
                  {MATCH_NEXT[m.state]!.map((s) => (
                    <option key={s} value={s}>
                      {label(s)}
                    </option>
                  ))}
                </select>
              ) : null}
              <button type="button" className="btn btn--sm" onClick={() => setEntriesFor(m)}>
                Entries
              </button>
              <button type="button" className="btn btn--sm" aria-expanded={openRoom === m.id} onClick={() => setOpenRoom(openRoom === m.id ? null : m.id)}>
                Room
              </button>
            </div>
          </div>
          {m.entries.length > 0 ? (
            <p className="small" style={{ marginTop: 10 }}>
              {m.entries.map((e) => e.entrantName).join(' · ')}
            </p>
          ) : null}
          {openRoom === m.id ? <RoomEditor match={m} onChanged={matches.reload} /> : null}
        </article>
      ))}

      {entriesFor ? (
        <EntriesModal tournament={t} match={entriesFor} onClose={() => setEntriesFor(null)} onSaved={() => {
          setEntriesFor(null);
          setMessage('Entries updated. Newly added players have been notified.');
          matches.reload();
        }} />
      ) : null}
    </section>
  );
}

function EntriesModal({ tournament: t, match, onClose, onSaved }: { tournament: TournamentRecord; match: AdminMatch; onClose: () => void; onSaved: () => void }) {
  const registrations = useAsync(() => api<{ registrations: Registration[] }>('GET', `/api/admin/tournaments/${encodeURIComponent(t.id)}/registrations?status=confirmed`), [t.id]);
  const [selected, setSelected] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const current = selected ?? match.entries.map((e) => e.registrationId);

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      await api('PUT', `/api/admin/matches/${encodeURIComponent(match.id)}/entries`, { registrationIds: current });
      onSaved();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title={`Entries for ${match.roundLabel}`} onClose={onClose}>
      <p className="small">Only confirmed entries can be placed in a match. Each entry can appear once.</p>
      {error ? <Notice tone="error">{error}</Notice> : null}
      {registrations.loading && !registrations.data ? <LoadingBlock rows={2} /> : null}
      {registrations.data && registrations.data.registrations.length === 0 ? <p className="muted">No confirmed entries to place yet.</p> : null}
      <fieldset style={{ border: 0, padding: 0, margin: 0, maxHeight: 300, overflowY: 'auto' }}>
        <legend className="sr-only">Confirmed entries</legend>
        {registrations.data?.registrations.map((r) => (
          <label key={r.id} className="checkbox">
            <input
              type="checkbox"
              checked={current.includes(r.id)}
              onChange={(e) => setSelected(e.target.checked ? [...current, r.id] : current.filter((x) => x !== r.id))}
            />
            <span>
              {r.entrantName} <span className="small faint">{label(r.kind)}</span>
            </span>
          </label>
        ))}
      </fieldset>
      <div className="btn-row" style={{ justifyContent: 'flex-end', marginTop: 16 }}>
        <button type="button" className="btn btn--ghost" onClick={onClose}>
          Cancel
        </button>
        <button type="button" className="btn btn--primary" disabled={busy} onClick={() => void save()}>
          {busy ? 'Saving…' : 'Save entries'}
        </button>
      </div>
    </Modal>
  );
}

function RoomEditor({ match, onChanged }: { match: AdminMatch; onChanged: () => void }) {
  const [roomId, setRoomId] = useState('');
  const [roomPassword, setRoomPassword] = useState('');
  const [revealed, setRevealed] = useState<RoomView | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const save = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setError(null);
    setMessage(null);
    try {
      const body: Record<string, unknown> = { roomId: roomId.trim() };
      if (roomPassword.trim()) body.roomPassword = roomPassword.trim();
      await api('PUT', `/api/admin/matches/${encodeURIComponent(match.id)}/room`, body);
      setRoomPassword('');
      setMessage('Room details saved as a draft. Players cannot see them until you publish.');
      onChanged();
    } catch (err) {
      setErrors(fieldErrors(err));
      setError(errorMessage(err));
    }
  };

  const publish = async () => {
    setError(null);
    setMessage(null);
    try {
      const data = await api<{ releaseAt: string }>('POST', `/api/admin/matches/${encodeURIComponent(match.id)}/room/publish`);
      setMessage(`Published. Players see the room from ${formatDateTime(data.releaseAt)}.`);
      announce('Room published.');
      onChanged();
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const reveal = async () => {
    setError(null);
    try {
      const data = await api<{ room: RoomView }>('GET', `/api/admin/matches/${encodeURIComponent(match.id)}/room`);
      setRevealed(data.room);
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  return (
    <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--line)' }}>
      <p className="small" style={{ marginBottom: 10 }}>
        Room status: <StatusBadge status={match.roomStatus === 'published' ? 'published' : 'not_set'} text={label(match.roomStatus)} />. Players
        see details only from the release time, and only if they are entered in this match.
      </p>
      {message ? <Notice tone="success">{message}</Notice> : null}
      {error ? <Notice tone="error">{error}</Notice> : null}
      <form onSubmit={save} noValidate>
        <div className="form-grid">
          <Field id={`room-id-${match.id}`} label="Room ID" hint="Letters, numbers, dashes and underscores." error={errors.roomId}>
            <input id={`room-id-${match.id}`} className="input num" autoComplete="off" value={roomId} onChange={(e) => setRoomId(e.target.value)} aria-invalid={Boolean(errors.roomId)} />
          </Field>
          <Field id={`room-pw-${match.id}`} label="Room password (optional)" error={errors.roomPassword}>
            <input id={`room-pw-${match.id}`} className="input" type="password" autoComplete="off" value={roomPassword} onChange={(e) => setRoomPassword(e.target.value)} />
          </Field>
        </div>
        <div className="btn-row">
          <button type="submit" className="btn btn--sm" disabled={!roomId.trim()}>
            Save draft
          </button>
          <button type="button" className="btn btn--sm btn--primary" onClick={() => void publish()} disabled={match.roomStatus === 'not_set'}>
            Publish
          </button>
          <button type="button" className="btn btn--sm btn--ghost" onClick={() => void reveal()}>
            Show stored details
          </button>
        </div>
      </form>
      {revealed?.state === 'available' ? (
        <p className="small" style={{ marginTop: 12 }}>
          Stored: <span className="num" style={{ color: 'var(--text)' }}>{revealed.roomId}</span>
          {revealed.roomPassword ? (
            <>
              {' '}· password <span className="num" style={{ color: 'var(--text)' }}>{revealed.roomPassword}</span>
            </>
          ) : null}
          <br />
          <span className="faint">Viewing stored credentials is recorded in the audit log.</span>
        </p>
      ) : null}
    </div>
  );
}

/* ---- Standings ---- */

function StandingsAdmin({ tournamentId }: { tournamentId: string }) {
  const standings = useAsync(
    () =>
      api<{ standings: { provisional: boolean; finalizedAt: string | null; standings: StandingRow[] } }>(
        'GET',
        `/api/admin/tournaments/${encodeURIComponent(tournamentId)}/standings`,
      ),
    [tournamentId],
  );
  if (standings.loading && !standings.data) return <LoadingBlock rows={3} />;
  if (standings.error) return <Notice tone="error">{errorMessage(standings.error)}</Notice>;
  const board = standings.data?.standings;
  const rows = board?.standings ?? [];
  if (rows.length === 0) return <Empty title="No standings yet">Standings appear once confirmed entries have approved results.</Empty>;
  return (
    <>
    <Notice
      tone={board?.provisional ? 'info' : 'success'}
      title={board?.provisional ? 'Provisional standings' : 'Final standings'}
    >
      {board?.provisional
        ? 'Results are still being verified, so points can change until the tournament is finalised.'
        : `Frozen${board?.finalizedAt ? ` ${formatDateTime(board.finalizedAt)}` : ' at finalisation'}. This table will not change.`}
    </Notice>
    <div className="panel panel--flush">
      <div className="table-wrap">
        <table className="data">
          <thead>
            <tr>
              <th scope="col">Rank</th>
              <th scope="col">Entrant</th>
              <th scope="col" className="num">
                Points
              </th>
              <th scope="col" className="num">
                Kills
              </th>
              <th scope="col" className="num">
                First places
              </th>
              <th scope="col" className="num">
                Pending results
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.registrationId ?? r.rank + r.entrantName}>
                <td className="num">{r.rank}</td>
                <td>{r.entrantName}</td>
                <td className="num">{r.totalPoints}</td>
                <td className="num">{r.kills}</td>
                <td className="num">{r.firstPlaces}</td>
                <td className="num">{r.pendingSubmissions ?? 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
    </>
  );
}

/* ---- Prizes ---- */

function PrizesTab({ tournament: t }: { tournament: TournamentRecord }) {
  const prizes = useAsync(() => api<{ prizes: PrizeAward[] }>('GET', `/api/admin/tournaments/${encodeURIComponent(t.id)}/prizes`), [t.id]);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (prizes.loading && !prizes.data) return <LoadingBlock rows={3} />;
  if (prizes.error) return <Notice tone="error">{errorMessage(prizes.error)}</Notice>;
  const rows = prizes.data?.prizes ?? [];
  if (rows.length === 0) {
    return (
      <Empty title="No prize records">
        {t.prize.poolMinor > 0
          ? 'Prize records are created when the tournament is finalised.'
          : 'This tournament has no prize pool.'}
      </Empty>
    );
  }
  return (
    <section className="stack">
      <Notice tone="info">
        ARENA X does not pay prizes. Record how each prize was delivered outside the app. Marking a prize fulfilled needs a note or reference.
      </Notice>
      {message ? <Notice tone="success">{message}</Notice> : null}
      {error ? <Notice tone="error">{error}</Notice> : null}
      {rows.map((p) => (
        <PrizeRow
          key={`${p.id}-${p.updatedAt}`}
          prize={p}
          onSaved={(text) => {
            setMessage(text);
            setError(null);
            prizes.reload();
          }}
          onError={(text) => setError(text)}
        />
      ))}
      <p className="small">Total pool {formatMoney(t.prize.poolMinor, t.prize.currency)}.</p>
    </section>
  );
}

function PrizeRow({ prize: p, onSaved, onError }: { prize: PrizeAward; onSaved: (text: string) => void; onError: (text: string) => void }) {
  const options = PRIZE_NEXT[p.status] ?? [];
  const [status, setStatus] = useState(options[0] ?? '');
  const [note, setNote] = useState('');
  const [reference, setReference] = useState('');
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      const body: Record<string, unknown> = { status };
      if (note.trim()) body.note = note.trim();
      if (reference.trim()) body.externalReference = reference.trim();
      await api('PATCH', `/api/admin/prizes/${encodeURIComponent(p.id)}`, body);
      onSaved(`${p.entrantName}: marked ${label(status).toLowerCase()}.`);
      announce('Prize record updated.');
    } catch (err) {
      onError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };
  return (
    <article className="panel">
      <div className="row row--between" style={{ alignItems: 'flex-start' }}>
        <div>
          <div className="eyebrow">Placement {p.placement}</div>
          <strong style={{ fontSize: '1.05rem' }}>{p.entrantName}</strong>
          <div className="num" style={{ color: 'var(--text)' }}>
            {p.display}
          </div>
        </div>
        <StatusBadge status={p.status} />
      </div>
      {p.statusNote || p.externalReference ? (
        <p className="small" style={{ marginTop: 8 }}>
          {p.statusNote ? `Note: ${p.statusNote}. ` : ''}
          {p.externalReference ? `Reference: ${p.externalReference}` : ''}
        </p>
      ) : null}
      {options.length > 0 ? (
        <div className="form-grid" style={{ marginTop: 12 }}>
          <Field id={`prize-status-${p.id}`} label="Change status">
            <select id={`prize-status-${p.id}`} className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
              {options.map((o) => (
                <option key={o} value={o}>
                  {label(o)}
                </option>
              ))}
            </select>
          </Field>
          <Field id={`prize-note-${p.id}`} label="Note or reference">
            <input id={`prize-note-${p.id}`} className="input" maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} placeholder="How it was delivered" />
          </Field>
          <Field id={`prize-ref-${p.id}`} label="External reference (optional)">
            <input id={`prize-ref-${p.id}`} className="input" maxLength={120} value={reference} onChange={(e) => setReference(e.target.value)} />
          </Field>
          <div className="btn-row" style={{ alignItems: 'end' }}>
            <button type="button" className="btn btn--sm btn--primary" disabled={busy || !status} onClick={() => void save()}>
              {busy ? 'Saving…' : 'Save'}
            </button>
          </div>
        </div>
      ) : (
        <p className="small" style={{ marginTop: 10 }}>
          Final status. No further changes are possible.
        </p>
      )}
    </article>
  );
}

/** Exports scoped to this tournament, linked from the manage page. */
export function TournamentExports({ tournamentId }: { tournamentId: string }) {
  return (
    <div className="btn-row">
      <a className="btn btn--sm" href={`/api/admin/export/registrations?tournamentId=${encodeURIComponent(tournamentId)}`} download>
        Registrations CSV
      </a>
      <a className="btn btn--sm" href={`/api/admin/export/results?tournamentId=${encodeURIComponent(tournamentId)}`} download>
        Results CSV
      </a>
    </div>
  );
}
