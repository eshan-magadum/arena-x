import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { api, errorMessage, fieldErrors } from '../lib/api.ts';
import { formatDateTime, label, ordinal } from '../lib/format.ts';
import { Link, useRouter } from '../lib/router.tsx';
import { useAsync, useDocumentTitle } from '../lib/hooks.ts';
import { useLiveEvent, useSession } from '../lib/session.tsx';
import { AVATAR_KEYS, MODE_OPTIONS } from '../lib/constants.ts';
import type {
  MatchHistoryItem,
  ChatMessage,
  Dashboard,
  Notification,
  ParticipantMatch,
  PlayerStats as PlayerStatsData,
  RoomView,
  TeamDetail,
  TeamInvitation,
  TeamSummary,
  Viewer,
} from '../lib/types.ts';
import { AnnouncementList } from './public.tsx';
import { Avatar, Empty, Field, LoadingBlock, Modal, Notice, PageHead, StatusBadge, announce } from '../components/ui.tsx';
import { PlayerStats } from '../components/stats.tsx';

/* ------------------------------------------------------------------ */
/* Dashboard                                                           */
/* ------------------------------------------------------------------ */

export function DashboardPage() {
  useDocumentTitle('Dashboard');
  const { viewer, refresh } = useSession();
  const dash = useAsync(() => api<Dashboard>('GET', '/api/me/dashboard'), []);
  const [actionError, setActionError] = useState<string | null>(null);
  useLiveEvent(['notification', 'team', 'registration', 'match'], () => dash.reload());

  const respond = async (id: string, accept: boolean) => {
    setActionError(null);
    try {
      await api('POST', `/api/invites/${encodeURIComponent(id)}/${accept ? 'accept' : 'decline'}`);
      announce(accept ? 'Invitation accepted.' : 'Invitation declined.');
      dash.reload();
    } catch (err) {
      setActionError(errorMessage(err));
    }
  };

  const markAllRead = async () => {
    await api('POST', '/api/me/notifications/read-all').catch(() => undefined);
    await refresh();
    dash.reload();
  };

  if (dash.loading && !dash.data) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <LoadingBlock rows={4} />
      </div>
    );
  }
  if (dash.error || !dash.data) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <Notice tone="error">{errorMessage(dash.error)}</Notice>
      </div>
    );
  }
  const d = dash.data;

  return (
    <div className="container" style={{ padding: '2.2rem 0 3rem' }}>
      <PageHead eyebrow="Your arena" title={`Hi, ${viewer?.displayName ?? 'player'}`}>
        <p className="muted" style={{ margin: 0 }}>
          {d.profile.inGameId ? (
            <>
              In-game ID <span className="num">{d.profile.inGameId}</span>
            </>
          ) : (
            'Add your in-game ID to enter tournaments.'
          )}
        </p>
      </PageHead>

      {viewer?.restriction ? (
        <Notice tone="error" title={viewer.restriction.kind === 'banned' ? 'Account banned' : 'Account suspended'}>
          {viewer.restriction.reason ? `Reason: ${viewer.restriction.reason}. ` : ''}
          {viewer.restriction.kind === 'suspended' && viewer.restriction.until
            ? `Restriction ends ${formatDateTime(viewer.restriction.until)}. `
            : ''}
          You can still read pages, but you cannot enter tournaments, post, or submit results.
        </Notice>
      ) : null}
      {d.profile.needsInGameId ? (
        <Notice tone="info" title="One more step">
          Add your in-game ID on your <Link to="/profile">profile</Link> to enter tournaments.
        </Notice>
      ) : null}
      {actionError ? <Notice tone="error">{actionError}</Notice> : null}

      <PlayerStats stats={d.stats} />

      <div className="grid-2" style={{ marginTop: 24 }}>
        <div className="stack">
          <section className="panel" aria-labelledby="regs-title">
            <div className="panel__head">
              <h2 id="regs-title" style={{ fontSize: '1.15rem' }}>
                My entries
              </h2>
              <Link to="/tournaments" className="small">
                Find a tournament
              </Link>
            </div>
            {d.registrations.length === 0 ? (
              <Empty title="No active entries">Enter a tournament and it will appear here.</Empty>
            ) : (
              <ul className="list">
                {d.registrations.map((r) => (
                  <li key={r.id} className="row row--between">
                    <div style={{ minWidth: 0 }}>
                      <Link to={`/tournaments/${r.tournamentSlug}`} style={{ fontWeight: 600, textDecoration: 'none' }}>
                        {r.tournamentName}
                      </Link>
                      <div className="small muted">
                        {r.entrantName} · {label(r.mode)} · starts {formatDateTime(r.startsAt)}
                      </div>
                    </div>
                    <StatusBadge status={r.status} />
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="panel" aria-labelledby="matches-title">
            <h2 id="matches-title" style={{ fontSize: '1.15rem', marginBottom: 12 }}>
              Upcoming and live matches
            </h2>
            {d.matches.length === 0 ? (
              <Empty title="No matches scheduled">Matches you are entered in appear here.</Empty>
            ) : (
              <ul className="list">
                {d.matches.map((m) => (
                  <li key={m.id} className="row row--between">
                    <div style={{ minWidth: 0 }}>
                      <Link to={`/matches/${m.id}`} style={{ fontWeight: 600, textDecoration: 'none' }}>
                        {m.roundLabel}
                      </Link>
                      <div className="small muted">
                        {m.tournamentName} · {formatDateTime(m.startsAt)}
                      </div>
                    </div>
                    <StatusBadge status={m.state} />
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="panel" aria-labelledby="pending-title">
            <h2 id="pending-title" style={{ fontSize: '1.15rem', marginBottom: 12 }}>
              Results awaiting review
            </h2>
            {d.pendingResults.length === 0 ? (
              <p className="muted">Nothing is waiting for review.</p>
            ) : (
              <ul className="list">
                {d.pendingResults.map((p) => (
                  <li key={p.id} className="row row--between">
                    <span>
                      {p.roundLabel}: {p.kills} kills, finished {ordinal(p.placement)}
                    </span>
                    <StatusBadge status="pending" />
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <div className="stack">
          <section className="panel" aria-labelledby="teams-title">
            <div className="panel__head">
              <h2 id="teams-title" style={{ fontSize: '1.15rem' }}>
                Teams and invitations
              </h2>
              <Link to="/teams" className="small">
                Manage teams
              </Link>
            </div>
            {d.teams.invitations.length > 0 ? (
              <ul className="list" style={{ marginBottom: 14 }}>
                {d.teams.invitations.map((inv: TeamInvitation) => (
                  <li key={inv.id} className="row row--between">
                    <span>
                      <strong>{inv.teamName}</strong> <span className="small muted">({label(inv.mode)}, from {inv.inviterName})</span>
                    </span>
                    <span className="btn-row">
                      <button type="button" className="btn btn--sm btn--primary" onClick={() => void respond(inv.id, true)}>
                        Accept
                      </button>
                      <button type="button" className="btn btn--sm" onClick={() => void respond(inv.id, false)}>
                        Decline
                      </button>
                    </span>
                  </li>
                ))}
              </ul>
            ) : null}
            {d.teams.teams.length === 0 ? (
              <p className="muted">You are not in a team. Solo players can enter without one.</p>
            ) : (
              <ul className="list">
                {d.teams.teams.map((team: TeamSummary) => (
                  <li key={team.id} className="row row--between">
                    <Link to={`/teams/${team.id}`} style={{ fontWeight: 600, textDecoration: 'none' }}>
                      {team.name}
                    </Link>
                    <span className="small muted">
                      {label(team.mode)} · {team.memberCount}/{team.rosterSize} {team.role === 'captain' ? '· captain' : ''}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="panel" aria-labelledby="notif-title">
            <div className="panel__head">
              <h2 id="notif-title" style={{ fontSize: '1.15rem' }}>
                Notifications {d.notifications.unread > 0 ? <span className="badge badge--open">{d.notifications.unread} new</span> : null}
              </h2>
              <div className="btn-row">
                {d.notifications.unread > 0 ? (
                  <button type="button" className="btn btn--ghost btn--sm" onClick={() => void markAllRead()}>
                    Mark all read
                  </button>
                ) : null}
                <Link to="/notifications" className="small">
                  All
                </Link>
              </div>
            </div>
            <NotificationList items={d.notifications.items} onChanged={dash.reload} />
          </section>

          <section className="panel" aria-labelledby="ann-title">
            <h2 id="ann-title" style={{ fontSize: '1.15rem', marginBottom: 12 }}>
              Announcements
            </h2>
            <AnnouncementList items={d.announcements} empty="No announcements." />
          </section>
        </div>
      </div>
    </div>
  );
}

export function NotificationList({ items, onChanged, empty = 'You are all caught up.' }: { items: Notification[]; onChanged: () => void; empty?: string }) {
  const { refresh } = useSession();
  const { navigate } = useRouter();
  if (items.length === 0) return <p className="muted">{empty}</p>;
  const open = async (item: Notification) => {
    if (!item.read) {
      await api('POST', `/api/me/notifications/${encodeURIComponent(item.id)}/read`).catch(() => undefined);
      await refresh();
      onChanged();
    }
    if (item.link && item.link.startsWith('/') && !item.link.startsWith('//')) navigate(item.link);
  };
  return (
    <ul className="list">
      {items.map((item) => (
        <li key={item.id}>
          <button
            type="button"
            onClick={() => void open(item)}
            style={{
              all: 'unset',
              boxSizing: 'border-box',
              display: 'grid',
              gap: 4,
              width: '100%',
              cursor: item.link ? 'pointer' : 'default',
              borderLeft: item.read ? '2px solid transparent' : '2px solid var(--accent)',
              paddingLeft: 10,
            }}
          >
            <span style={{ fontWeight: item.read ? 500 : 700, color: 'var(--text)' }}>{item.title}</span>
            <span className="small">{item.body}</span>
            <span className="small faint">{formatDateTime(item.createdAt)}</span>
          </button>
        </li>
      ))}
    </ul>
  );
}

/* ------------------------------------------------------------------ */
/* Notifications page                                                  */
/* ------------------------------------------------------------------ */

export function NotificationsPage() {
  useDocumentTitle('Notifications');
  const { refresh } = useSession();
  const [items, setItems] = useState<Notification[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadingMore, setLoadingMore] = useState(false);
  const [exhausted, setExhausted] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await api<{ items: Notification[] }>('GET', '/api/me/notifications?limit=30');
      setItems(data.items);
      setExhausted(data.items.length < 30);
    } catch (err) {
      setError(errorMessage(err));
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);
  useLiveEvent(['notification'], () => void load());

  const more = async () => {
    if (!items || items.length === 0) return;
    setLoadingMore(true);
    try {
      const before = items[items.length - 1]!.createdAt;
      const data = await api<{ items: Notification[] }>('GET', `/api/me/notifications?limit=30&before=${encodeURIComponent(before)}`);
      setItems((previous) => [...(previous ?? []), ...data.items]);
      setExhausted(data.items.length < 30);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoadingMore(false);
    }
  };

  const readAll = async () => {
    await api('POST', '/api/me/notifications/read-all').catch(() => undefined);
    await refresh();
    void load();
  };

  return (
    <div className="container" style={{ padding: '2.2rem 0 3rem' }}>
      <PageHead eyebrow="Inbox" title="Notifications">
        <button type="button" className="btn btn--sm" onClick={() => void readAll()}>
          Mark all read
        </button>
      </PageHead>
      {error ? <Notice tone="error">{error}</Notice> : null}
      <section className="panel">
        {items === null && !error ? <LoadingBlock rows={3} /> : null}
        {items ? <NotificationList items={items} onChanged={() => void load()} /> : null}
        {items && items.length > 0 && !exhausted ? (
          <div style={{ textAlign: 'center', marginTop: 14 }}>
            <button type="button" className="btn btn--sm" onClick={() => void more()} disabled={loadingMore}>
              {loadingMore ? 'Loading…' : 'Load older'}
            </button>
          </div>
        ) : null}
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Profile and security                                                */
/* ------------------------------------------------------------------ */

export function ProfilePage() {
  useDocumentTitle('Profile and security');
  const { viewer, refresh } = useSession();
  const profile = useAsync(() => api<{ viewer: Viewer; stats: PlayerStatsData }>('GET', '/api/me/profile'), []);

  if (!viewer) return null;
  if (profile.loading && !profile.data) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <LoadingBlock rows={3} />
      </div>
    );
  }
  return (
    <div className="container" style={{ padding: '2.2rem 0 3rem' }}>
      <PageHead eyebrow="Account" title="Profile and security" />
      <div className="grid-2">
        <ProfileForm viewer={profile.data?.viewer ?? viewer} onSaved={() => void refresh()} />
        <div className="stack">
          <PasswordForm />
          {profile.data ? (
            <section className="panel">
              <h2 style={{ fontSize: '1.1rem', marginBottom: 10 }}>Your record</h2>
              <PlayerStats stats={profile.data.stats} compact />
            </section>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function ProfileForm({ viewer, onSaved }: { viewer: Viewer; onSaved: () => void }) {
  const [displayName, setDisplayName] = useState(viewer.displayName);
  const [inGameId, setInGameId] = useState(viewer.inGameId ?? '');
  const [avatarKey, setAvatarKey] = useState(viewer.avatarKey);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setDisplayName(viewer.displayName);
    setInGameId(viewer.inGameId ?? '');
    setAvatarKey(viewer.avatarKey);
  }, [viewer.id, viewer.displayName, viewer.inGameId, viewer.avatarKey]);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setMessage(null);
    setFormError(null);
    const body: Record<string, unknown> = {};
    if (displayName.trim() !== viewer.displayName) body.displayName = displayName.trim();
    const nextId = inGameId.trim() === '' ? null : inGameId.trim();
    if (nextId !== viewer.inGameId) body.inGameId = nextId;
    if (avatarKey !== viewer.avatarKey) body.avatarKey = avatarKey;
    if (Object.keys(body).length === 0) {
      setMessage('Nothing has changed.');
      return;
    }
    setBusy(true);
    try {
      await api('PATCH', '/api/me/profile', body);
      setMessage('Profile saved.');
      announce('Profile saved.');
      onSaved();
    } catch (err) {
      setErrors(fieldErrors(err));
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel" aria-labelledby="profile-title">
      <h2 id="profile-title" style={{ fontSize: '1.1rem', marginBottom: 14 }}>
        Profile
      </h2>
      {message ? <Notice tone="success">{message}</Notice> : null}
      {formError ? <Notice tone="error">{formError}</Notice> : null}
      <form onSubmit={submit} noValidate>
        <Field id="p-name" label="Display name" error={errors.displayName}>
          <input id="p-name" className="input" value={displayName} onChange={(e) => setDisplayName(e.target.value)} aria-invalid={Boolean(errors.displayName)} />
        </Field>
        <Field
          id="p-ingame"
          label="Free Fire MAX in-game ID"
          hint="6 to 12 digits. It cannot be changed while you have an active entry."
          error={errors.inGameId}
        >
          <input id="p-ingame" className="input num" inputMode="numeric" value={inGameId} onChange={(e) => setInGameId(e.target.value)} aria-invalid={Boolean(errors.inGameId)} />
        </Field>
        <fieldset style={{ border: 0, padding: 0, margin: '0 0 1.2rem' }}>
          <legend className="field__label" style={{ marginBottom: 8 }}>
            Avatar
          </legend>
          <div className="row" style={{ gap: 8 }}>
            {AVATAR_KEYS.map((key) => (
              <label key={key} className="chip" style={{ padding: 4, cursor: 'pointer', outline: avatarKey === key ? '2px solid var(--accent)' : 'none' }}>
                <input type="radio" name="avatar" value={key} checked={avatarKey === key} onChange={() => setAvatarKey(key)} className="sr-only" />
                <Avatar avatarKey={key} size="sm" />
                <span className="sr-only">{key}</span>
              </label>
            ))}
          </div>
        </fieldset>
        <button type="submit" className="btn btn--primary" disabled={busy}>
          {busy ? 'Saving…' : 'Save profile'}
        </button>
      </form>
      <div className="row" style={{ marginTop: 16 }}>
        <Avatar avatarKey={viewer.avatarKey} />
        <span className="small muted">Signed in as {viewer.email}</span>
      </div>
    </section>
  );
}

function PasswordForm() {
  const { refresh } = useSession();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setMessage(null);
    setFormError(null);
    if (newPassword !== confirm) {
      setErrors({ confirm: 'The new passwords do not match.' });
      return;
    }
    setBusy(true);
    try {
      const data = await api<{ message: string }>('POST', '/api/me/password', { currentPassword, newPassword });
      setMessage(data.message);
      setCurrentPassword('');
      setNewPassword('');
      setConfirm('');
      announce('Password updated.');
      await refresh();
    } catch (err) {
      setErrors(fieldErrors(err));
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel" aria-labelledby="pw-title">
      <h2 id="pw-title" style={{ fontSize: '1.1rem', marginBottom: 14 }}>
        Change password
      </h2>
      {message ? <Notice tone="success">{message}</Notice> : null}
      {formError ? <Notice tone="error">{formError}</Notice> : null}
      <form onSubmit={submit} noValidate>
        <Field id="pw-current" label="Current password" error={errors.currentPassword}>
          <input id="pw-current" className="input" type="password" autoComplete="current-password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
        </Field>
        <Field id="pw-new" label="New password" hint="At least 10 characters." error={errors.newPassword}>
          <input id="pw-new" className="input" type="password" autoComplete="new-password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
        </Field>
        <Field id="pw-confirm" label="Confirm new password" error={errors.confirm}>
          <input id="pw-confirm" className="input" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        </Field>
        <button type="submit" className="btn" disabled={busy}>
          {busy ? 'Updating…' : 'Update password'}
        </button>
      </form>
      <p className="small" style={{ marginTop: 12 }}>
        Changing your password signs out your other devices.
      </p>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Teams                                                               */
/* ------------------------------------------------------------------ */

export function TeamsPage() {
  useDocumentTitle('Teams');
  const { navigate } = useRouter();
  const { viewer } = useSession();
  const mine = useAsync(() => api<{ teams: TeamSummary[]; invitations: TeamInvitation[] }>('GET', '/api/teams/mine'), []);
  const [name, setName] = useState('');
  const [mode, setMode] = useState<'duo' | 'squad'>('duo');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useLiveEvent(['team'], () => mine.reload());

  const create = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setFormError(null);
    setBusy(true);
    try {
      const data = await api<{ team: TeamDetail }>('POST', '/api/teams', { name: name.trim(), mode });
      navigate(`/teams/${data.team.id}`);
    } catch (err) {
      setErrors(fieldErrors(err));
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const respond = async (id: string, accept: boolean) => {
    try {
      await api('POST', `/api/invites/${encodeURIComponent(id)}/${accept ? 'accept' : 'decline'}`);
      mine.reload();
    } catch (err) {
      setFormError(errorMessage(err));
    }
  };

  return (
    <div className="container" style={{ padding: '2.2rem 0 3rem' }}>
      <PageHead eyebrow="Rosters" title="Teams">
        <p className="muted" style={{ margin: 0 }}>
          Duo teams have 2 players and squads have 4. The captain registers the team for tournaments.
        </p>
      </PageHead>
      {!viewer?.inGameId ? (
        <Notice tone="info">
          Add your in-game ID on your <Link to="/profile">profile</Link> before creating a team. Every team member also needs one.
        </Notice>
      ) : null}
      {formError ? <Notice tone="error">{formError}</Notice> : null}
      <div className="grid-2">
        <div className="stack">
          {mine.data && mine.data.invitations.length > 0 ? (
            <section className="panel">
              <h2 style={{ fontSize: '1.1rem', marginBottom: 12 }}>Invitations</h2>
              <ul className="list">
                {mine.data.invitations.map((inv) => (
                  <li key={inv.id} className="row row--between">
                    <span>
                      <strong>{inv.teamName}</strong> <span className="small muted">({label(inv.mode)}, from {inv.inviterName})</span>
                    </span>
                    <span className="btn-row">
                      <button type="button" className="btn btn--sm btn--primary" onClick={() => void respond(inv.id, true)}>
                        Accept
                      </button>
                      <button type="button" className="btn btn--sm" onClick={() => void respond(inv.id, false)}>
                        Decline
                      </button>
                    </span>
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
          <section className="panel">
            <h2 style={{ fontSize: '1.1rem', marginBottom: 12 }}>Your teams</h2>
            {mine.loading && !mine.data ? <LoadingBlock rows={2} /> : null}
            {mine.data && mine.data.teams.length === 0 ? <Empty title="No teams yet">Create one, or wait for an invitation.</Empty> : null}
            {mine.data && mine.data.teams.length > 0 ? (
              <ul className="list">
                {mine.data.teams.map((team) => (
                  <li key={team.id} className="row row--between">
                    <div>
                      <Link to={`/teams/${team.id}`} style={{ fontWeight: 600, textDecoration: 'none' }}>
                        {team.name}
                      </Link>
                      <div className="small muted">
                        {label(team.mode)} · {team.memberCount}/{team.rosterSize} players
                      </div>
                    </div>
                    <StatusBadge status={team.role} />
                  </li>
                ))}
              </ul>
            ) : null}
          </section>
        </div>

        <section className="panel" aria-labelledby="create-team">
          <h2 id="create-team" style={{ fontSize: '1.1rem', marginBottom: 14 }}>
            Create a team
          </h2>
          <form onSubmit={create} noValidate>
            <Field id="team-name" label="Team name" hint="3 to 24 characters. Names are unique." error={errors.name}>
              <input id="team-name" className="input" value={name} onChange={(e) => setName(e.target.value)} aria-invalid={Boolean(errors.name)} />
            </Field>
            <fieldset style={{ border: 0, padding: 0, margin: '0 0 1.2rem' }}>
              <legend className="field__label" style={{ marginBottom: 8 }}>
                Mode
              </legend>
              <div className="row" style={{ gap: 18 }}>
                {MODE_OPTIONS.filter((m) => m.id !== 'solo').map((m) => (
                  <label key={m.id} className="checkbox" style={{ marginBottom: 0 }}>
                    <input type="radio" name="team-mode" checked={mode === m.id} onChange={() => setMode(m.id as 'duo' | 'squad')} />
                    <span>
                      {m.label} ({m.roster} players)
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>
            <button type="submit" className="btn btn--primary" disabled={busy || !name.trim()}>
              {busy ? 'Creating…' : 'Create team'}
            </button>
          </form>
          <p className="small" style={{ marginTop: 12 }}>
            You can be on one team per mode. You become the captain.
          </p>
        </section>
      </div>
    </div>
  );
}

export function TeamDetailPage({ id }: { id: string }) {
  const { viewer } = useSession();
  const { navigate } = useRouter();
  const team = useAsync(() => api<{ team: TeamDetail }>('GET', `/api/teams/${encodeURIComponent(id)}`), [id]);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteError, setInviteError] = useState<string | null>(null);
  const [inviteOk, setInviteOk] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<null | { kind: 'remove'; userId: string; name: string } | { kind: 'leave' } | { kind: 'disband' }>(null);
  const [busy, setBusy] = useState(false);
  useDocumentTitle(team.data?.team.name ?? 'Team');
  useLiveEvent(['team', 'registration'], () => team.reload());

  if (team.loading && !team.data) return <div className="container" style={{ padding: '2.4rem 0' }}><LoadingBlock rows={3} /></div>;
  if (team.error || !team.data) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <Empty title="Team not found">{errorMessage(team.error)}</Empty>
      </div>
    );
  }
  const t = team.data.team;
  const isCaptain = t.viewer.isCaptain;
  const isMember = t.viewer.isMember;

  const invite = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setInviteError(null);
    setInviteOk(null);
    setBusy(true);
    try {
      await api('POST', `/api/teams/${encodeURIComponent(t.id)}/invites`, { email: inviteEmail.trim() });
      setInviteEmail('');
      setInviteOk('Invitation sent.');
      announce('Invitation sent.');
      team.reload();
    } catch (err) {
      setInviteError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const revoke = async (inviteId: string) => {
    try {
      await api('DELETE', `/api/invites/${encodeURIComponent(inviteId)}`);
      team.reload();
    } catch (err) {
      setActionError(errorMessage(err));
    }
  };

  const runConfirm = async () => {
    if (!confirm) return;
    setBusy(true);
    setActionError(null);
    try {
      if (confirm.kind === 'remove') {
        await api('DELETE', `/api/teams/${encodeURIComponent(t.id)}/members/${encodeURIComponent(confirm.userId)}`);
        team.reload();
      } else if (confirm.kind === 'leave') {
        await api('DELETE', `/api/teams/${encodeURIComponent(t.id)}/members/${encodeURIComponent(viewer!.id)}`);
        navigate('/teams', { replace: true });
      } else {
        await api('DELETE', `/api/teams/${encodeURIComponent(t.id)}`);
        navigate('/teams', { replace: true });
      }
      setConfirm(null);
    } catch (err) {
      setActionError(errorMessage(err));
      setConfirm(null);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container" style={{ padding: '2.2rem 0 3rem' }}>
      <nav aria-label="Breadcrumb" className="small muted" style={{ marginBottom: 10 }}>
        <Link to="/teams" style={{ color: 'var(--muted)' }}>
          Teams
        </Link>{' '}
        / {t.name}
      </nav>
      <PageHead eyebrow={`${label(t.mode)} team`} title={t.name}>
        <p className="muted" style={{ margin: 0 }}>
          {t.members.length}/{t.rosterSize} players · created {formatDateTime(t.createdAt)}
        </p>
      </PageHead>
      {actionError ? <Notice tone="error">{actionError}</Notice> : null}

      <div className="grid-2">
        <div className="stack">
          <section className="panel" aria-labelledby="roster-title">
            <h2 id="roster-title" style={{ fontSize: '1.15rem', marginBottom: 12 }}>
              Roster
            </h2>
            <ul className="list">
              {t.members.map((m) => (
                <li key={m.userId} className="row row--between">
                  <span className="row" style={{ flexWrap: 'nowrap' }}>
                    <Avatar avatarKey={m.avatarKey} size="sm" />
                    <span>
                      <strong>{m.displayName}</strong> <StatusBadge status={m.role} />
                      <div className="small muted num">{m.inGameId ?? (isMember ? 'No in-game ID' : 'In-game ID hidden')}</div>
                    </span>
                  </span>
                  {isCaptain && m.role !== 'captain' ? (
                    <button type="button" className="btn btn--sm btn--ghost" onClick={() => setConfirm({ kind: 'remove', userId: m.userId, name: m.displayName })}>
                      Remove
                    </button>
                  ) : null}
                </li>
              ))}
            </ul>
            {isMember && !isCaptain ? (
              <button type="button" className="btn btn--sm btn--danger" style={{ marginTop: 14 }} onClick={() => setConfirm({ kind: 'leave' })}>
                Leave team
              </button>
            ) : null}
            {isMember && isCaptain ? (
              <p className="small" style={{ marginTop: 12 }}>
                As captain you cannot leave. Transfer or disband the team instead.
              </p>
            ) : null}
          </section>

          {isMember ? (
            <section className="panel" aria-labelledby="entries-title">
              <h2 id="entries-title" style={{ fontSize: '1.15rem', marginBottom: 12 }}>
                Tournament entries
              </h2>
              {t.registrations.length === 0 ? (
                <p className="muted">This team has not entered a tournament.</p>
              ) : (
                <ul className="list">
                  {t.registrations.map((r) => (
                    <li key={r.id} className="row row--between">
                      <Link to={`/tournaments/${r.tournamentId}`} style={{ textDecoration: 'none' }}>
                        {r.tournamentName}
                      </Link>
                      <StatusBadge status={r.status} />
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ) : null}

          {isMember ? <ChatPanel teamId={t.id} /> : (
            <Notice tone="info">Only team members can read the team chat.</Notice>
          )}
        </div>

        <div className="stack">
          {isCaptain ? (
            <section className="panel" aria-labelledby="invite-title">
              <h2 id="invite-title" style={{ fontSize: '1.15rem', marginBottom: 12 }}>
                Invite a player
              </h2>
              {inviteError ? <Notice tone="error">{inviteError}</Notice> : null}
              {inviteOk ? <Notice tone="success">{inviteOk}</Notice> : null}
              {t.members.length < t.rosterSize ? (
                <form onSubmit={invite} noValidate>
                  <Field id="invite-email" label="Player's account email" hint="They must have an account with an in-game ID.">
                    <input id="invite-email" className="input" type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} required />
                  </Field>
                  <button type="submit" className="btn btn--primary" disabled={busy || !inviteEmail.trim()}>
                    Send invitation
                  </button>
                </form>
              ) : (
                <p className="muted">The roster is full.</p>
              )}
              {t.invitations.length > 0 ? (
                <>
                  <h3 style={{ fontSize: '0.95rem', margin: '18px 0 8px' }}>Pending</h3>
                  <ul className="list">
                    {t.invitations.map((inv) => (
                      <li key={inv.id} className="row row--between">
                        <span>{inv.inviteeName}</span>
                        <button type="button" className="btn btn--sm btn--ghost" onClick={() => void revoke(inv.id)}>
                          Revoke
                        </button>
                      </li>
                    ))}
                  </ul>
                </>
              ) : null}
              {isCaptain ? (
                <button type="button" className="btn btn--sm btn--danger" style={{ marginTop: 18 }} onClick={() => setConfirm({ kind: 'disband' })}>
                  Disband team
                </button>
              ) : null}
            </section>
          ) : null}
        </div>
      </div>

      {confirm ? (
        <Modal
          title={confirm.kind === 'remove' ? `Remove ${confirm.name}?` : confirm.kind === 'leave' ? 'Leave this team?' : 'Disband this team?'}
          onClose={() => setConfirm(null)}
        >
          <p>
            {confirm.kind === 'remove'
              ? 'They will leave the roster. Roster changes are blocked while the team has an active entry.'
              : confirm.kind === 'leave'
                ? 'You will leave the roster. You can be invited again later.'
                : 'The team will be closed and pending invitations cancelled. Active entries must be withdrawn first.'}
          </p>
          <div className="btn-row" style={{ justifyContent: 'flex-end', marginTop: 16 }}>
            <button type="button" className="btn btn--ghost" onClick={() => setConfirm(null)}>
              Cancel
            </button>
            <button type="button" className="btn btn--danger" disabled={busy} onClick={() => void runConfirm()}>
              {busy ? 'Working…' : 'Confirm'}
            </button>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}

/* ---- Persistent team chat ---- */

function mergeMessages(existing: ChatMessage[], incoming: ChatMessage[]): ChatMessage[] {
  const byId = new Map<number, ChatMessage>();
  for (const m of existing) byId.set(m.id, m);
  for (const m of incoming) byId.set(m.id, m);
  return [...byId.values()].sort((a, b) => a.id - b.id);
}

export function ChatPanel({ teamId }: { teamId: string }) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [nextCursor, setNextCursor] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);
  const lastId = messages.length ? messages[messages.length - 1]!.id : 0;

  const loadLatest = useCallback(async () => {
    try {
      const data = await api<{ messages: ChatMessage[]; nextCursor: number | null }>('GET', `/api/teams/${encodeURIComponent(teamId)}/messages?limit=40`);
      setMessages((previous) => mergeMessages(previous, data.messages));
      setNextCursor((previous) => (previous === null ? data.nextCursor : previous));
      setError(null);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [teamId]);

  useEffect(() => {
    setLoading(true);
    setMessages([]);
    setNextCursor(null);
    void loadLatest();
  }, [loadLatest]);

  useLiveEvent(['chat'], (data) => {
    if ((data as { teamId?: string } | null)?.teamId === teamId) void loadLatest();
  });

  useEffect(() => {
    const node = logRef.current;
    if (node) node.scrollTop = node.scrollHeight;
  }, [lastId]);

  const loadOlder = async () => {
    if (nextCursor === null) return;
    try {
      const data = await api<{ messages: ChatMessage[]; nextCursor: number | null }>(
        'GET',
        `/api/teams/${encodeURIComponent(teamId)}/messages?limit=40&before=${nextCursor}`,
      );
      setMessages((previous) => mergeMessages(previous, data.messages));
      setNextCursor(data.nextCursor);
    } catch (err) {
      setError(errorMessage(err));
    }
  };

  const send = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const body = draft.trim();
    if (!body) return;
    setSending(true);
    setError(null);
    try {
      const data = await api<{ message: ChatMessage }>('POST', `/api/teams/${encodeURIComponent(teamId)}/messages`, { body });
      setMessages((previous) => mergeMessages(previous, [data.message]));
      setDraft('');
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSending(false);
    }
  };

  return (
    <section className="panel panel--flush" aria-labelledby="chat-title">
      <div className="panel__head">
        <h2 id="chat-title" style={{ fontSize: '1.15rem' }}>
          Team chat
        </h2>
        <span className="small faint">Messages are kept for the team.</span>
      </div>
      {error ? (
        <div style={{ padding: '0 1.25rem 0.8rem' }}>
          <Notice tone="error">{error}</Notice>
        </div>
      ) : null}
      <div className="chat" style={{ border: 0, borderRadius: 0, background: 'transparent', height: 360 }}>
        <div className="chat__log" ref={logRef} role="log" aria-live="off" aria-label="Team messages">
          {nextCursor !== null ? (
            <button type="button" className="btn btn--ghost btn--sm" onClick={() => void loadOlder()} style={{ alignSelf: 'center' }}>
              Load earlier messages
            </button>
          ) : null}
          {loading && messages.length === 0 ? <LoadingBlock rows={2} /> : null}
          {!loading && messages.length === 0 ? <p className="muted small">No messages yet. Say hello to your squad.</p> : null}
          {messages.map((m) => (
            <div key={m.id} className="chat__msg">
              <span className="avatar avatar--sm" aria-hidden="true" style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>
                {m.authorName.slice(0, 1).toUpperCase()}
              </span>
              <div style={{ minWidth: 0 }}>
                <div className="chat__meta">
                  <strong style={{ color: 'var(--text-soft)' }}>{m.authorName}</strong> · {formatDateTime(m.createdAt)}
                </div>
                <div className={`chat__body${m.removed ? ' chat__body--removed' : ''}`}>{m.body}</div>
              </div>
            </div>
          ))}
        </div>
        <form className="chat__form" onSubmit={send}>
          <label htmlFor="chat-input" className="sr-only">
            Write a message to your team
          </label>
          <input
            id="chat-input"
            className="input"
            maxLength={500}
            value={draft}
            placeholder="Write to your team"
            onChange={(e) => setDraft(e.target.value)}
          />
          <button type="submit" className="btn btn--primary" disabled={sending || !draft.trim()}>
            {sending ? 'Sending…' : 'Send'}
          </button>
        </form>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Match room and result submission                                    */
/* ------------------------------------------------------------------ */

export function MatchPage({ id }: { id: string }) {
  useDocumentTitle('Match');
  const match = useAsync(() => api<{ match: ParticipantMatch }>('GET', `/api/matches/${encodeURIComponent(id)}`), [id]);
  const room = useAsync(() => api<{ room: RoomView }>('GET', `/api/matches/${encodeURIComponent(id)}/room`).then((r) => r.room), [id, match.data?.match.room.status]);
  useLiveEvent(['match'], () => {
    match.reload();
  });

  if (match.loading && !match.data) return <div className="container" style={{ padding: '2.4rem 0' }}><LoadingBlock rows={3} /></div>;
  if (match.error || !match.data) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <Empty title="Match not available">{errorMessage(match.error)}</Empty>
      </div>
    );
  }
  const m = match.data.match;

  return (
    <div className="container" style={{ padding: '2.2rem 0 3rem' }}>
      <nav aria-label="Breadcrumb" className="small muted" style={{ marginBottom: 10 }}>
        <Link to={`/tournaments/${m.tournamentSlug}`} style={{ color: 'var(--muted)' }}>
          {m.tournamentName}
        </Link>{' '}
        / Match {m.matchNumber}
      </nav>
      <PageHead eyebrow="Match" title={m.roundLabel}>
        <div className="row" style={{ gap: 10 }}>
          <StatusBadge status={m.state} />
          <span className="small muted">Starts {formatDateTime(m.startsAt)}</span>
        </div>
      </PageHead>

      <div className="grid-2">
        <div className="stack">
          <RoomPanel
            state={room.data ?? null}
            loading={room.loading}
            error={room.error}
            onRefresh={room.reload}
            releaseAt={m.room.releaseAt}
          />
          <section className="panel" aria-labelledby="sub-title">
            <h2 id="sub-title" style={{ fontSize: '1.15rem', marginBottom: 12 }}>
              Your results
            </h2>
            {m.submissions.length === 0 ? (
              <p className="muted">No results submitted for this match yet.</p>
            ) : (
              <div className="table-wrap">
                <table className="data">
                  <thead>
                    <tr>
                      <th scope="col">Submitted</th>
                      <th scope="col" className="num">
                        Kills
                      </th>
                      <th scope="col" className="num">
                        Place
                      </th>
                      <th scope="col" className="num">
                        Points
                      </th>
                      <th scope="col">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {m.submissions.map((s) => (
                      <tr key={s.id}>
                        <td className="small">{formatDateTime(s.createdAt)}</td>
                        <td className="num">{s.kills}</td>
                        <td className="num">{ordinal(s.placement)}</td>
                        <td className="num">{s.totalPoints ?? '–'}</td>
                        <td>
                          <StatusBadge status={s.status} />
                          {s.reviewReason ? <div className="small muted">{s.reviewReason}</div> : null}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>

        <ResultForm match={m} onSubmitted={match.reload} />
      </div>
    </div>
  );
}

function RoomPanel({
  state,
  loading,
  error,
  onRefresh,
  releaseAt,
}: {
  state: RoomView | null;
  loading: boolean;
  error: unknown;
  onRefresh: () => void;
  releaseAt: string;
}) {
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    // Re-check when the release time passes, so the room appears without a manual refresh.
    if (!state || state.state !== 'not_released') return;
    const wait = Math.max(0, Date.parse(state.releaseAt) - Date.now()) + 1000;
    const timer = window.setTimeout(onRefresh, Math.min(wait, 2_147_000_000));
    return () => window.clearTimeout(timer);
  }, [state, onRefresh]);

  const copy = async (text: string, what: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(what);
      announce(`${what} copied.`);
    } catch {
      setCopied(null);
    }
  };

  return (
    <section className="panel" aria-labelledby="room-title">
      <div className="panel__head">
        <h2 id="room-title" style={{ fontSize: '1.15rem' }}>
          Private room
        </h2>
        <button type="button" className="btn btn--ghost btn--sm" onClick={onRefresh} disabled={loading}>
          {loading ? 'Checking…' : 'Refresh'}
        </button>
      </div>
      {error ? <Notice tone="error">{errorMessage(error)}</Notice> : null}
      {!state && !error ? <LoadingBlock rows={1} /> : null}
      {state?.state === 'not_set' ? <p className="muted">The operator has not added room details for this match yet.</p> : null}
      {state?.state === 'not_published' ? <p className="muted">Room details will appear here when the operator publishes them.</p> : null}
      {state?.state === 'not_released' ? (
        <Notice tone="info" title="Room details are not released yet">
          They unlock at {formatDateTime(state.releaseAt)}. This page refreshes itself at that time.
        </Notice>
      ) : null}
      {state?.state === 'available' ? (
        <div style={{ display: 'grid', gap: 12 }}>
          <div className="row row--between">
            <div>
              <span className="eyebrow">Room ID</span>
              <div className="num" style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--text)' }}>
                {state.roomId}
              </div>
            </div>
            <button type="button" className="btn btn--sm" onClick={() => void copy(state.roomId, 'Room ID')}>
              Copy ID
            </button>
          </div>
          {state.roomPassword !== null ? (
            <div className="row row--between">
              <div>
                <span className="eyebrow">Password</span>
                <div className="num" style={{ fontSize: '1.4rem', fontWeight: 700, color: 'var(--text)' }}>
                  {state.roomPassword}
                </div>
              </div>
              <button type="button" className="btn btn--sm" onClick={() => void copy(state.roomPassword ?? '', 'Password')}>
                Copy password
              </button>
            </div>
          ) : null}
          <p className="small">Share these only with your own entry. Each time you open this panel is recorded.</p>
          {copied ? <p className="small" role="status">{copied} copied.</p> : null}
        </div>
      ) : null}
      <p className="small" style={{ marginTop: 10 }}>
        Release time for this match: {formatDateTime(releaseAt)}
      </p>
    </section>
  );
}

function ResultForm({ match, onSubmitted }: { match: ParticipantMatch; onSubmitted: () => void }) {
  const [kills, setKills] = useState('0');
  const [placement, setPlacement] = useState('1');
  const [notes, setNotes] = useState('');
  const [evidenceUrl, setEvidenceUrl] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const { navigate } = useRouter();
  const stateText: Record<string, string> = {
    scheduled: 'Results open when the match goes live.',
    completed: 'This match is complete. Results are final.',
    cancelled: 'This match was cancelled.',
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrors({});
    setFormError(null);
    setSuccess(null);
    const body: Record<string, unknown> = { kills: Number(kills), placement: Number(placement) };
    if (notes.trim()) body.notes = notes.trim();
    if (evidenceUrl.trim()) body.evidenceUrl = evidenceUrl.trim();
    setBusy(true);
    try {
      await api('POST', `/api/matches/${encodeURIComponent(match.id)}/results`, body);
      setSuccess('Result submitted. It counts once an administrator approves it.');
      announce('Result submitted for review.');
      setNotes('');
      onSubmitted();
    } catch (err) {
      setErrors(fieldErrors(err));
      setFormError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel" aria-labelledby="submit-title">
      <h2 id="submit-title" style={{ fontSize: '1.15rem', marginBottom: 8 }}>
        Submit your result
      </h2>
      {match.canSubmitResult ? (
        <>
          <p className="small" style={{ marginBottom: 14 }}>
            Team entries are submitted by the captain. Results stay pending until an administrator approves them.
          </p>
          {formError ? <Notice tone="error">{formError}</Notice> : null}
          {success ? <Notice tone="success">{success}</Notice> : null}
          <form onSubmit={submit} noValidate>
            <div className="form-grid">
              <Field id="res-kills" label="Eliminations" error={errors.kills}>
                <input id="res-kills" className="input num" type="number" min={0} max={99} value={kills} onChange={(e) => setKills(e.target.value)} aria-invalid={Boolean(errors.kills)} />
              </Field>
              <Field id="res-place" label="Final placement" hint="1 is first place." error={errors.placement}>
                <input id="res-place" className="input num" type="number" min={1} max={50} value={placement} onChange={(e) => setPlacement(e.target.value)} aria-invalid={Boolean(errors.placement)} />
              </Field>
              <div className="span-2">
                <Field id="res-notes" label="Notes (optional)" error={errors.notes}>
                  <textarea id="res-notes" className="textarea" style={{ minHeight: 70 }} maxLength={500} value={notes} onChange={(e) => setNotes(e.target.value)} />
                </Field>
              </div>
              <div className="span-2">
                <Field id="res-evidence" label="Screenshot link (optional)" hint="Must start with https://" error={errors.evidenceUrl}>
                  <input id="res-evidence" className="input" type="url" value={evidenceUrl} onChange={(e) => setEvidenceUrl(e.target.value)} aria-invalid={Boolean(errors.evidenceUrl)} />
                </Field>
              </div>
            </div>
            <button type="submit" className="btn btn--primary" disabled={busy}>
              {busy ? 'Submitting…' : 'Submit result'}
            </button>
          </form>
        </>
      ) : (
        <Notice tone="info">{stateText[match.state] ?? 'Results are not open for this match right now.'}</Notice>
      )}
      <button type="button" className="btn btn--ghost btn--sm" style={{ marginTop: 14 }} onClick={() => navigate('/dashboard')}>
        Back to dashboard
      </button>
    </section>
  );
}

/* ---- Match history ---- */

export function HistoryPage() {
  useDocumentTitle('Match history');
  const history = useAsync(() => api<{ matches: MatchHistoryItem[] }>('GET', '/api/me/matches').then((r) => r.matches), []);
  useLiveEvent(['match', 'registration'], () => history.reload());

  if (history.loading && !history.data) return <div className="container" style={{ padding: '2.4rem 0' }}><LoadingBlock rows={4} /></div>;
  if (history.error) return <div className="container" style={{ padding: '2.4rem 0' }}><Notice tone="error">{errorMessage(history.error)}</Notice></div>;
  const rows = history.data ?? [];

  return (
    <div className="container" style={{ padding: '2.4rem 0 4rem' }}>
      <PageHead eyebrow="Your record" title="Match history" />
      {rows.length === 0 ? (
        <Empty title="No matches yet">When an operator enters you or your team in a match, it appears here with your verified result.</Empty>
      ) : (
        <div className="panel panel--flush">
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th scope="col">Date</th>
                  <th scope="col">Tournament</th>
                  <th scope="col">Entrant</th>
                  <th scope="col">Result</th>
                  <th scope="col" className="num">Kills</th>
                  <th scope="col" className="num">Place</th>
                  <th scope="col" className="num">Points</th>
                  <th scope="col"><span className="sr-only">Open</span></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((m) => (
                  <tr key={m.matchId}>
                    <td className="small">{formatDateTime(m.startsAt)}</td>
                    <td>
                      <Link to={`/tournaments/${m.tournamentSlug}`}>{m.tournamentName}</Link>
                      <div className="small faint">{m.roundLabel}</div>
                    </td>
                    <td>{m.entrantName}</td>
                    <td>
                      <StatusBadge
                        status={m.resultStatus === 'approved' ? 'approved' : m.resultStatus === 'pending' ? 'pending' : m.resultStatus === 'rejected' ? 'rejected' : 'none'}
                        text={m.resultStatus === 'none' ? 'Not submitted' : label(m.resultStatus)}
                      />
                    </td>
                    <td className="num">{m.resultStatus === 'approved' || m.resultStatus === 'pending' ? m.kills : '–'}</td>
                    <td className="num">{m.resultStatus === 'approved' || m.resultStatus === 'pending' ? ordinal(m.placement ?? 0) : '–'}</td>
                    <td className="num">{m.totalPoints === null ? '–' : m.totalPoints}</td>
                    <td><Link to={`/matches/${m.matchId}`} className="btn btn--sm btn--ghost">Open</Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      <p className="small faint" style={{ marginTop: 12 }}>Points appear only after an administrator approves the result. Pending claims are not scored.</p>
    </div>
  );
}
