import { useState } from 'react';
import { api, ApiError, errorMessage } from '../lib/api.ts';
import { formatDateTime, formatNumber, formatZoneLabel, label, ordinal } from '../lib/format.ts';
import { Link, useSearchParams, useSetSearchParams, useRouter } from '../lib/router.tsx';
import { useAsync, useDocumentTitle } from '../lib/hooks.ts';
import { useLiveEvent, useSession } from '../lib/session.tsx';
import type {
  Announcement,
  EntryOptions,
  HomeData,
  LeaderboardRow,
  Mode,
  PlayerStats,
  PublicMatch,
  Registration,
  TournamentDetail,
  TournamentList,
  TournamentRecord,
} from '../lib/types.ts';
import { PrizeTable, ScoringSummary, TournamentCard } from '../components/tournament.tsx';
import { Avatar, Empty, LoadingBlock, Modal, Notice, PageHead, StatusBadge, Tabs, announce } from '../components/ui.tsx';

/* ------------------------------------------------------------------ */
/* Home                                                                */
/* ------------------------------------------------------------------ */

export function HomePage() {
  useDocumentTitle('ARENA X');
  const { viewer } = useSession();
  const home = useAsync(() => api<HomeData>('GET', '/api/home'), []);

  return (
    <>
      <section className="hero" aria-labelledby="hero-title">
        <div className="container hero__grid">
          <div>
            <span className="eyebrow">Free Fire MAX · Solo · Duo · Squad</span>
            <h1 id="hero-title" className="hero__headline">
              Compete clean.
              <br />
              <em>Verified placements.</em>
            </h1>
            <p className="hero__lede">
              ARENA X runs tournaments end to end: entry, team rosters, private room details, result checks and standings that only count
              approved results.
            </p>
            <div className="hero__ctas">
              <Link to="/tournaments" className="btn btn--primary">
                Browse tournaments
              </Link>
              {viewer ? (
                <Link to="/dashboard" className="btn">
                  Go to dashboard
                </Link>
              ) : (
                <Link to="/register" className="btn">
                  Create your account
                </Link>
              )}
            </div>
          </div>
          <aside className="hero__rail" aria-label="Upcoming and live tournaments">
            {home.loading && !home.data ? <LoadingBlock rows={3} /> : null}
            {home.error ? <Notice tone="error">{errorMessage(home.error)}</Notice> : null}
            {home.data && home.data.featured.length === 0 ? (
              <Empty title="Nothing scheduled yet">Published tournaments will appear here.</Empty>
            ) : null}
            {home.data?.featured.map((t) => (
              <Link key={t.id} to={`/tournaments/${t.slug}`} className="rail-row">
                <StatusBadge status={t.status} />
                <span className="rail-row__name">{t.name}</span>
                <span className="rail-row__time">{formatDateTime(t.startsAt, t.timezone)}</span>
              </Link>
            ))}
          </aside>
        </div>
      </section>

      <section className="section container" aria-labelledby="modes-title">
        <div className="section__head">
          <h2 id="modes-title">Three ways to play</h2>
          <span className="muted small">Roster sizes are enforced at registration.</span>
        </div>
        <div className="mode-grid">
          <article className="mode">
            <span className="mode__count">01</span>
            <h3>Solo</h3>
            <p>Enter alone. Your Free Fire MAX in-game ID on your profile is your entry.</p>
          </article>
          <article className="mode">
            <span className="mode__count">02</span>
            <h3>Duo</h3>
            <p>A captain registers a team of exactly two players, and both need an in-game ID.</p>
          </article>
          <article className="mode">
            <span className="mode__count">04</span>
            <h3>Squad</h3>
            <p>A captain registers a team of exactly four. Every roster change is recorded.</p>
          </article>
        </div>
      </section>

      <section className="section container" aria-labelledby="featured-title">
        <div className="section__head">
          <h2 id="featured-title">Featured tournaments</h2>
          <Link to="/tournaments" className="btn btn--ghost btn--sm">
            All tournaments
          </Link>
        </div>
        {home.data && home.data.featured.length > 0 ? (
          <div className="card-grid">
            {home.data.featured.map((t: TournamentRecord) => (
              <TournamentCard key={t.id} tournament={t} />
            ))}
          </div>
        ) : home.loading ? (
          <LoadingBlock rows={2} />
        ) : (
          <Empty title="No tournaments are open right now">Check back soon, or follow the announcements below.</Empty>
        )}
      </section>

      <section className="section container" aria-labelledby="stats-title">
        <h2 id="stats-title" className="sr-only">
          Platform totals
        </h2>
        <div className="stat-row">
          <div className="stat">
            <span className="stat__value">{formatNumber(home.data?.stats.verifiedResults ?? 0)}</span>
            <span className="stat__label">Verified results</span>
          </div>
          <div className="stat">
            <span className="stat__value">{formatNumber(home.data?.stats.finishedTournaments ?? 0)}</span>
            <span className="stat__label">Completed tournaments</span>
          </div>
          <div className="stat">
            <span className="stat__value">{formatNumber(home.data?.topPlayers.length ?? 0)}</span>
            <span className="stat__label">Ranked players</span>
          </div>
          <div className="stat">
            <span className="stat__value">{formatNumber(home.data?.winners.length ?? 0)}</span>
            <span className="stat__label">Recent winners listed</span>
          </div>
        </div>
      </section>

      <section className="section container" aria-labelledby="board-title">
        <div className="grid-2">
          <div>
            <div className="section__head">
              <h2 id="board-title">Top players</h2>
              <Link to="/leaderboards" className="btn btn--ghost btn--sm">
                Full leaderboards
              </Link>
            </div>
            <LeaderboardTable rows={home.data?.topPlayers ?? []} loading={home.loading} empty="No verified results yet. Standings appear once the first results are approved." />
          </div>
          <div>
            <div className="section__head">
              <h2>Recent winners</h2>
            </div>
            {home.data && home.data.winners.length === 0 ? (
              <Empty title="No finalised winners yet">Winners appear here after a tournament's standings are published.</Empty>
            ) : null}
            {home.data?.winners.map((w) => (
              <div key={`${w.tournamentSlug}-${w.winnerName}`} className="winner-row">
                <span className="rank rank--1">1</span>
                <div style={{ minWidth: 0 }}>
                  <Link to={`/tournaments/${w.tournamentSlug}`} style={{ fontWeight: 600, textDecoration: 'none' }}>
                    {w.tournamentName}
                  </Link>
                  <div className="small muted">{w.winnerName}</div>
                </div>
                <span className="num small muted">{w.totalPoints} pts</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section container" aria-labelledby="news-title">
        <div className="section__head">
          <h2 id="news-title">Announcements</h2>
        </div>
        <AnnouncementList items={home.data?.announcements ?? []} empty="No announcements yet." />
      </section>
    </>
  );
}

export function AnnouncementList({ items, empty }: { items: Announcement[]; empty: string }) {
  if (items.length === 0) return <p className="muted">{empty}</p>;
  return (
    <ul className="list">
      {items.map((a) => (
        <li key={a.id}>
          <div className="row row--between" style={{ alignItems: 'baseline' }}>
            <h3 style={{ textTransform: 'none', fontFamily: 'var(--font-body)', fontSize: '1rem', letterSpacing: 0 }}>{a.title}</h3>
            <span className="small faint">{formatDateTime(a.createdAt)}</span>
          </div>
          <p className="small" style={{ whiteSpace: 'pre-wrap', margin: '6px 0 0' }}>
            {a.body}
          </p>
        </li>
      ))}
    </ul>
  );
}

export function LeaderboardTable({ rows, loading, empty, showAvatars = true }: { rows: LeaderboardRow[]; loading?: boolean; empty: string; showAvatars?: boolean }) {
  if (loading && rows.length === 0) return <LoadingBlock rows={4} />;
  if (rows.length === 0) return <Empty title="No ranking yet">{empty}</Empty>;
  return (
    <div className="panel panel--flush">
      <div className="table-wrap">
        <table className="data">
          <thead>
            <tr>
              <th scope="col">Rank</th>
              <th scope="col">Name</th>
              <th scope="col" className="num">
                Points
              </th>
              <th scope="col" className="num">
                Kills
              </th>
              <th scope="col" className="num">
                Wins
              </th>
              <th scope="col" className="num">
                Matches
              </th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.key} className={row.rank === 1 ? 'is-first' : undefined}>
                <td>
                  <span className={`rank${row.rank === 1 ? ' rank--1' : ''}`}>{row.rank}</span>
                </td>
                <td>
                  <span className="row" style={{ flexWrap: 'nowrap' }}>
                    {showAvatars ? <Avatar avatarKey={row.avatarKey ?? 'titan'} size="sm" /> : null}
                    {showAvatars && row.avatarKey ? (
                      <Link to={`/players/${row.key}`} style={{ fontWeight: 600, textDecoration: 'none' }}>
                        {row.name}
                      </Link>
                    ) : (
                      <span style={{ fontWeight: 600 }}>{row.name}</span>
                    )}
                  </span>
                </td>
                <td className="num" style={{ fontWeight: 600, color: 'var(--text)' }}>
                  {row.totalPoints}
                </td>
                <td className="num">{row.kills}</td>
                <td className="num">{row.wins}</td>
                <td className="num">{row.matchesPlayed}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Tournament list                                                     */
/* ------------------------------------------------------------------ */

const STATUS_FILTERS = [
  { value: '', label: 'All open and past' },
  { value: 'registration_open', label: 'Registration open' },
  { value: 'scheduled', label: 'Scheduled' },
  { value: 'registration_closed', label: 'Registration closed' },
  { value: 'live', label: 'Live' },
  { value: 'completed', label: 'Completed' },
];

export function TournamentsPage() {
  useDocumentTitle('Tournaments');
  const params = useSearchParams();
  const setParams = useSetSearchParams();
  const status = params.get('status') ?? '';
  const mode = params.get('mode') ?? '';
  const list = useAsync(() => {
    const query = new URLSearchParams({ limit: '50' });
    if (status) query.set('status', status);
    if (mode) query.set('mode', mode);
    return api<TournamentList>('GET', `/api/tournaments?${query.toString()}`);
  }, [status, mode]);
  useLiveEvent(['tournament', 'registration', 'match'], () => list.reload());

  return (
    <div className="container" style={{ padding: '2.2rem 0 3rem' }}>
      <PageHead eyebrow="Competition" title="Tournaments">
        <p className="muted" style={{ margin: 0 }}>
          Each tournament shows its own scoring, prize breakdown and time zone.
        </p>
      </PageHead>

      <div className="toolbar" role="search" aria-label="Filter tournaments">
        <label className="sr-only" htmlFor="filter-status">
          Status
        </label>
        <select id="filter-status" className="select" value={status} onChange={(e) => setParams({ status: e.target.value || undefined })}>
          {STATUS_FILTERS.map((f) => (
            <option key={f.value} value={f.value}>
              {f.label}
            </option>
          ))}
        </select>
        <label className="sr-only" htmlFor="filter-mode">
          Mode
        </label>
        <select id="filter-mode" className="select" value={mode} onChange={(e) => setParams({ mode: e.target.value || undefined })}>
          <option value="">All modes</option>
          <option value="solo">Solo</option>
          <option value="duo">Duo</option>
          <option value="squad">Squad</option>
        </select>
        {list.data ? (
          <span className="muted small" aria-live="polite">
            {list.data.total} {list.data.total === 1 ? 'tournament' : 'tournaments'}
          </span>
        ) : null}
      </div>

      {list.error ? <Notice tone="error">{errorMessage(list.error)}</Notice> : null}
      {list.loading && !list.data ? <LoadingBlock rows={3} /> : null}
      {list.data && list.data.items.length === 0 ? (
        <Empty title="No tournaments match these filters">Try another status or mode.</Empty>
      ) : null}
      {list.data && list.data.items.length > 0 ? (
        <div className="card-grid">
          {list.data.items.map((t) => (
            <TournamentCard key={t.id} tournament={t} />
          ))}
        </div>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Tournament detail                                                   */
/* ------------------------------------------------------------------ */

type DetailTab = 'overview' | 'matches' | 'standings' | 'entry';

export function TournamentDetailPage({ slug }: { slug: string }) {
  const { viewer } = useSession();
  const { navigate } = useRouter();
  const detail = useAsync(() => api<TournamentDetail>('GET', `/api/tournaments/${encodeURIComponent(slug)}`), [slug]);
  const [tab, setTab] = useState<DetailTab>('overview');
  useDocumentTitle(detail.data?.tournament.name ?? 'Tournament');
  useLiveEvent(['tournament', 'registration', 'match'], () => detail.reload());

  if (detail.loading && !detail.data) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <LoadingBlock rows={4} />
      </div>
    );
  }
  if (detail.error) {
    const notFound = detail.error instanceof ApiError && detail.error.status === 404;
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <Empty title={notFound ? 'Tournament not found' : 'Could not load this tournament'}>
          {notFound ? 'It may be unpublished or the link is out of date.' : errorMessage(detail.error)}
        </Empty>
        <div className="btn-row" style={{ justifyContent: 'center', marginTop: 16 }}>
          <Link to="/tournaments" className="btn">
            Back to tournaments
          </Link>
        </div>
      </div>
    );
  }
  if (!detail.data) return null;

  const t = detail.data.tournament;
  const canEnter = t.status === 'registration_open';
  const tabs: Array<{ id: DetailTab; label: string }> = [
    { id: 'overview', label: 'Overview' },
    { id: 'matches', label: `Matches (${detail.data.matches.length})` },
    { id: 'standings', label: 'Standings' },
    ...(viewer ? [{ id: 'entry' as const, label: 'Entry' }] : []),
  ];

  return (
    <>
      <header className="t-hero">
        <div className={`cover--${t.coverStyle}`} aria-hidden="true" style={{ position: 'absolute', inset: 0, zIndex: -1, opacity: 0.55 }} />
        <div className="container">
          <nav aria-label="Breadcrumb" className="small muted" style={{ marginBottom: 12 }}>
            <Link to="/tournaments" style={{ color: 'var(--muted)' }}>
              Tournaments
            </Link>{' '}
            / <span>{t.name}</span>
          </nav>
          <div className="row" style={{ gap: 10, marginBottom: 12 }}>
            <StatusBadge status={t.status} />
            <span className="badge">{label(t.mode)} · roster {t.rosterSize}</span>
            <span className="badge">{label(t.approvalMode)}</span>
          </div>
          <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3.4rem)' }}>{t.name}</h1>
          <div className="t-hero__meta">
            <span>
              Starts <strong>{formatDateTime(t.startsAt, t.timezone)}</strong> ({formatZoneLabel(t.timezone)})
            </span>
            <span>
              Registration closes <strong>{formatDateTime(t.regClosesAt, t.timezone)}</strong>
            </span>
            <span>
              Places <strong className="num">{t.confirmedCount}/{t.capacity}</strong>
            </span>
          </div>
          {viewer?.role === 'admin' ? (
            <p className="small" style={{ marginTop: 14 }}>
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => navigate(`/admin/tournaments/${t.id}`)}>
                Manage in the admin portal
              </button>
            </p>
          ) : null}
        </div>
      </header>

      <div className="container" style={{ padding: '1.6rem 0 3rem' }}>
        <Tabs items={tabs} value={tab} onChange={setTab} name="tournament" />
        <div id="panel-tournament" role="tabpanel" aria-labelledby={`tab-tournament-${tab}`}>
          {tab === 'overview' ? (
            <div className="grid-2">
              <div className="stack">
                <section className="panel">
                  <h2 style={{ fontSize: '1.15rem', marginBottom: 10 }}>About</h2>
                  <p style={{ whiteSpace: 'pre-wrap' }}>{t.description || 'No description has been added yet.'}</p>
                </section>
                <section className="panel">
                  <h2 style={{ fontSize: '1.15rem', marginBottom: 10 }}>Rules</h2>
                  <p style={{ whiteSpace: 'pre-wrap' }}>{t.rulesText || 'The operator has not published rules text for this tournament.'}</p>
                  {t.entryRequirements ? (
                    <p className="small" style={{ marginTop: 12 }}>
                      <strong style={{ color: 'var(--text)' }}>Entry requirements:</strong> {t.entryRequirements}
                    </p>
                  ) : null}
                </section>
              </div>
              <div className="stack">
                <section className="panel">
                  <h2 style={{ fontSize: '1.15rem', marginBottom: 10 }}>Scoring</h2>
                  <ScoringSummary t={t} />
                </section>
                <section className="panel">
                  <h2 style={{ fontSize: '1.15rem', marginBottom: 10 }}>Prizes</h2>
                  <PrizeTable t={t} />
                </section>
                {canEnter && !viewer ? (
                  <section className="panel">
                    <h2 style={{ fontSize: '1.15rem', marginBottom: 10 }}>Want in?</h2>
                    <p>Registration is open. Sign in to enter with your in-game ID.</p>
                    <Link to={`/login?next=${encodeURIComponent(`/tournaments/${t.slug}`)}`} className="btn btn--primary">
                      Sign in to enter
                    </Link>
                  </section>
                ) : null}
              </div>
            </div>
          ) : null}

          {tab === 'matches' ? <MatchesTab matches={detail.data.matches} /> : null}

          {tab === 'standings' ? (
            <StandingsTab
              provisional={detail.data.standings.provisional}
              finalizedAt={detail.data.standings.finalizedAt}
              rows={detail.data.standings.rows}
              timezone={t.timezone}
            />
          ) : null}

          {tab === 'entry' && viewer ? <EntryPanel tournament={t} onChanged={detail.reload} /> : null}
        </div>
      </div>
    </>
  );
}

function MatchesTab({ matches }: { matches: PublicMatch[] }) {
  if (matches.length === 0) {
    return <Empty title="No matches scheduled">The operator adds matches as the schedule is confirmed.</Empty>;
  }
  return (
    <div className="panel panel--flush">
      <div className="table-wrap">
        <table className="data">
          <thead>
            <tr>
              <th scope="col">Match</th>
              <th scope="col">Round</th>
              <th scope="col">Starts</th>
              <th scope="col" className="num">
                Entries
              </th>
              <th scope="col">State</th>
            </tr>
          </thead>
          <tbody>
            {matches.map((m) => (
              <tr key={m.id}>
                <td className="num">#{m.matchNumber}</td>
                <td>{m.roundLabel}</td>
                <td>{formatDateTime(m.startsAt)}</td>
                <td className="num">{m.entries}</td>
                <td>
                  <StatusBadge status={m.state} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="small" style={{ padding: '0.9rem 1.25rem 1.1rem', margin: 0 }}>
        Room details are only shown to players entered in a match, from the release time onward. Match times are displayed in the
        tournament's time zone.
      </p>
    </div>
  );
}

function StandingsTab({
  provisional,
  finalizedAt,
  rows,
  timezone,
}: {
  provisional: boolean;
  finalizedAt: string | null;
  rows: TournamentDetail['standings']['rows'];
  timezone: string;
}) {
  return (
    <>
      <Notice tone={provisional ? 'info' : 'success'} title={provisional ? 'Provisional standings' : 'Final standings'}>
        {provisional
          ? 'Only approved results count. Standings can still change until the operator finalises the tournament.'
          : `Finalised ${formatDateTime(finalizedAt, timezone)}. This table is a stored snapshot and will not change.`}
      </Notice>
      {rows.length === 0 ? (
        <Empty title="No standings yet">Standings appear once confirmed entries have approved results.</Empty>
      ) : (
        <div className="panel panel--flush">
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th scope="col">Rank</th>
                  <th scope="col">Entrant</th>
                  <th scope="col" className="num">
                    Points
                  </th>
                  <th scope="col" className="num">
                    Kills
                  </th>
                  <th scope="col" className="num">
                    First places
                  </th>
                  <th scope="col" className="num">
                    Best finish
                  </th>
                  <th scope="col" className="num">
                    Matches
                  </th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={`${row.rank}-${row.entrantName}`} className={row.rank === 1 ? 'is-first' : undefined}>
                    <td>
                      <span className={`rank${row.rank === 1 ? ' rank--1' : ''}`}>{row.rank}</span>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{row.entrantName}</div>
                      {row.members.length > 1 ? <div className="small muted">{row.members.join(', ')}</div> : null}
                    </td>
                    <td className="num" style={{ fontWeight: 600, color: 'var(--text)' }}>
                      {row.totalPoints}
                    </td>
                    <td className="num">{row.kills}</td>
                    <td className="num">{row.firstPlaces}</td>
                    <td className="num">{row.bestPlacement === null ? '–' : ordinal(row.bestPlacement)}</td>
                    <td className="num">{row.matchesPlayed}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
}

/* ---- Entry panel: eligibility, team choice and registration ---- */

function EntryPanel({ tournament: t, onChanged }: { tournament: TournamentRecord; onChanged: () => void }) {
  const { viewer } = useSession();
  const options = useAsync(() => api<EntryOptions>('GET', `/api/tournaments/${encodeURIComponent(t.slug)}/entry`), [t.slug, viewer?.id, t.status]);
  const [teamId, setTeamId] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [confirmCancel, setConfirmCancel] = useState<Registration['id'] | null>(null);
  const isTeam = t.mode !== 'solo';

  const register = async () => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const body = isTeam ? { teamId } : {};
      const data = await api<{ registration: Registration }>('POST', `/api/tournaments/${encodeURIComponent(t.slug)}/registrations`, body);
      const text =
        data.registration.status === 'confirmed'
          ? `You are confirmed for ${t.name}.`
          : data.registration.status === 'pending'
            ? 'Your entry is waiting for the operator to approve it.'
            : 'The tournament is full, so you are on the waitlist. You will be notified if a place opens.';
      setMessage(text);
      announce(text);
      options.reload();
      onChanged();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const withdraw = async (registrationId: string) => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      await api('DELETE', `/api/registrations/${encodeURIComponent(registrationId)}`);
      setConfirmCancel(null);
      setMessage('Your entry has been withdrawn.');
      announce('Entry withdrawn.');
      options.reload();
      onChanged();
    } catch (err) {
      setError(errorMessage(err));
      setConfirmCancel(null);
    } finally {
      setBusy(false);
    }
  };

  if (options.loading && !options.data) return <LoadingBlock rows={2} />;
  if (options.error) return <Notice tone="error">{errorMessage(options.error)}</Notice>;
  if (!options.data) return null;
  const data = options.data;
  const eligibleTeams = data.teams.filter((team) => team.eligible);

  return (
    <div className="grid-2">
      <section className="panel" aria-labelledby="entry-title">
        <h2 id="entry-title" style={{ fontSize: '1.2rem', marginBottom: 12 }}>
          Enter {t.name}
        </h2>
        {message ? <Notice tone="success">{message}</Notice> : null}
        {error ? <Notice tone="error">{error}</Notice> : null}

        {data.myEntries.length > 0 ? (
          <div style={{ marginBottom: 18 }}>
            <p className="small" style={{ marginBottom: 8 }}>
              Your current entry
            </p>
            <ul className="list">
              {data.myEntries.map((entry) => (
                <li key={entry.id} className="row row--between">
                  <span>
                    <strong>{entry.entrantName}</strong> <StatusBadge status={entry.status} />
                  </span>
                  <button type="button" className="btn btn--sm btn--danger" onClick={() => setConfirmCancel(entry.id)} disabled={busy}>
                    Withdraw
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        {data.canRegister ? (
          <form
            onSubmit={(event) => {
              event.preventDefault();
              if (isTeam && !teamId) {
                setError('Choose the team that will enter.');
                return;
              }
              void register();
            }}
            noValidate
          >
            {isTeam ? (
              <div className="field">
                <label htmlFor="entry-team">Team</label>
                <select id="entry-team" className="select" value={teamId} onChange={(e) => setTeamId(e.target.value)} required>
                  <option value="">Choose a team you captain</option>
                  {data.teams.map((team) => (
                    <option key={team.id} value={team.id} disabled={!team.eligible}>
                      {team.name} ({team.memberCount}/{team.rosterSize}){team.eligible ? '' : ' not ready'}
                    </option>
                  ))}
                </select>
                {data.teams.length === 0 ? (
                  <span className="field__hint">
                    You do not captain a {label(t.mode)} team yet. <Link to="/teams">Create one in Teams</Link>.
                  </span>
                ) : null}
                {data.teams.some((team) => !team.eligible) ? (
                  <ul className="small" style={{ margin: '6px 0 0', paddingLeft: 18 }}>
                    {data.teams
                      .filter((team) => !team.eligible)
                      .map((team) => (
                        <li key={team.id}>
                          <strong>{team.name}:</strong> {team.issues.join(' ')}
                        </li>
                      ))}
                  </ul>
                ) : null}
              </div>
            ) : (
              <p>
                You will enter as <strong>{viewer?.displayName}</strong> with in-game ID <span className="num">{viewer?.inGameId}</span>.
              </p>
            )}
            <button type="submit" className="btn btn--primary" disabled={busy || (isTeam && eligibleTeams.length === 0)}>
              {busy ? 'Submitting…' : t.approvalMode === 'manual' ? 'Request entry' : 'Enter now'}
            </button>
          </form>
        ) : (
          <div>
            <p>Entry is not available for you right now.</p>
            <ul className="small" style={{ paddingLeft: 18 }}>
              {data.reasons.map((reason) => (
                <li key={reason}>{reason}</li>
              ))}
              {data.reasons.length === 0 && data.myEntries.length > 0 ? <li>You already have an entry for this tournament.</li> : null}
            </ul>
            {!viewer?.inGameId ? (
              <Link to="/profile" className="btn btn--sm" style={{ marginTop: 10 }}>
                Add in-game ID
              </Link>
            ) : null}
          </div>
        )}
      </section>

      <section className="panel" aria-labelledby="entry-rules">
        <h2 id="entry-rules" style={{ fontSize: '1.15rem', marginBottom: 10 }}>
          Before you enter
        </h2>
        <ul className="small" style={{ paddingLeft: 18, display: 'grid', gap: 6 }}>
          <li>Entries are checked against capacity at the moment you submit, so you always know your status.</li>
          <li>{t.approvalMode === 'manual' ? 'The operator approves each entry before it holds a place.' : 'Places are confirmed automatically until capacity is reached.'}</li>
          <li>When a tournament is full, new entries join the waitlist and move up if a confirmed entry withdraws.</li>
          <li>Room details appear on your dashboard only after they are published for your match.</li>
        </ul>
      </section>

      {confirmCancel ? (
        <Modal title="Withdraw this entry?" onClose={() => setConfirmCancel(null)}>
          <p>You can withdraw while registration is open. A confirmed entry frees its place for the next person on the waitlist.</p>
          <div className="btn-row" style={{ justifyContent: 'flex-end', marginTop: 16 }}>
            <button type="button" className="btn btn--ghost" onClick={() => setConfirmCancel(null)}>
              Keep entry
            </button>
            <button type="button" className="btn btn--danger" disabled={busy} onClick={() => void withdraw(confirmCancel)}>
              Withdraw
            </button>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Leaderboards                                                        */
/* ------------------------------------------------------------------ */

export function LeaderboardsPage() {
  useDocumentTitle('Leaderboards');
  const params = useSearchParams();
  const setParams = useSetSearchParams();
  const scope = params.get('scope') === 'teams' ? 'teams' : 'players';
  const mode = (params.get('mode') ?? 'all') as 'all' | Mode;
  const effectiveMode = scope === 'teams' && mode === 'solo' ? 'all' : mode;
  const board = useAsync(() => {
    const query = new URLSearchParams({ scope, limit: '50' });
    if (effectiveMode !== 'all') query.set('mode', effectiveMode);
    return api<{ rows: LeaderboardRow[] }>('GET', `/api/leaderboards?${query.toString()}`);
  }, [scope, effectiveMode]);
  useLiveEvent(['tournament', 'match', 'registration'], () => board.reload());

  return (
    <div className="container" style={{ padding: '2.2rem 0 3rem' }}>
      <PageHead eyebrow="Rankings" title="Leaderboards">
        <p className="muted" style={{ margin: 0 }}>
          Built only from approved results. Pending or rejected submissions never count.
        </p>
      </PageHead>
      <div className="toolbar" style={{ justifyContent: 'space-between' }}>
        <Tabs
          name="board"
          value={scope}
          onChange={(next) => setParams({ scope: next, mode: next === 'teams' && mode === 'solo' ? undefined : mode === 'all' ? undefined : mode })}
          items={[
            { id: 'players', label: 'Players' },
            { id: 'teams', label: 'Teams' },
          ]}
        />
        <div className="row">
          <label htmlFor="board-mode" className="small muted">
            Mode
          </label>
          <select id="board-mode" className="select" style={{ minWidth: 150 }} value={effectiveMode} onChange={(e) => setParams({ mode: e.target.value === 'all' ? undefined : e.target.value })}>
            <option value="all">All modes</option>
            <option value="solo" disabled={scope === 'teams'}>
              Solo
            </option>
            <option value="duo">Duo</option>
            <option value="squad">Squad</option>
          </select>
        </div>
      </div>
      {board.error ? <Notice tone="error">{errorMessage(board.error)}</Notice> : null}
      <div id="panel-board" role="tabpanel">
        <LeaderboardTable
          rows={board.data?.rows ?? []}
          loading={board.loading}
          showAvatars={scope === 'players'}
          empty="No approved results yet for this selection."
        />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Public player profile                                               */
/* ------------------------------------------------------------------ */

export function PlayerPage({ id }: { id: string }) {
  const profile = useAsync(
    () => api<{ player: { id: string; displayName: string; avatarKey: string; createdAt: string }; stats: PlayerStats }>('GET', `/api/players/${encodeURIComponent(id)}`),
    [id],
  );
  useDocumentTitle(profile.data?.player.displayName ?? 'Player');
  if (profile.loading && !profile.data) return <div className="container" style={{ padding: '2.4rem 0' }}><LoadingBlock rows={2} /></div>;
  if (profile.error) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <Empty title="Player not found">{errorMessage(profile.error)}</Empty>
      </div>
    );
  }
  if (!profile.data) return null;
  const { player, stats } = profile.data;
  return (
    <div className="container" style={{ padding: '2.4rem 0 3rem' }}>
      <div className="row" style={{ gap: 18, marginBottom: 24 }}>
        <Avatar avatarKey={player.avatarKey} size="lg" />
        <div>
          <span className="eyebrow">Player profile</span>
          <h1 style={{ fontSize: 'clamp(1.8rem, 4vw, 2.6rem)' }}>{player.displayName}</h1>
          <p className="small" style={{ margin: 0 }}>
            Joined {formatDateTime(player.createdAt)}
          </p>
        </div>
      </div>
      <div className="stat-row">
        <Stat value={stats.verifiedMatches} label="Verified matches" />
        <Stat value={stats.totalPoints} label="Total points" />
        <Stat value={stats.kills} label="Kills" />
        <Stat value={stats.wins} label="First places" />
      </div>
      <p className="small" style={{ marginTop: 18 }}>
        Only approved results are counted. In-game IDs are private and are not shown on public profiles.
      </p>
    </div>
  );
}

function Stat({ value, label: text }: { value: number; label: string }) {
  return (
    <div className="stat">
      <span className="stat__value">{formatNumber(value)}</span>
      <span className="stat__label">{text}</span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Legal and rules                                                     */
/* ------------------------------------------------------------------ */

export function LegalPage() {
  useDocumentTitle('Rules, data and fair play');
  return (
    <article className="legal container">
      <span className="eyebrow">Policy</span>
      <h1 style={{ margin: '0.5rem 0 1rem' }}>Rules, data and fair play</h1>
      <p>
        This page describes how ARENA X handles results, room details, personal data and prizes. It is a plain-language summary of how the
        platform works, not a legal agreement.
      </p>
      <h2>Independence</h2>
      <p>
        ARENA X is an independent tournament platform. It is not affiliated with, endorsed by, or sponsored by the makers of Free Fire MAX.
        Game names are used only to describe the game the tournaments are for.
      </p>
      <h2>How results count</h2>
      <p>
        A result becomes part of standings only after an administrator approves it. Each approved result stores the scoring rules that were
        in force at review, so later changes do not rewrite history. Corrections create a new record and keep the earlier one in the audit
        trail.
      </p>
      <h2>Room details</h2>
      <p>
        Private room details are stored encrypted. They are shown only to players entered in that match, and only from the release time the
        operator sets. Each view is recorded in an access log.
      </p>
      <h2>Prizes</h2>
      <p>
        ARENA X does not process payments. Prize records show what the operator has allocated, approved and delivered outside the app. A
        prize is marked fulfilled only when an administrator records how it was delivered.
      </p>
      <h2>Personal data</h2>
      <p>
        We store your email address, display name, avatar choice and in-game ID. Your password is stored only as a salted hash. Your in-game
        ID is visible to members of your own team and to administrators, and it is not shown on public pages.
      </p>
      <h2>Fair play</h2>
      <p>
        Accounts can be suspended or banned for cheating, abuse of team chat, impersonation or repeated false submissions. Every moderation
        action is recorded with a reason.
      </p>
      <p className="small" style={{ marginTop: 28 }}>
        Questions about these terms go to the operator of this installation.
      </p>
    </article>
  );
}

export function NotFoundPage() {
  useDocumentTitle('Page not found');
  return (
    <div className="container" style={{ padding: '4rem 0' }}>
      <Empty title="This page does not exist">The link may be out of date. Head back to the tournaments.</Empty>
      <div className="btn-row" style={{ justifyContent: 'center', marginTop: 18 }}>
        <Link to="/" className="btn btn--primary">
          Home
        </Link>
      </div>
    </div>
  );
}
