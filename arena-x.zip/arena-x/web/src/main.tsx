import { createRoot } from 'react-dom/client';
import { App } from './App.tsx';
import './styles.css';

const container = document.getElementById('root');
if (!container) throw new Error('ARENA X could not find its root element.');
createRoot(container).render(<App />);
