import { useEffect, type ReactNode } from 'react';
import { matchPattern, RouterProvider, useRouter } from './lib/router.tsx';
import { SessionProvider, useSession } from './lib/session.tsx';
import { safeInternalPath } from './lib/format.ts';
import { Shell } from './components/layout.tsx';
import { Empty, LoadingBlock, Notice } from './components/ui.tsx';
import { HomePage, LeaderboardsPage, LegalPage, NotFoundPage, PlayerPage, TournamentDetailPage, TournamentsPage } from './pages/public.tsx';
import { AdminLoginPage, LoginPage, RegisterPage } from './pages/auth.tsx';
import { DashboardPage, HistoryPage, MatchPage, NotificationsPage, ProfilePage, TeamDetailPage, TeamsPage } from './pages/player.tsx';
import { AdminAnalyticsPage, AdminAnnouncementsPage, AdminAuditPage, AdminLayout, AdminOverviewPage, AdminPlayersPage, AdminSubmissionsPage, AdminTournamentsPage } from './pages/admin.tsx';
import { AdminTournamentManagePage } from './pages/admin-tournament.tsx';

type Params = Record<string, string>;
type Render = (params: Params) => ReactNode;

/** Route table. Patterns use :params. Access rules are also enforced by the server. */
const ROUTES: Array<{ pattern: string; render: Render; access?: 'player' | 'admin' | 'guest'; admin?: boolean }> = [
  { pattern: '/', render: () => <HomePage /> },
  { pattern: '/tournaments', render: () => <TournamentsPage /> },
  { pattern: '/tournaments/:slug', render: (p) => <TournamentDetailPage key={p.slug} slug={p.slug!} /> },
  { pattern: '/leaderboards', render: () => <LeaderboardsPage /> },
  { pattern: '/players/:id', render: (p) => <PlayerPage key={p.id} id={p.id!} /> },
  { pattern: '/login', render: () => <LoginPage />, access: 'guest' },
  { pattern: '/admin/login', render: () => <AdminLoginPage />, access: 'guest' },
  { pattern: '/register', render: () => <RegisterPage />, access: 'guest' },
  { pattern: '/dashboard', render: () => <DashboardPage />, access: 'player' },
  { pattern: '/profile', render: () => <ProfilePage />, access: 'player' },
  { pattern: '/history', render: () => <HistoryPage />, access: 'player' },
  { pattern: '/notifications', render: () => <NotificationsPage />, access: 'player' },
  { pattern: '/teams', render: () => <TeamsPage />, access: 'player' },
  { pattern: '/teams/:id', render: (p) => <TeamDetailPage key={p.id} id={p.id!} />, access: 'player' },
  { pattern: '/matches/:id', render: (p) => <MatchPage key={p.id} id={p.id!} />, access: 'player' },
  { pattern: '/legal', render: () => <LegalPage /> },
  { pattern: '/admin', render: () => <AdminLayout><AdminOverviewPage /></AdminLayout>, admin: true },
  { pattern: '/admin/tournaments', render: () => <AdminLayout><AdminTournamentsPage /></AdminLayout>, admin: true },
  { pattern: '/admin/tournaments/:id', render: (p) => <AdminLayout><AdminTournamentManagePage key={p.id} id={p.id!} /></AdminLayout>, admin: true },
  { pattern: '/admin/submissions', render: () => <AdminLayout><AdminSubmissionsPage /></AdminLayout>, admin: true },
  { pattern: '/admin/players', render: () => <AdminLayout><AdminPlayersPage /></AdminLayout>, admin: true },
  { pattern: '/admin/announcements', render: () => <AdminLayout><AdminAnnouncementsPage /></AdminLayout>, admin: true },
  { pattern: '/admin/analytics', render: () => <AdminLayout><AdminAnalyticsPage /></AdminLayout>, admin: true },
  { pattern: '/admin/audit', render: () => <AdminLayout><AdminAuditPage /></AdminLayout>, admin: true },
];

function resolve(pathname: string): { render: Render; params: Params; route: (typeof ROUTES)[number] } | null {
  for (const route of ROUTES) {
    const params = matchPattern(route.pattern, pathname);
    if (params) return { render: route.render, params, route };
  }
  return null;
}

function Routes() {
  const { location, navigate } = useRouter();
  const { ready, viewer } = useSession();
  const match = resolve(location.pathname);

  // Access rules for screens. The server still enforces every one of these rules.
  const route = match?.route;
  const needsPlayer = route?.access === 'player';
  const guestOnly = route?.access === 'guest';
  const isAdminRoute = route?.admin === true;

  useEffect(() => {
    if (!ready) return;
    if (needsPlayer && !viewer) {
      navigate(`/login?next=${encodeURIComponent(location.pathname + location.search)}`, { replace: true });
    } else if (guestOnly && viewer) {
      // Honour a safe ?next= path so a freshly signed-in user lands where they were headed.
      const next = safeInternalPath(new URLSearchParams(location.search).get('next'));
      navigate(next ?? (viewer.role === 'admin' ? '/admin' : '/dashboard'), { replace: true });
    }
  }, [ready, needsPlayer, guestOnly, viewer, location.pathname, location.search, navigate]);

  if (!match) {
    return <NotFoundPage />;
  }
  if (!ready && (needsPlayer || isAdminRoute)) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <LoadingBlock rows={3} />
      </div>
    );
  }
  if (needsPlayer && !viewer) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <Notice tone="info">Sign in to open this page. Redirecting…</Notice>
      </div>
    );
  }
  if (guestOnly && viewer) {
    return (
      <div className="container" style={{ padding: '2.4rem 0' }}>
        <LoadingBlock rows={1} />
      </div>
    );
  }
  if (isAdminRoute && viewer?.role !== 'admin' && ready) {
    return <Empty title="Admin access required">Sign in with an administrator account, or return to the public site.</Empty>;
  }
  return <>{match.render(match.params)}</>;
}

export function App() {
  return (
    <RouterProvider>
      <SessionProvider>
        <AppShell />
      </SessionProvider>
    </RouterProvider>
  );
}

function AppShell() {
  return (
    <Shell>
      <Routes />
    </Shell>
  );
}
