import { test } from 'node:test';
import assert from 'node:assert/strict';
import { tempDb, makeAdmin } from '../helpers/fixtures.ts';
import { run, getRow } from '../../server/db/index.ts';
import { recordAudit, verifyAuditChain, redactDetail } from '../../server/lib/audit.ts';

test('the audit chain verifies when untouched and pinpoints an edited row', async () => {
  const env = tempDb();
  try {
    const admin = await makeAdmin(env.db);
    for (let i = 1; i <= 5; i++) {
      recordAudit(env.db, { actorId: admin.id, actorRole: 'admin', action: `test.event_${i}`, entityType: 'test', entityId: null, detail: { n: i } });
    }
    assert.deepEqual(verifyAuditChain(env.db).ok, true);

    // Simulate someone editing history directly in the database.
    run(env.db, "UPDATE audit_events SET detail = '{\"n\":999}' WHERE action = 'test.event_3'");
    const verdict = verifyAuditChain(env.db);
    assert.equal(verdict.ok, false, 'an edited event must break verification');
    const tampered = getRow<{ seq: number }>(env.db, "SELECT seq FROM audit_events WHERE action = 'test.event_3'");
    assert.equal(verdict.brokenAtSeq, tampered?.seq, 'verification must point at the edited event');
  } finally {
    env.cleanup();
  }
});

test('deleting an event from the middle of the chain is also detected', async () => {
  const env = tempDb();
  try {
    const admin = await makeAdmin(env.db);
    for (let i = 1; i <= 4; i++) {
      recordAudit(env.db, { actorId: admin.id, actorRole: 'admin', action: `test.del_${i}`, entityType: 'test', entityId: null, detail: { n: i } });
    }
    run(env.db, "DELETE FROM audit_events WHERE action = 'test.del_2'");
    assert.equal(verifyAuditChain(env.db).ok, false, 'a removed event must break the chain');
  } finally {
    env.cleanup();
  }
});

test('secret-looking keys are redacted before an audit entry is written', () => {
  const redacted = redactDetail({ roomPassword: 'hunter2', password: 'x', safe: 'ok' });
  assert.equal(JSON.stringify(redacted).includes('hunter2'), false);
  assert.equal(redacted.safe, 'ok');
});
