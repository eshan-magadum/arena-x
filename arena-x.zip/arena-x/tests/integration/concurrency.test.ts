import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { tempDb, makeAdmin, makePlayer, soloTournament } from '../helpers/fixtures.ts';
import { getRows } from '../../server/db/index.ts';
import { createTournament, transitionTournament } from '../../server/services/tournaments.ts';
import { verifyAuditChain } from '../../server/lib/audit.ts';

const run = promisify(execFile);
const CHILD = fileURLToPath(new URL('../helpers/register-child.ts', import.meta.url));

interface ChildOutcome {
  ok: boolean;
  status?: string;
  code?: string;
}

async function spawnRegistration(dbPath: string, slug: string, userId: string): Promise<ChildOutcome> {
  const { stdout } = await run(process.execPath, ['--disable-warning=ExperimentalWarning', '--import', 'tsx', CHILD, dbPath, slug, userId], {
    timeout: 60_000,
    cwd: fileURLToPath(new URL('../..', import.meta.url)),
  });
  return JSON.parse(stdout.trim().split('\n').pop() ?? '{}') as ChildOutcome;
}

test('concurrent processes cannot oversell a tournament or double-register one player', async () => {
  const env = tempDb();
  try {
    const admin = await makeAdmin(env.db);
    const tournament = createTournament(env.db, admin, soloTournament({ capacity: 4 }));
    transitionTournament(env.db, admin, tournament.id, { to: 'scheduled' });
    transitionTournament(env.db, admin, tournament.id, { to: 'registration_open' });

    const players = [];
    for (let i = 1; i <= 10; i++) players.push(await makePlayer(env.db, i));
    // The first player also attempts a second registration from a separate process.
    const attempts = [...players.map((p) => p.id), players[0]!.id];

    const outcomes = await Promise.all(attempts.map((id) => spawnRegistration(env.dir + '/test.sqlite', tournament.slug, id)));

    const confirmed = getRows<{ user_id: string }>(
      env.db,
      `SELECT rm.user_id FROM registrations r JOIN registration_members rm ON rm.registration_id = r.id
       WHERE r.tournament_id = ? AND r.status = 'confirmed'`,
      tournament.id,
    );
    assert.equal(confirmed.length, 4, 'exactly capacity-many places may be confirmed');
    assert.equal(new Set(confirmed.map((c) => c.user_id)).size, 4, 'no player may hold two confirmed places');

    const activeRows = getRows<{ n: number }>(
      env.db,
      `SELECT COUNT(*) AS n FROM registrations WHERE tournament_id = ? AND status IN ('pending','confirmed','waitlisted')`,
      tournament.id,
    );
    assert.equal(activeRows[0]!.n, 10, 'each of the ten players has exactly one active registration');

    const successes = outcomes.filter((o) => o.ok).length;
    assert.equal(successes, 10, 'the duplicate attempt must be refused, the other ten must succeed');
    const statuses = outcomes.filter((o) => o.ok).map((o) => o.status).sort();
    assert.deepEqual(statuses.filter((x) => x === 'confirmed').length, 4);
    assert.equal(statuses.filter((x) => x === 'waitlisted').length, 6);
    const failures = outcomes.filter((o) => !o.ok);
    assert.equal(failures.length, 1, 'only the duplicate attempt may fail');
    assert.equal(failures[0]!.code, 'already_registered');
    assert.equal(verifyAuditChain(env.db).ok, true);
  } finally {
    env.cleanup();
  }
});
