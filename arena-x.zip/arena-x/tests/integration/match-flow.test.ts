import { test, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { tempDb, makeAdmin, makePlayer, soloTournament, inMinutes, TEST_SECRET, type TempDb } from '../helpers/fixtures.ts';
import { getRows, getRow } from '../../server/db/index.ts';
import { createTournament, transitionTournament } from '../../server/services/tournaments.ts';
import { registerForTournament } from '../../server/services/registrations.ts';
import { createMatch, assignEntries, setRoom, publishRoom, getRoomForViewer, updateMatch } from '../../server/services/matches.ts';
import { submitResult, reviewSubmission, finalizeTournament } from '../../server/services/results.ts';
import { setClockForTests } from '../../server/lib/clock.ts';
import { verifyAuditChain } from '../../server/lib/audit.ts';
import type { Viewer } from '../../server/services/accounts.ts';

const ROOM_ID = 'LOBBY-778';
const ROOM_PASSWORD = 's3cret-room-pw';

let env: TempDb | null = null;
afterEach(() => {
  setClockForTests(null);
  env?.cleanup();
  env = null;
});

/** Builds a live tournament with three confirmed entries and one match with entries assigned. */
async function setupMatch() {
  env = tempDb();
  const db = env.db;
  const admin = await makeAdmin(db);
  const tournament = createTournament(db, admin, soloTournament({ capacity: 4 }));
  transitionTournament(db, admin, tournament.id, { to: 'scheduled' });
  transitionTournament(db, admin, tournament.id, { to: 'registration_open' });
  const players: Viewer[] = [];
  const registrations = [];
  for (let i = 1; i <= 3; i++) {
    const player = await makePlayer(db, i);
    players.push(player);
    registrations.push(registerForTournament(db, player, tournament.slug, {}));
  }
  const matchId = createMatch(db, admin, tournament.id, { roundLabel: 'Grand Final', startsAt: inMinutes(60) });
  transitionTournament(db, admin, tournament.id, { to: 'registration_closed' });
  transitionTournament(db, admin, tournament.id, { to: 'live' });
  assignEntries(db, admin, matchId, { registrationIds: registrations.map((r) => r.id) });
  return { db, admin, tournament, players, registrations, matchId };
}

test('room credentials stay hidden from outsiders and before release, then reach only entrants', async () => {
  const { db, admin, players, matchId } = await setupMatch();
  setRoom(db, admin, matchId, { roomId: ROOM_ID, roomPassword: ROOM_PASSWORD }, TEST_SECRET);
  publishRoom(db, admin, matchId);

  const outsider = await makePlayer(db, 9);
  assert.throws(
    () => getRoomForViewer(db, outsider, matchId, TEST_SECRET),
    (error: { code?: string }) => error.code === 'not_a_participant',
    'a player who is not entered in the match must be refused outright',
  );

  const entrantEarly = JSON.stringify(getRoomForViewer(db, players[0]!, matchId, TEST_SECRET));
  assert.equal(entrantEarly.includes(ROOM_PASSWORD), false, 'entrant must not see credentials before release time');

  // Match starts in 60 minutes with a 15 minute lead, so release is at 45 minutes from now.
  setClockForTests(Date.now() + 50 * 60_000);
  const entrantLate = JSON.stringify(getRoomForViewer(db, players[0]!, matchId, TEST_SECRET));
  assert.equal(entrantLate.includes(ROOM_ID), true, 'entrant should see the room ID after release');
  assert.equal(entrantLate.includes(ROOM_PASSWORD), true, 'entrant should see the password after release');

  const accessRows = getRows<{ user_id: string; via: string }>(db, 'SELECT user_id, via FROM room_access_log WHERE match_id = ?', matchId);
  assert.ok(accessRows.some((row) => row.user_id === players[0]!.id && row.via === 'participant'), 'every disclosure must be logged');
  assert.equal(accessRows.some((row) => row.user_id === outsider.id), false, 'refused viewers must not be logged as disclosed');
  assert.equal(verifyAuditChain(db).ok, true);
});

test('approved results drive standings, finalisation and exact prize allocations', async () => {
  const { db, admin, tournament, players, matchId } = await setupMatch();
  updateMatch(db, admin, matchId, { state: 'live' });
  updateMatch(db, admin, matchId, { state: 'awaiting_results' });

  // Placement and kills per entrant: 17, 12 and 8 total points under the default table.
  const claims = [
    { kills: 5, placement: 1 },
    { kills: 3, placement: 2 },
    { kills: 0, placement: 3 },
  ];
  const submissions = players.map((player, index) => submitResult(db, player, matchId, claims[index]));
  assert.throws(() => submitResult(db, players[0]!, matchId, claims[0]), (error: { status?: number }) => error.status === 409);

  for (const submission of submissions) {
    reviewSubmission(db, admin, submission.id, { decision: 'approve' });
  }
  // Approving the final verified result completes the match automatically.
  assert.equal(getRow<{ state: string }>(db, 'SELECT state FROM matches WHERE id = ?', matchId)?.state, 'completed');

  const outcome = finalizeTournament(db, admin, tournament.id);

  assert.deepEqual(
    outcome.prizeAwards.map((award) => award.amountMinor),
    [250_000, 150_000, 100_000],
    'prize shares of 50/30/20 percent must allocate the whole pool',
  );
  assert.equal(outcome.standings[0]!.totalPoints, 17);
  assert.equal(outcome.standings[0]!.rank, 1);

  const awards = getRows<{ amount_minor: number }>(db, "SELECT amount_minor FROM prize_awards WHERE tournament_id = ?", tournament.id);
  assert.equal(awards.reduce((sum, row) => sum + row.amount_minor, 0), 500_000);

  const status = getRow<{ status: string }>(db, 'SELECT status FROM tournaments WHERE id = ?', tournament.id);
  assert.equal(status?.status, 'completed');
  assert.equal(verifyAuditChain(db).ok, true);
});

test('a rejected claim is not scored; only the entrant\'s resubmission counts', async () => {
  const { db, admin, tournament, players, matchId } = await setupMatch();
  updateMatch(db, admin, matchId, { state: 'live' });
  updateMatch(db, admin, matchId, { state: 'awaiting_results' });
  const [first, second, third] = players.map((player, index) => submitResult(db, player, matchId, { kills: 2, placement: index + 1 }));
  reviewSubmission(db, admin, first!.id, { decision: 'approve' });
  reviewSubmission(db, admin, second!.id, { decision: 'reject', reason: 'Screenshot does not match the lobby.' });
  reviewSubmission(db, admin, third!.id, { decision: 'approve' });

  // One entrant is still unresolved, so the match cannot complete and the tournament cannot finalise.
  assert.equal(getRow<{ state: string }>(db, 'SELECT state FROM matches WHERE id = ?', matchId)?.state, 'awaiting_results');
  assert.throws(
    () => finalizeTournament(db, admin, tournament.id),
    (error: { code?: string }) => error.code === 'matches_unfinished',
  );

  // The entrant corrects the claim. The rejected claim (2 kills, 2nd place = 11 points) must not survive.
  const corrected = submitResult(db, players[1]!, matchId, { kills: 0, placement: 2 });
  reviewSubmission(db, admin, corrected.id, { decision: 'approve' });
  assert.equal(getRow<{ state: string }>(db, 'SELECT state FROM matches WHERE id = ?', matchId)?.state, 'completed');

  const outcome = finalizeTournament(db, admin, tournament.id);
  const secondEntry = outcome.standings.find((s) => s.registrationId === second!.registrationId);
  assert.equal(secondEntry?.totalPoints, 9, 'only the approved correction (0 kills, 2nd place) may score');
  assert.equal(verifyAuditChain(db).ok, true);
});
