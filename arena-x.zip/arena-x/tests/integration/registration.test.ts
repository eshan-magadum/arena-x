import { test } from 'node:test';
import assert from 'node:assert/strict';
import { tempDb, makeAdmin, makePlayer, soloTournament } from '../helpers/fixtures.ts';
import { createTournament, transitionTournament } from '../../server/services/tournaments.ts';
import { registerForTournament } from '../../server/services/registrations.ts';
import { verifyAuditChain } from '../../server/lib/audit.ts';

test('auto-approved places fill to capacity and overflow is waitlisted', async () => {
  const env = tempDb();
  try {
    const admin = await makeAdmin(env.db);
    const tournament = createTournament(env.db, admin, soloTournament({ capacity: 4 }));
    transitionTournament(env.db, admin, tournament.id, { to: 'scheduled' });
    transitionTournament(env.db, admin, tournament.id, { to: 'registration_open' });

    const statuses: string[] = [];
    for (let i = 1; i <= 5; i++) {
      const player = await makePlayer(env.db, i);
      statuses.push(registerForTournament(env.db, player, tournament.slug, {}).status);
    }
    assert.deepEqual(statuses, ['confirmed', 'confirmed', 'confirmed', 'confirmed', 'waitlisted']);
    assert.equal(verifyAuditChain(env.db).ok, true);
  } finally {
    env.cleanup();
  }
});

test('the same player cannot hold two active registrations in one tournament', async () => {
  const env = tempDb();
  try {
    const admin = await makeAdmin(env.db);
    const tournament = createTournament(env.db, admin, soloTournament());
    transitionTournament(env.db, admin, tournament.id, { to: 'scheduled' });
    transitionTournament(env.db, admin, tournament.id, { to: 'registration_open' });
    const player = await makePlayer(env.db, 1);
    registerForTournament(env.db, player, tournament.slug, {});
    assert.throws(() => registerForTournament(env.db, player, tournament.slug, {}), (error: { status?: number }) => {
      assert.equal(error.status, 409);
      return true;
    });
  } finally {
    env.cleanup();
  }
});

test('registration is refused while the tournament is not open', async () => {
  const env = tempDb();
  try {
    const admin = await makeAdmin(env.db);
    const tournament = createTournament(env.db, admin, soloTournament());
    transitionTournament(env.db, admin, tournament.id, { to: 'scheduled' });
    const player = await makePlayer(env.db, 1);
    assert.throws(() => registerForTournament(env.db, player, tournament.slug, {}));
  } finally {
    env.cleanup();
  }
});

test('a registration window cannot be opened after the closing time has passed', async () => {
  const env = tempDb();
  try {
    const admin = await makeAdmin(env.db);
    const tournament = createTournament(env.db, admin, soloTournament({ regOpensAt: new Date(Date.now() - 3 * 3_600_000).toISOString(), regClosesAt: new Date(Date.now() - 3_600_000).toISOString(), startsAt: new Date(Date.now() + 3_600_000).toISOString() }));
    transitionTournament(env.db, admin, tournament.id, { to: 'scheduled' });
    assert.throws(() => transitionTournament(env.db, admin, tournament.id, { to: 'registration_open' }));
  } finally {
    env.cleanup();
  }
});
