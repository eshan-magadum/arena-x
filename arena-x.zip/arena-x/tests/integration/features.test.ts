/**
 * Features added after the core lifecycle: player match history, administrator analytics, the separate
 * administrator sign-in, the automatic winner announcement, and the live public channel (a guest's
 * event stream receives updates caused by administrator writes).
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import type http from 'node:http';
import { tempDb, makeAdmin, soloTournament, inMinutes, TEST_PASSWORD, TEST_SECRET, type TempDb } from '../helpers/fixtures.ts';
import { loadConfig } from '../../server/lib/config.ts';
import { createHttpApp } from '../../server/http/app.ts';
import { buildRoutes } from '../../server/http/routes.ts';
import { resetRateLimits } from '../../server/lib/rateLimit.ts';
import { setClockForTests } from '../../server/lib/clock.ts';

let env: TempDb;
let server: http.Server;
let base: string;
const streamEvents: string[] = [];
let streamReader: ReadableStreamDefaultReader<Uint8Array> | null = null;

interface Res {
  status: number;
  json: any;
  text: string;
  headers: Headers;
}

async function call(method: string, path: string, options: { cookie?: string; body?: unknown } = {}): Promise<Res> {
  const headers: Record<string, string> = { 'x-arena-request': '1' };
  if (options.body !== undefined) headers['content-type'] = 'application/json';
  if (options.cookie) headers.cookie = `arenax_session=${options.cookie}`;
  const response = await fetch(base + path, { method, headers, body: options.body === undefined ? undefined : JSON.stringify(options.body) });
  const text = await response.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = null;
  }
  return { status: response.status, json, text, headers: response.headers };
}

function cookieFrom(res: Res): string {
  const match = /arenax_session=([^;]+)/.exec(res.headers.get('set-cookie') ?? '');
  assert.ok(match, 'expected a session cookie');
  return match![1]!;
}

/** Waits until the guest stream has delivered an event with the given name. */
async function waitForStreamEvent(name: string, timeoutMs = 5000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (streamEvents.includes(name)) return;
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  assert.fail(`no "${name}" event arrived on the public stream within ${timeoutMs} ms (saw: ${streamEvents.join(', ') || 'none'})`);
}

before(async () => {
  env = tempDb();
  resetRateLimits();
  const config = loadConfig({ ARENA_SECRET: TEST_SECRET, ARENA_DB_PATH: `${env.dir}/test.sqlite`, PORT: '0', HOST: '127.0.0.1' });
  server = createHttpApp({ db: env.db, config, routes: buildRoutes() });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(async () => {
  setClockForTests(null);
  await streamReader?.cancel().catch(() => undefined);
  await new Promise<void>((resolve) => server.close(() => resolve()));
  env.cleanup();
});

test('the live public channel delivers updates to a guest who never signed in', async () => {
  const response = await fetch(`${base}/api/stream`);
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type') ?? '', /text\/event-stream/);
  streamReader = response.body!.getReader();
  const decoder = new TextDecoder();
  void (async () => {
    let buffer = '';
    for (;;) {
      const { value, done } = await streamReader!.read();
      if (done) return;
      buffer += decoder.decode(value, { stream: true });
      let index: number;
      while ((index = buffer.indexOf('\n\n')) !== -1) {
        const block = buffer.slice(0, index);
        buffer = buffer.slice(index + 2);
        const line = block.split('\n').find((l) => l.startsWith('event: '));
        if (line) streamEvents.push(line.slice(7));
      }
    }
  })().catch(() => undefined);
  await waitForStreamEvent('ready');
});

test('full journey: administrator sign-in, live updates, history, analytics and the winner announcement', async () => {
  const admin = await makeAdmin(env.db, 'features');
  const playerEmails: string[] = [];
  const playerIds: string[] = [];
  const playerCookies: string[] = [];
  for (let i = 1; i <= 3; i++) {
    const email = `features-player${i}@test.invalid`;
    const signUp = await call('POST', '/api/auth/register', { body: { email, password: TEST_PASSWORD, displayName: `Feature ${i}`, inGameId: String(8_300_000 + i * 13) } });
    assert.equal(signUp.status, 200, signUp.text);
    playerEmails.push(email);
    playerIds.push(signUp.json.viewer.id);
    playerCookies.push(cookieFrom(await call('POST', '/api/auth/login', { body: { email, password: TEST_PASSWORD } })));
  }

  // The separate administrator sign-in: a player's correct password is refused and no session is kept.
  const playerAtAdminDoor = await call('POST', '/api/admin/auth/login', { body: { email: playerEmails[0], password: TEST_PASSWORD } });
  assert.equal(playerAtAdminDoor.status, 403);
  assert.equal(playerAtAdminDoor.json?.error?.code, 'not_administrator');
  assert.equal(playerAtAdminDoor.headers.get('set-cookie'), null, 'a refused administrator sign-in must not set a session cookie');

  const adminLogin = await call('POST', '/api/admin/auth/login', { body: { email: admin.email, password: TEST_PASSWORD } });
  assert.equal(adminLogin.status, 200, adminLogin.text);
  const adminCookie = cookieFrom(adminLogin);

  // Administrator work. Each write should reach the guest's live stream.
  const created = await call('POST', '/api/admin/tournaments', { cookie: adminCookie, body: soloTournament({ capacity: 4 }) });
  assert.ok(created.status >= 200 && created.status < 300, created.text);
  const tid = created.json.tournament.id as string;
  const slug = created.json.tournament.slug as string;
  streamEvents.length = 0;
  const opened = await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to: 'scheduled' } });
  assert.equal(opened.status, 200);
  await waitForStreamEvent('tournament');
  await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to: 'registration_open' } });

  const registrationIds: string[] = [];
  for (const cookie of playerCookies) {
    const reg = await call('POST', `/api/tournaments/${slug}/registrations`, { cookie, body: {} });
    assert.ok(reg.status >= 200 && reg.status < 300, reg.text);
    registrationIds.push((reg.json.registration ?? reg.json).id as string);
  }

  const matchId = (await call('POST', `/api/admin/tournaments/${tid}/matches`, { cookie: adminCookie, body: { roundLabel: 'Grand Final', startsAt: inMinutes(60) } })).json.matchId as string;
  await call('PUT', `/api/admin/matches/${matchId}/entries`, { cookie: adminCookie, body: { registrationIds } });
  await call('PUT', `/api/admin/matches/${matchId}/room`, { cookie: adminCookie, body: { roomId: 'FEAT-1', roomPassword: 'feat-pass' } });
  await call('POST', `/api/admin/matches/${matchId}/room/publish`, { cookie: adminCookie, body: {} });
  await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to: 'registration_closed' } });
  await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to: 'live' } });
  await call('PATCH', `/api/admin/matches/${matchId}`, { cookie: adminCookie, body: { state: 'live' } });

  const claims = [{ kills: 6, placement: 1 }, { kills: 2, placement: 2 }, { kills: 0, placement: 3 }];
  const submissionIds: string[] = [];
  for (let i = 0; i < 3; i++) {
    const res = await call('POST', `/api/matches/${matchId}/results`, { cookie: playerCookies[i], body: claims[i] });
    assert.equal(res.status, 201, res.text);
    submissionIds.push((res.json.submission ?? res.json).id as string);
  }
  // Player 1's claim is approved, player 2 is rejected, player 3 stays pending.
  assert.equal((await call('POST', `/api/admin/submissions/${submissionIds[0]}/decision`, { cookie: adminCookie, body: { decision: 'approve' } })).status, 200);
  assert.equal((await call('POST', `/api/admin/submissions/${submissionIds[1]}/decision`, { cookie: adminCookie, body: { decision: 'reject', reason: 'Screenshot does not match.' } })).status, 200);

  // History: the approved claim shows points, the rejected one shows as rejected, the pending one as pending.
  const history = async (cookie: string) => (await call('GET', '/api/me/matches', { cookie })).json.matches as Array<{ resultStatus: string; totalPoints: number | null; kills: number | null }>;
  const first = await history(playerCookies[0]!);
  assert.equal(first.length, 1, 'a player sees the match they were entered in');
  assert.equal(first[0]!.resultStatus, 'approved');
  assert.equal(first[0]!.totalPoints, 18, 'six kills plus first place');
  assert.equal((await history(playerCookies[1]!))[0]!.resultStatus, 'rejected');
  const pending = await history(playerCookies[2]!);
  assert.equal(pending[0]!.resultStatus, 'pending');
  assert.equal(pending[0]!.totalPoints, null, 'an unverified claim must not show points');

  // Resolve the rest before finalising: player 2 corrects the rejected claim, and both remaining claims are approved.
  const corrected = await call('POST', `/api/matches/${matchId}/results`, { cookie: playerCookies[1], body: { kills: 2, placement: 2 } });
  assert.equal(corrected.status, 201, corrected.text);
  const correctedId = (corrected.json.submission ?? corrected.json).id as string;
  assert.equal((await call('POST', `/api/admin/submissions/${correctedId}/decision`, { cookie: adminCookie, body: { decision: 'approve' } })).status, 200);
  assert.equal((await call('POST', `/api/admin/submissions/${submissionIds[2]}/decision`, { cookie: adminCookie, body: { decision: 'approve' } })).status, 200);

  // Analytics: administrators only, and the numbers match the data.
  assert.equal((await call('GET', '/api/admin/analytics', { cookie: playerCookies[0] })).status, 403);
  const analytics = (await call('GET', '/api/admin/analytics', { cookie: adminCookie })).json.analytics;
  assert.ok(analytics.players.total >= 3);
  assert.equal(analytics.registrations.byStatus.confirmed, 3);
  assert.equal(analytics.results.byStatus.approved, 3, 'one approved result per entry: the first claim, the corrected claim and the third claim');
  assert.equal(analytics.results.byStatus.rejected, 1);
  assert.equal(analytics.results.byStatus.pending ?? 0, 0);
  assert.equal(analytics.dailyRegistrations.length, 14);
  assert.equal(analytics.dailyRegistrations.reduce((sum: number, d: { count: number }) => sum + d.count, 0), 3);

  // Finalising publishes a winner announcement and a live update.
  streamEvents.length = 0;
  await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to: 'completed' } }).then((r) => {
    assert.ok(r.status === 200, `finalise: ${r.text}`);
  });
  await waitForStreamEvent('tournament');
  const announcements = (await call('GET', '/api/announcements')).json.items as Array<{ title: string; body: string }>;
  const winners = announcements.find((a) => a.title.startsWith('Winners:'));
  assert.ok(winners, 'finalising must publish a winner announcement');
  assert.match(winners!.body, /#1 Feature 1 \(18 points\)/);
  assert.match(winners!.body, /#2 Feature 2 \(11 points\)/);
  assert.match(winners!.body, /#3 Feature 3 \(8 points\)/);

  const prizes = (await call('GET', `/api/admin/tournaments/${tid}/prizes`, { cookie: adminCookie })).json.prizes as Array<{ amountMinor: number }>;
  assert.equal(prizes.reduce((sum, p) => sum + p.amountMinor, 0), 500_000);
  assert.ok(playerIds.length === 3);
});
