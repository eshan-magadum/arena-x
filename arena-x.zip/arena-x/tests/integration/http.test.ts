import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import type http from 'node:http';
import { getRow } from '../../server/db/index.ts';
import { tempDb, makeAdmin, makePlayer, TEST_PASSWORD, TEST_SECRET, type TempDb } from '../helpers/fixtures.ts';
import { loadConfig } from '../../server/lib/config.ts';
import { createHttpApp } from '../../server/http/app.ts';
import { buildRoutes } from '../../server/http/routes.ts';
import { resetRateLimits } from '../../server/lib/rateLimit.ts';
import { createTournament, transitionTournament } from '../../server/services/tournaments.ts';
import { registerForTournament } from '../../server/services/registrations.ts';
import { soloTournament } from '../helpers/fixtures.ts';

let env: TempDb;
let server: http.Server;
let base: string;
let playerEmail: string;
let adminEmail: string;
const PASSWORD = TEST_PASSWORD;

before(async () => {
  env = tempDb();
  resetRateLimits();
  const config = loadConfig({ ARENA_SECRET: TEST_SECRET, ARENA_DB_PATH: `${env.dir}/test.sqlite`, PORT: '0', HOST: '127.0.0.1' });
  const admin = await makeAdmin(env.db, 'http');
  const player = await makePlayer(env.db, 1);
  playerEmail = player.email;
  adminEmail = admin.email;
  // A tournament with a registered player and a match with a room, so room and chat routes have data.
  const tournament = createTournament(env.db, admin, soloTournament());
  transitionTournament(env.db, admin, tournament.id, { to: 'scheduled' });
  transitionTournament(env.db, admin, tournament.id, { to: 'registration_open' });
  registerForTournament(env.db, player, tournament.slug, {});

  server = createHttpApp({ db: env.db, config, routes: buildRoutes() });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
  env.cleanup();
});

const POST_HEADERS = { 'content-type': 'application/json', 'x-arena-request': '1' };

async function login(email: string): Promise<string> {
  const response = await fetch(`${base}/api/auth/login`, {
    method: 'POST',
    headers: POST_HEADERS,
    body: JSON.stringify({ email, password: PASSWORD }),
  });
  assert.equal(response.status, 200, 'login should succeed');
  const cookie = response.headers.get('set-cookie') ?? '';
  const match = /arenax_session=([^;]+)/.exec(cookie);
  assert.ok(match, 'login must set the session cookie');
  return match[1]!;
}

test('health responds without any session and carries security headers', async () => {
  const response = await fetch(`${base}/api/health`);
  assert.equal(response.status, 200);
  assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(response.headers.get('x-frame-options'), 'DENY');
  assert.match(response.headers.get('content-security-policy') ?? '', /default-src 'self'/);
  assert.match(response.headers.get('content-security-policy') ?? '', /frame-ancestors 'none'/);
});

test('the session cookie is HttpOnly and SameSite=Lax', async () => {
  const response = await fetch(`${base}/api/auth/login`, {
    method: 'POST',
    headers: POST_HEADERS,
    body: JSON.stringify({ email: playerEmail, password: PASSWORD }),
  });
  const cookie = response.headers.get('set-cookie') ?? '';
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Lax/);
});

test('state-changing requests without the CSRF header are refused', async () => {
  const response = await fetch(`${base}/api/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ email: playerEmail, password: PASSWORD }),
  });
  assert.equal(response.status, 403);
});

test('a cross-origin request is refused even with the CSRF header', async () => {
  const response = await fetch(`${base}/api/auth/login`, {
    method: 'POST',
    headers: { ...POST_HEADERS, origin: 'https://evil.example' },
    body: JSON.stringify({ email: playerEmail, password: PASSWORD }),
  });
  assert.equal(response.status, 403);
});

test('unknown body fields such as role are rejected with a field-level error', async () => {
  const response = await fetch(`${base}/api/auth/register`, {
    method: 'POST',
    headers: POST_HEADERS,
    body: JSON.stringify({ email: 'new.player@test.invalid', password: 'long-enough-pw', displayName: 'New Player', role: 'admin' }),
  });
  assert.equal(response.status, 422);
  const body = (await response.json()) as { error?: { details?: Array<{ message: string }> } };
  assert.ok(
    body.error?.details?.some((detail) => /unrecognized/i.test(detail.message) && /role/.test(detail.message)),
    `expected an unrecognised-key error naming "role", got ${JSON.stringify(body)}`,
  );
  const created = getRow<{ n: number }>(env.db, "SELECT COUNT(*) AS n FROM users WHERE email = 'new.player@test.invalid'");
  assert.equal(created?.n, 0, 'the rejected registration must not create an account');
});

test('admin routes refuse anonymous and player sessions', async () => {
  const anonymous = await fetch(`${base}/api/admin/dashboard`);
  assert.equal(anonymous.status, 401);

  const playerToken = await login(playerEmail);
  const asPlayer = await fetch(`${base}/api/admin/dashboard`, { headers: { cookie: `arenax_session=${playerToken}` } });
  assert.equal(asPlayer.status, 403);
});

test('an administrator reaches admin routes', async () => {
  const adminToken = await login(adminEmail);
  const response = await fetch(`${base}/api/admin/dashboard`, { headers: { cookie: `arenax_session=${adminToken}` } });
  assert.equal(response.status, 200);
});

test('a logged-out session token is no longer accepted', async () => {
  const token = await login(playerEmail);
  const logout = await fetch(`${base}/api/auth/logout`, {
    method: 'POST',
    headers: { ...POST_HEADERS, cookie: `arenax_session=${token}` },
  });
  assert.equal(logout.status, 200);
  const after2 = await fetch(`${base}/api/auth/session`, { headers: { cookie: `arenax_session=${token}` } });
  const body = (await after2.json()) as { viewer: unknown };
  assert.equal(body.viewer, null, 'a revoked token must not identify anyone');
});

test('room credentials are absent from public tournament and match payloads', async () => {
  const response = await fetch(`${base}/api/tournaments`);
  const text = await response.text();
  assert.equal(text.includes('roomPassword'), false);
  assert.equal(text.includes('room_credentials'), false);
});

test('admin login rate limiting stops repeated wrong passwords', async () => {
  let limited = false;
  for (let i = 0; i < 40 && !limited; i++) {
    const response = await fetch(`${base}/api/auth/login`, {
      method: 'POST',
      headers: { ...POST_HEADERS, 'x-forwarded-for': '203.0.113.9' },
      body: JSON.stringify({ email: 'nobody@test.invalid', password: 'wrong-password-value' }),
    });
    if (response.status === 429) limited = true;
  }
  assert.equal(limited, true, 'repeated failed logins should eventually be rate limited');
});
