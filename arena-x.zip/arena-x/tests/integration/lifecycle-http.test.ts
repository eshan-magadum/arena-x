/**
 * End-to-end tournament lifecycle over HTTP, using real sessions, cookies and the CSRF header.
 * Covers: public sign-up, tournament creation and publishing, registration, match scheduling,
 * room release timing, results submission and review, finalisation, prize records, exports,
 * moderation and the audit chain.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import type http from 'node:http';
import { tempDb, makeAdmin, soloTournament, inMinutes, TEST_PASSWORD, TEST_SECRET, type TempDb } from '../helpers/fixtures.ts';
import { loadConfig } from '../../server/lib/config.ts';
import { createHttpApp } from '../../server/http/app.ts';
import { buildRoutes } from '../../server/http/routes.ts';
import { resetRateLimits } from '../../server/lib/rateLimit.ts';
import { setClockForTests } from '../../server/lib/clock.ts';

let env: TempDb;
let server: http.Server;
let base: string;

interface Res {
  status: number;
  json: any;
  text: string;
  headers: Headers;
}

async function call(method: string, path: string, options: { cookie?: string; body?: unknown } = {}): Promise<Res> {
  const headers: Record<string, string> = { 'x-arena-request': '1' };
  if (options.body !== undefined) headers['content-type'] = 'application/json';
  if (options.cookie) headers.cookie = `arenax_session=${options.cookie}`;
  const response = await fetch(base + path, {
    method,
    headers,
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });
  const text = await response.text();
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = null;
  }
  return { status: response.status, json, text, headers: response.headers };
}

async function signIn(email: string, password = TEST_PASSWORD): Promise<string> {
  const res = await call('POST', '/api/auth/login', { body: { email, password } });
  assert.ok(res.status >= 200 && res.status < 300, `sign-in should succeed for ${email}`);
  const match = /arenax_session=([^;]+)/.exec(res.headers.get('set-cookie') ?? '');
  assert.ok(match, 'sign-in must set the session cookie');
  return match![1]!;
}

before(async () => {
  env = tempDb();
  resetRateLimits();
  const config = loadConfig({ ARENA_SECRET: TEST_SECRET, ARENA_DB_PATH: `${env.dir}/test.sqlite`, PORT: '0', HOST: '127.0.0.1' });
  server = createHttpApp({ db: env.db, config, routes: buildRoutes() });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(async () => {
  setClockForTests(null);
  await new Promise<void>((resolve) => server.close(() => resolve()));
  env.cleanup();
});

test('full tournament lifecycle over HTTP', async () => {
  // 1. Accounts: an administrator (created by the CLI path in production) and three players who sign up publicly.
  const admin = await makeAdmin(env.db, 'lifecycle');
  const adminCookie = await signIn(admin.email);

  const players: Array<{ id: string; email: string; cookie: string }> = [];
  for (let i = 1; i <= 3; i++) {
    const email = `lifecycle-player${i}@test.invalid`;
    const signUp = await call('POST', '/api/auth/register', {
      body: { email, password: TEST_PASSWORD, displayName: `Lifecycle ${i}`, inGameId: String(8_100_000 + i * 17) },
    });
    assert.ok(signUp.status >= 200 && signUp.status < 300, `public sign-up should work: ${signUp.text}`);
    assert.equal(signUp.json?.viewer?.role, 'player', 'public sign-up must never grant administrator');
    players.push({ id: signUp.json.viewer.id, email, cookie: await signIn(email) });
  }

  // 2. Administrator creates a tournament, then publishes it and opens registration.
  const created = await call('POST', '/api/admin/tournaments', {
    cookie: adminCookie,
    body: soloTournament({ capacity: 4, roomLeadMinutes: 15 }),
  });
  assert.ok(created.status >= 200 && created.status < 300, `tournament creation: ${created.text}`);
  const tournament = created.json.tournament ?? created.json;
  const tid = tournament.id as string;
  const slug = tournament.slug as string;
  assert.ok(tid && slug, 'created tournament must carry an id and slug');

  for (const to of ['scheduled', 'registration_open']) {
    const res = await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to } });
    assert.ok(res.status >= 200 && res.status < 300, `transition to ${to}: ${res.text}`);
  }

  // The public listing shows it; a player sees the tournament page.
  const listing = await call('GET', '/api/tournaments');
  assert.ok(JSON.stringify(listing.json).includes(slug), 'published tournament must appear publicly');

  // 3. Players register.
  const registrations: Array<{ id: string }> = [];
  for (const player of players) {
    const res = await call('POST', `/api/tournaments/${slug}/registrations`, { cookie: player.cookie, body: {} });
    assert.ok(res.status >= 200 && res.status < 300, `registration: ${res.text}`);
    registrations.push(res.json.registration ?? res.json);
  }
  assert.equal(registrations.length, 3);
  assert.ok(registrations.every((r) => r.id), 'every registration needs an id');

  // 4. Match is scheduled, entries assigned, room set and published.
  const matchRes = await call('POST', `/api/admin/tournaments/${tid}/matches`, {
    cookie: adminCookie,
    body: { roundLabel: 'Grand Final', startsAt: inMinutes(60) },
  });
  assert.ok(matchRes.status >= 200 && matchRes.status < 300, `match creation: ${matchRes.text}`);
  const matchId = matchRes.json.matchId as string;
  assert.ok(matchId, 'match creation must return its id');

  const entries = await call('PUT', `/api/admin/matches/${matchId}/entries`, {
    cookie: adminCookie,
    body: { registrationIds: registrations.map((r) => r.id) },
  });
  assert.ok(entries.status >= 200 && entries.status < 300, `assign entries: ${entries.text}`);

  const roomSet = await call('PUT', `/api/admin/matches/${matchId}/room`, {
    cookie: adminCookie,
    body: { roomId: 'LIFE-4471', roomPassword: 'life-pass-9' },
  });
  assert.ok(roomSet.status >= 200 && roomSet.status < 300, `set room: ${roomSet.text}`);
  assert.equal(roomSet.text.includes('life-pass-9'), false, 'the admin write response must not echo the room password');
  const publish = await call('POST', `/api/admin/matches/${matchId}/room/publish`, { cookie: adminCookie, body: {} });
  assert.ok(publish.status >= 200 && publish.status < 300, `publish room: ${publish.text}`);

  // 5. Room timing: an outsider is refused; entrants see nothing before release; then they see it.
  const outsiderSignIn = await call('POST', '/api/auth/register', {
    body: { email: 'lifecycle-outsider@test.invalid', password: TEST_PASSWORD, displayName: 'Outsider Pat', inGameId: '8200001' },
  });
  assert.ok(outsiderSignIn.status >= 200 && outsiderSignIn.status < 300);
  const outsiderCookie = await signIn('lifecycle-outsider@test.invalid');
  const refused = await call('GET', `/api/matches/${matchId}/room`, { cookie: outsiderCookie });
  assert.equal(refused.status, 403, 'a non-entrant must be refused');
  assert.equal(refused.text.includes('LIFE-4471'), false);

  const early = await call('GET', `/api/matches/${matchId}/room`, { cookie: players[0]!.cookie });
  assert.equal(early.text.includes('life-pass-9'), false, 'credentials must not appear before release');

  setClockForTests(Date.now() + 50 * 60_000); // release is at match start minus 15 minutes
  const released = await call('GET', `/api/matches/${matchId}/room`, { cookie: players[0]!.cookie });
  assert.ok(released.status >= 200 && released.status < 300);
  assert.ok(released.text.includes('LIFE-4471') && released.text.includes('life-pass-9'), 'entrant must receive credentials after release');

  // 6. Live play and results.
  const transitionLive = await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to: 'registration_closed' } });
  assert.ok(transitionLive.status >= 200 && transitionLive.status < 300);
  const startTournament = await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to: 'live' } });
  assert.ok(startTournament.status >= 200 && startTournament.status < 300, `start tournament: ${startTournament.text}`);
  const matchLive = await call('PATCH', `/api/admin/matches/${matchId}`, { cookie: adminCookie, body: { state: 'live' } });
  assert.ok(matchLive.status >= 200 && matchLive.status < 300, `match to live: ${matchLive.text}`);

  const claims = [
    { kills: 6, placement: 1 },
    { kills: 2, placement: 2 },
    { kills: 0, placement: 3 },
  ];
  const submissionIds: string[] = [];
  for (let i = 0; i < players.length; i++) {
    const res = await call('POST', `/api/matches/${matchId}/results`, { cookie: players[i]!.cookie, body: claims[i] });
    assert.ok(res.status >= 200 && res.status < 300, `submit result: ${res.text}`);
    submissionIds.push((res.json.submission ?? res.json).id as string);
  }
  const duplicate = await call('POST', `/api/matches/${matchId}/results`, { cookie: players[0]!.cookie, body: claims[0] });
  assert.equal(duplicate.status, 409, 'a second submission for the same entry must be refused');

  for (const id of submissionIds) {
    const res = await call('POST', `/api/admin/submissions/${id}/decision`, { cookie: adminCookie, body: { decision: 'approve' } });
    assert.ok(res.status >= 200 && res.status < 300, `approve: ${res.text}`);
  }

  // 7. Finalisation and prize records.
  const finalise = await call('POST', `/api/admin/tournaments/${tid}/transition`, { cookie: adminCookie, body: { to: 'completed' } });
  assert.ok(finalise.status >= 200 && finalise.status < 300, `finalise: ${finalise.text}`);

  const standings = await call('GET', `/api/admin/tournaments/${tid}/standings`, { cookie: adminCookie });
  const board = standings.json?.standings;
  assert.equal(board?.provisional, false, 'finalised standings must not be marked provisional');
  assert.ok(board?.finalizedAt, 'finalised standings must record when they were finalised');
  const rows = board.standings as Array<{ totalPoints: number }>;
  assert.equal(rows.length, 3, `standings endpoint: ${standings.text}`);
  assert.equal(rows[0]!.totalPoints, 6 + 12, 'first place: six kills plus twelve placement points');
  assert.equal(rows[1]!.totalPoints, 2 + 9);
  assert.equal(rows[2]!.totalPoints, 0 + 8);

  const prizes = await call('GET', `/api/admin/tournaments/${tid}/prizes`, { cookie: adminCookie });
  const awards = prizes.json.awards ?? prizes.json.prizes ?? prizes.json;
  const amounts = (awards as Array<{ amountMinor: number }>).map((a) => a.amountMinor).sort((a, b) => b - a);
  assert.deepEqual(amounts, [250_000, 150_000, 100_000]);
  assert.equal(amounts.reduce((sum, n) => sum + n, 0), 500_000, 'allocations must equal the pool');

  // 8. Exports, announcements, audit chain.
  const csv = await call('GET', `/api/admin/export/results?tournamentId=${tid}`, { cookie: adminCookie });
  assert.ok(csv.status >= 200 && csv.status < 300, `results export: ${csv.text}`);
  assert.match(csv.headers.get('content-type') ?? '', /text\/csv/);
  assert.ok(csv.text.split('\r\n')[0]!.length > 0, 'export must start with a header row');

  const announcement = await call('POST', '/api/admin/announcements', {
    cookie: adminCookie,
    body: { title: 'Grand Final results are in', body: 'Standings are final and prizes are being recorded.' },
  });
  assert.ok(announcement.status >= 200 && announcement.status < 300, `announcement: ${announcement.text}`);
  const publicAnnouncements = await call('GET', '/api/announcements');
  assert.ok(JSON.stringify(publicAnnouncements.json).includes('Grand Final results are in'));

  const verify = await call('GET', '/api/admin/audit/verify', { cookie: adminCookie });
  assert.equal(verify.json.ok, true, 'audit chain must verify after a full lifecycle');

  // 9. Moderation takes effect immediately: a suspended player cannot submit.
  const moderate = await call('POST', `/api/admin/players/${players[2]!.id}/moderation`, {
    cookie: adminCookie,
    body: { action: 'suspend', reason: 'Lifecycle test suspension', days: 1 },
  });
  assert.ok(moderate.status >= 200 && moderate.status < 300, `moderation: ${moderate.text}`);
  // Suspension revokes live sessions at once, so the old cookie no longer identifies anyone...
  const oldSession = await call('GET', '/api/auth/session', { cookie: players[2]!.cookie });
  assert.equal(oldSession.json.viewer, null, "a suspended player's existing session must be revoked");
  // ...and signing in again is refused with the reason.
  const retry = await call('POST', '/api/auth/login', { body: { email: players[2]!.email, password: TEST_PASSWORD } });
  assert.equal(retry.status, 403, `suspended sign-in: ${retry.text}`);
  assert.equal(retry.json?.error?.code, 'account_suspended');
});
