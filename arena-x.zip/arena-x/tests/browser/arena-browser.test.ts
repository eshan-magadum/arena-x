/// <reference lib="dom" />
/**
 * Browser test: drives the real web app in Chromium through the tournament journey.
 * UI actions: administrator match creation, entries, room draft and publish, match state, registration
 * close and start, finalisation; each player reads their room and submits a result; administrator
 * approves results and checks standings and prizes; announcement and CSV export; mobile overflow;
 * keyboard skip link; console errors.
 *
 * Setup that is not the subject of the test (accounts, the tournament, registrations) goes through the
 * service layer for speed. The test skips, with a message, when Playwright or Chromium cannot launch.
 */
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AddressInfo } from 'node:net';
import type http from 'node:http';
import { tempDb, makeAdmin, makePlayer, soloTournament, TEST_PASSWORD, TEST_SECRET, type TempDb } from '../helpers/fixtures.ts';
import { loadConfig } from '../../server/lib/config.ts';
import { createHttpApp } from '../../server/http/app.ts';
import { buildRoutes } from '../../server/http/routes.ts';
import { resetRateLimits } from '../../server/lib/rateLimit.ts';
import { createTournament, transitionTournament } from '../../server/services/tournaments.ts';
import { registerForTournament } from '../../server/services/registrations.ts';
import { getRow, getRows } from '../../server/db/index.ts';
import type { Viewer } from '../../server/services/accounts.ts';

type Browser = { newContext(options?: object): Promise<any>; close(): Promise<void> };

let env: TempDb;
let server: http.Server;
let base: string;
let browser: Browser | null = null;
let skipReason = '';
// Set ARENA_SCREENSHOT_DIR to keep the screenshots; otherwise the folder is removed after the run.
const keepShots = Boolean(process.env.ARENA_SCREENSHOT_DIR);
const shots = process.env.ARENA_SCREENSHOT_DIR ?? mkdtempSync(join(tmpdir(), 'arenax-shots-'));

/** Local wall-clock value for a datetime-local input in Asia/Kolkata. */
function kolkataLocal(date: Date): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);
  const get = (type: string) => parts.find((p) => p.type === type)!.value;
  return `${get('year')}-${get('month')}-${get('day')}T${get('hour')}:${get('minute')}`;
}

before(async () => {
  try {
    const { chromium } = await import('playwright');
    browser = (await chromium.launch()) as unknown as Browser;
  } catch (error) {
    skipReason = `Chromium unavailable: ${(error as Error).message.split('\n')[0]}`;
  }
  env = tempDb();
  resetRateLimits();
  const config = loadConfig({ ARENA_SECRET: TEST_SECRET, ARENA_DB_PATH: `${env.dir}/test.sqlite`, PORT: '0', HOST: '127.0.0.1' });
  server = createHttpApp({ db: env.db, config, routes: buildRoutes() });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', () => resolve()));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});

after(async () => {
  await browser?.close();
  if (!keepShots) rmSync(shots, { recursive: true, force: true });
  await new Promise<void>((resolve) => server.close(() => resolve()));
  env.cleanup();
});

test('the tournament journey works in a real browser', async (t) => {
  if (!browser) {
    t.skip(skipReason);
    return;
  }
  const db = env.db;
  const admin: Viewer = await makeAdmin(db, 'browser');
  const players: Viewer[] = [];
  for (let i = 1; i <= 3; i++) players.push(await makePlayer(db, i));

  const tournament = createTournament(db, admin, soloTournament({ capacity: 4, roomLeadMinutes: 15 }));
  transitionTournament(db, admin, tournament.id, { to: 'scheduled' });
  transitionTournament(db, admin, tournament.id, { to: 'registration_open' });
  for (const player of players) registerForTournament(db, player, tournament.slug, {});

  const consoleProblems: string[] = [];
  const newPage = async (viewport = { width: 1280, height: 900 }) => {
    const context = await browser!.newContext({ viewport });
    const page = await context.newPage();
    page.on('console', (m: { type(): string; text(): string }) => {
      if (m.type() === 'error') consoleProblems.push(m.text());
    });
    page.on('pageerror', (e: Error) => consoleProblems.push(e.message));
    return { context, page };
  };
  const signIn = async (page: any, email: string) => {
    await page.goto(`${base}/login`);
    await page.fill('#login-email', email);
    await page.fill('#login-password', TEST_PASSWORD);
    await page.click('button[type="submit"]');
  };

  // Administrator creates a match at +10 minutes. With a 15 minute lead, the room is already releasable.
  const admins = await newPage();
  await signIn(admins.page, admin.email);
  await admins.page.waitForURL(/\/admin/);
  await admins.page.goto(`${base}/admin/tournaments/${tournament.id}`);
  await admins.page.getByRole('heading', { name: tournament.name }).waitFor();
  await admins.page.getByRole('tab', { name: /^Matches/ }).click();
  await admins.page.fill('#m-round', 'Grand Final');
  await admins.page.fill('#m-starts', kolkataLocal(new Date(Date.now() + 10 * 60_000)));
  await admins.page.click('button:has-text("Add match")');
  await admins.page.getByText('Grand Final').first().waitFor();

  // Entries: check all three players and save.
  await admins.page.click('button:has-text("Entries")');
  for (const player of players) {
    await admins.page.getByLabel(player.displayName, { exact: false }).first().check();
  }
  await admins.page.click('button:has-text("Save entries")');
  await admins.page.getByText(/3 entries/).first().waitFor();

  // Room: save a draft, publish it.
  await admins.page.click('button:has-text("Room")');
  await admins.page.fill('#room-id-' + (await matchIdFor(db, tournament.id)), 'UI-ROOM-552');
  await admins.page.fill('#room-pw-' + (await matchIdFor(db, tournament.id)), 'ui-pass-42');
  await admins.page.click('button:has-text("Save draft")');
  await admins.page.click('button:has-text("Publish")');
  await admins.page.getByText(/published/i).first().waitFor();

  // Close registration and start the tournament, then set the match live.
  await admins.page.click('button:has-text("Close registration")');
  await admins.page.click('button:has-text("Start tournament")');
  await admins.page.getByRole('dialog').getByRole('button', { name: 'Start tournament' }).click();
  await admins.page.getByLabel(/Change state of match/).first().selectOption('live');

  // Each player: sees the room (released), submits a result through the form.
  const claims = [
    { kills: 5, placement: 1 },
    { kills: 2, placement: 2 },
    { kills: 0, placement: 3 },
  ];
  const matchId = await matchIdFor(db, tournament.id);
  for (let i = 0; i < players.length; i++) {
    const ui = await newPage();
    await signIn(ui.page, players[i]!.email);
    await ui.page.waitForURL(/\/dashboard/);
    await ui.page.goto(`${base}/matches/${matchId}`);
    await ui.page.getByText('UI-ROOM-552').first().waitFor();
    await ui.page.fill('#res-kills', String(claims[i]!.kills));
    await ui.page.fill('#res-place', String(claims[i]!.placement));
    await ui.page.click('button:has-text("Submit result")');
    await ui.page.getByText(/submitted|pending|waiting/i).first().waitFor();
    if (i === 0) {
      await ui.page.setViewportSize({ width: 390, height: 844 });
      await ui.page.screenshot({ path: join(shots, 'player-match-mobile.png'), fullPage: true });
      const overflow = await ui.page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      const culprits = await ui.page.evaluate(() =>
        [...document.querySelectorAll<HTMLElement>('body *')]
          .filter((el) => el.getBoundingClientRect().right > window.innerWidth + 1)
          .slice(0, 6)
          .map((el) => `${el.tagName.toLowerCase()}.${String(el.className).split(' ')[0]} right=${Math.round(el.getBoundingClientRect().right)}`),
      );
      assert.ok(overflow <= 1, `player match page must not scroll sideways on a phone (overflow ${overflow}px): ${culprits.join('; ')}`);
    }
    await ui.context.close();
  }

  // Administrator approves each pending result in the queue.
  await admins.page.goto(`${base}/admin/submissions`);
  const approveButtons = () => admins.page.getByRole('button', { name: 'Approve', exact: true });
  await approveButtons().first().waitFor();
  for (let remaining = await approveButtons().count(); remaining > 0; remaining = await approveButtons().count()) {
    await approveButtons().first().click();
    await admins.page.waitForFunction(
      (before: number) => document.querySelectorAll('button')[0] !== undefined && [...document.querySelectorAll('button')].filter((b) => b.textContent?.trim() === 'Approve').length < before,
      remaining,
      { timeout: 5000 },
    );
  }
  const leftover = await approveButtons().count();
  const statuses = getRows<{ status: string; n: number }>(db, 'SELECT status, COUNT(*) AS n FROM result_submissions WHERE match_id = ? GROUP BY status', matchId);
  assert.deepEqual(
    Object.fromEntries(statuses.map((r) => [r.status, r.n])),
    { approved: 3 },
    `every result must be approved; approve buttons left: ${leftover}`,
  );
  assert.equal(getRow<{ state: string }>(db, 'SELECT state FROM matches WHERE id = ?', matchId)?.state, 'completed');

  // Finalise standings from the tournament page.
  await admins.page.goto(`${base}/admin/tournaments/${tournament.id}`);
  await admins.page.click('button:has-text("Finalise standings")');
  await admins.page.getByRole('dialog').getByRole('button', { name: 'Finalise standings' }).click();
  await admins.page.getByText(/Finalised\./).first().waitFor();
  await admins.page.getByRole('tab', { name: 'Standings' }).click();
  await admins.page.locator('table.data').waitFor({ timeout: 10_000 });
  for (const player of players) {
    const shown = await admins.page.getByText(player.displayName, { exact: true }).count();
    if (shown === 0) {
      const text = ((await admins.page.locator('main').innerText()) ?? '').slice(0, 700).replace(/\n+/g, ' | ');
      const selected = await admins.page.evaluate(() => [...document.querySelectorAll('[role="tab"][aria-selected="true"]')].map((t) => t.textContent).join(','));
      assert.fail(`standings do not show ${player.displayName}; selected tab: ${selected}; console: ${consoleProblems.join(' | ').slice(0, 400)}; page says: ${text}`);
    }
  }
  await admins.page.getByRole('tab', { name: 'Prizes' }).click();
  await admins.page.getByText(/2,500/).first().waitFor();
  await admins.page.getByText(/1,500/).first().waitFor();
  await admins.page.getByText(/1,000/).first().waitFor();

  // CSV export downloads.
  await admins.page.getByRole('tab', { name: 'Overview' }).click();
  const [download] = await Promise.all([
    admins.page.waitForEvent('download'),
    admins.page.click('a[href*="export/results"]'),
  ]);
  assert.match(download.suggestedFilename(), /\.csv$/);

  // Announcement published from the console appears on the public page.
  await admins.page.goto(`${base}/admin/announcements`);
  await admins.page.fill('#ann-title', 'Browser test announcement');
  await admins.page.fill('#ann-body', 'This announcement was published from the admin console in a browser test.');
  await admins.page.click('button:has-text("Publish to all players")');
  await admins.page.waitForTimeout(400);
  const publicPage = await newPage();
  await publicPage.page.goto(`${base}/`);
  await publicPage.page.getByText('Browser test announcement').first().waitFor({ timeout: 5000 });

  // Keyboard: the first Tab on the home page reaches the skip link.
  await publicPage.page.keyboard.press('Tab');
  const focused = await publicPage.page.evaluate(() => document.activeElement?.textContent ?? '');
  assert.match(focused, /skip/i, `first Tab should reach the skip link, reached "${focused}"`);

  // Mobile: public tournaments and the admin console must not scroll sideways.
  const phone = await newPage({ width: 390, height: 844 });
  for (const path of ['/', '/tournaments', '/leaderboards']) {
    await phone.page.goto(base + path);
    const overflow = await phone.page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    assert.ok(overflow <= 1, `${path} must not scroll sideways on a phone (overflow ${overflow}px)`);
  }
  await phone.page.screenshot({ path: join(shots, 'home-mobile.png'), fullPage: true });
  await phone.context.close();

  await admins.page.screenshot({ path: join(shots, 'admin-prizes.png'), fullPage: true });
  await admins.context.close();
  await publicPage.context.close();

  assert.deepEqual(consoleProblems, [], `console errors during the journey: ${consoleProblems.join(' | ')}`);
  mkdirSync(shots, { recursive: true });
});

async function matchIdFor(db: TempDb['db'], tournamentId: string): Promise<string> {
  const row = getRow<{ id: string }>(db, 'SELECT id FROM matches WHERE tournament_id = ? ORDER BY match_number DESC LIMIT 1', tournamentId);
  return row!.id;
}

test('administrator sign-in, analytics, match history and navigation work in a real browser', async (t) => {
  if (!browser) {
    t.skip(skipReason);
    return;
  }
  const db = env.db;
  const admin: Viewer = await makeAdmin(db, 'analytics');
  const player: Viewer = await makePlayer(db, 90);
  const consoleProblems: string[] = [];
  const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await context.newPage();
  page.on('console', (m: { type(): string; text(): string }) => {
    if (m.type() === 'error') consoleProblems.push(m.text());
  });
  page.on('pageerror', (e: Error) => consoleProblems.push(e.message));

  // A player account must be refused on the administrator sign-in, even with the right password.
  await page.goto(`${base}/admin/login`);
  await page.fill('#admin-login-email', player.email);
  await page.fill('#admin-login-password', TEST_PASSWORD);
  await page.click('button[type="submit"]');
  await page.getByText('This sign-in is for administrators only.').waitFor({ timeout: 10_000 });
  assert.equal(new URL(page.url()).pathname, '/admin/login', 'a refused player must stay on the administrator sign-in');
  // The refusal itself is a 403 that the browser logs. Only that expected entry is discarded here.
  consoleProblems.length = 0;

  // The administrator signs in and reaches the analytics page.
  await page.fill('#admin-login-email', admin.email);
  await page.fill('#admin-login-password', TEST_PASSWORD);
  await page.click('button[type="submit"]');
  await page.waitForURL((url: URL) => url.pathname === '/admin', { timeout: 10_000 });
  await page.goto(`${base}/admin/analytics`);
  await page.getByRole('heading', { name: 'Analytics', exact: true }).waitFor({ timeout: 10_000 });
  await page.getByRole('heading', { name: 'Prize records', exact: true }).waitFor();

  // Every administrator navigation link opens its screen without a console error.
  for (const label of ['Overview', 'Tournaments', 'Result review', 'Players', 'Announcements', 'Analytics', 'Audit and exports']) {
    await page.locator('.admin-side').getByRole('link', { name: label, exact: true }).click();
    await page.waitForLoadState('domcontentloaded');
    const heading = page.getByRole('heading', { level: 1 }).first();
    await heading.waitFor({ timeout: 10_000 });
  }
  await page.screenshot({ path: join(shots, 'admin-analytics.png'), fullPage: true });

  // The player's match history renders its empty state.
  await context.clearCookies();
  await page.goto(`${base}/login`);
  await page.fill('#login-email', player.email);
  await page.fill('#login-password', TEST_PASSWORD);
  await page.click('button[type="submit"]');
  await page.waitForURL((url: URL) => url.pathname === '/dashboard', { timeout: 10_000 });
  await page.goto(`${base}/history`);
  await page.getByRole('heading', { name: 'Match history', exact: true }).waitFor({ timeout: 10_000 });
  await page.getByText('No matches yet').waitFor();
  await page.screenshot({ path: join(shots, 'player-history.png'), fullPage: true });

  await context.close();
  assert.deepEqual(consoleProblems, [], `console errors: ${consoleProblems.join(' | ')}`);
});
