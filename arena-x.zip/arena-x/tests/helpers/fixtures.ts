/**
 * Test fixtures. Each test gets its own temporary SQLite file so tests cannot leak state into each
 * other. Accounts are created through the real service layer, never by writing password hashes
 * by hand, except for the administrator which public registration cannot create.
 */
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openDatabase, getRow, run, type Db } from '../../server/db/index.ts';
import { hashPassword, newId } from '../../server/lib/crypto.ts';
import { nowIso } from '../../server/lib/clock.ts';
import { registerAccount, toViewer, type UserRow, type Viewer } from '../../server/services/accounts.ts';

export const TEST_SECRET = 'integration-test-secret-not-for-real-use-0123456789';
export const TEST_PASSWORD = 'correct-horse-battery-staple';

export interface TempDb {
  db: Db;
  dir: string;
  cleanup: () => void;
}

export function tempDb(): TempDb {
  const dir = mkdtempSync(join(tmpdir(), 'arenax-test-'));
  const db = openDatabase(join(dir, 'test.sqlite'));
  return {
    db,
    dir,
    cleanup: () => {
      db.close();
      rmSync(dir, { recursive: true, force: true });
    },
  };
}

export async function makeAdmin(db: Db, label = 'admin'): Promise<Viewer> {
  const id = newId();
  const at = nowIso();
  run(
    db,
    `INSERT INTO users (id, email, password_hash, display_name, avatar_key, role, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'titan', 'admin', 'active', ?, ?)`,
    id,
    `${label}-${id.slice(0, 6)}@test.invalid`,
    await hashPassword(TEST_PASSWORD),
    `Admin ${label}`,
    at,
    at,
  );
  return toViewer(getRow<UserRow>(db, 'SELECT * FROM users WHERE id = ?', id)!);
}

export async function makePlayer(db: Db, n: number): Promise<Viewer> {
  return registerAccount(db, {
    email: `player${n}-${newId().slice(0, 6)}@test.invalid`,
    password: TEST_PASSWORD,
    displayName: `Player ${n}`,
    inGameId: String(7_000_000 + n * 11),
  });
}

/** ISO instant offset from now by the given number of minutes. */
export function inMinutes(minutes: number): string {
  return new Date(Date.now() + minutes * 60_000).toISOString();
}

export function soloTournament(overrides: Record<string, unknown> = {}) {
  return {
    name: `Test Cup ${newId().slice(0, 5)}`,
    description: 'Integration test tournament with a valid description for publishing.',
    rulesText: 'Standard lobby rules.',
    entryRequirements: 'Valid in-game ID.',
    mode: 'solo',
    capacity: 4,
    approvalMode: 'auto',
    regOpensAt: inMinutes(-60),
    regClosesAt: inMinutes(24 * 60),
    startsAt: inMinutes(2 * 24 * 60),
    timezone: 'Asia/Kolkata',
    maxEntriesPerMatch: 12,
    killPoint: 1,
    placementPoints: [12, 9, 8, 7, 6, 5, 4, 3, 2, 1],
    tiebreakOrder: ['kills', 'first_places', 'best_placement'],
    prizePoolMinor: 500_000,
    prizeCurrency: 'INR',
    prizeShareBps: [5000, 3000, 2000],
    roomLeadMinutes: 15,
    coverStyle: 'ember',
    ...overrides,
  };
}
