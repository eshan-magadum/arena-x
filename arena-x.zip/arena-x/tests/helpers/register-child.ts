/**
 * Child process used by the concurrency test. Each child opens the same SQLite file independently
 * and attempts one registration, so the test exercises cross-process locking, not just in-memory
 * serialisation. Prints a single JSON line with the outcome.
 */
import { openDatabase, getRow } from '../../server/db/index.ts';
import { toViewer, type UserRow } from '../../server/services/accounts.ts';
import { registerForTournament } from '../../server/services/registrations.ts';

const [dbPath, slug, userId] = process.argv.slice(2);
if (!dbPath || !slug || !userId) {
  console.log(JSON.stringify({ ok: false, code: 'bad_arguments' }));
  process.exit(2);
}

const db = openDatabase(dbPath);
try {
  const row = getRow<UserRow>(db, 'SELECT * FROM users WHERE id = ?', userId);
  if (!row) throw new Error('user missing');
  const result = registerForTournament(db, toViewer(row), slug, {});
  console.log(JSON.stringify({ ok: true, status: result.status }));
} catch (error) {
  const code = (error as { code?: string }).code ?? 'error';
  console.log(JSON.stringify({ ok: false, code }));
} finally {
  db.close();
}
