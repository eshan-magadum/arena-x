import { test } from 'node:test';
import assert from 'node:assert/strict';
import { toCsv } from '../../server/services/platform.ts';
import { zonedLocalToIso, isoToZonedLocal, safeInternalPath } from '../../web/src/lib/format.ts';

test('CSV quotes commas, quotes and newlines and doubles embedded quotes', () => {
  const csv = toCsv(['name', 'note'], [['Ace, Jr', 'said "gg"\nlater']]);
  assert.equal(csv, 'name,note\r\n"Ace, Jr","said ""gg""\nlater"\r\n');
});

test('CSV neutralises spreadsheet formulas by prefixing a quote', () => {
  const csv = toCsv(['value'], [['=HYPERLINK("x")'], ['+1'], ['-2'], ['@sum'], [null], [7]]);
  const lines = csv.split('\r\n');
  assert.equal(lines[1], `"'=HYPERLINK(""x"")"`);
  assert.equal(lines[2], "'+1");
  assert.equal(lines[3], "'-2");
  assert.equal(lines[4], "'@sum");
  assert.equal(lines[5], '');
  assert.equal(lines[6], '7');
});

test('zoned local times convert to the correct UTC instant', () => {
  // Asia/Kolkata is UTC+05:30 with no daylight saving.
  assert.equal(zonedLocalToIso('2030-11-01T18:30', 'Asia/Kolkata'), '2030-11-01T13:00:00.000Z');
  // New York is still on EDT (UTC-4) on 1 Nov 2030; US daylight time ends on 3 Nov.
  assert.equal(zonedLocalToIso('2030-11-01T18:30', 'America/New_York'), '2030-11-01T22:30:00.000Z');
  assert.equal(zonedLocalToIso('not a date', 'Asia/Kolkata'), null);
});

test('zoned conversion round-trips for input fields', () => {
  const iso = zonedLocalToIso('2030-06-15T09:45', 'Europe/London');
  assert.ok(iso);
  assert.equal(isoToZonedLocal(iso!, 'Europe/London'), '2030-06-15T09:45');
  assert.equal(isoToZonedLocal('bogus', 'Asia/Kolkata'), '');
});

test('internal redirects reject protocol-relative and absolute external targets', () => {
  assert.equal(safeInternalPath('/tournaments'), '/tournaments');
  assert.equal(safeInternalPath('//evil.example'), null);
  assert.equal(safeInternalPath('https://evil.example'), null);
  assert.equal(safeInternalPath(null), null);
});
