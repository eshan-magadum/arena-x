import { test } from 'node:test';
import assert from 'node:assert/strict';
import { canTransition, acceptsRegistrations, lockedFields, scheduleIssues, transitionBlockers } from '../../server/domain/tournamentRules.ts';

test('status moves only along the published lifecycle', () => {
  assert.equal(canTransition('draft', 'scheduled'), true);
  assert.equal(canTransition('registration_open', 'registration_closed'), true);
  assert.equal(canTransition('registration_closed', 'registration_open'), true);
  assert.equal(canTransition('live', 'completed'), true);
  // Stale or malicious requests must never move a tournament backwards or revive a finished one.
  assert.equal(canTransition('completed', 'registration_open'), false);
  assert.equal(canTransition('cancelled', 'scheduled'), false);
  assert.equal(canTransition('draft', 'live'), false);
});

test('registration is accepted only while open and before the closing instant', () => {
  const closes = '2030-01-01T10:00:00.000Z';
  assert.equal(acceptsRegistrations('registration_open', closes, new Date('2029-12-31T10:00:00Z')), true);
  assert.equal(acceptsRegistrations('registration_open', closes, new Date('2030-01-01T10:00:00Z')), false);
  assert.equal(acceptsRegistrations('scheduled', closes, new Date('2029-12-31T10:00:00Z')), false);
});

test('structural and rule fields lock once players can register', () => {
  const open = lockedFields('registration_open', true);
  assert.ok(open.has('mode'));
  assert.ok(open.has('prizePoolMinor'));
  assert.ok(!open.has('name'));
  assert.ok(lockedFields('live', false).has('startsAt'));
  assert.equal(lockedFields('draft', false).has('mode'), false);
});

test('a schedule must close registration after it opens and start after it closes', () => {
  const good = { regOpensAt: '2030-01-01T00:00:00Z', regClosesAt: '2030-01-02T00:00:00Z', startsAt: '2030-01-02T12:00:00Z' };
  assert.deepEqual(scheduleIssues(good), []);
  assert.ok(scheduleIssues({ ...good, regClosesAt: good.regOpensAt }).length > 0);
  assert.ok(scheduleIssues({ ...good, startsAt: '2030-01-01T23:00:00Z' }).length > 0);
});

test('publishing needs a real description and a match before going live', () => {
  const base = {
    from: 'draft' as const,
    name: 'Weekend Cup',
    description: 'Short',
    mode: 'solo',
    capacity: 8,
    scheduleIssues: [],
    matchCount: 0,
    now: new Date('2030-01-01T00:00:00Z'),
    regClosesAt: '2030-01-02T00:00:00Z',
  };
  assert.ok(transitionBlockers({ ...base, to: 'scheduled' }).some((r) => r.includes('description')));
  const live = transitionBlockers({ ...base, from: 'registration_closed', to: 'live', description: 'A proper description here.' });
  assert.ok(live.some((r) => r.includes('match')));
  const illegal = transitionBlockers({ ...base, from: 'completed', to: 'live', description: 'A proper description here.', matchCount: 2 });
  assert.equal(illegal.length, 1);
});

test('registration cannot be opened when its closing time has already passed', () => {
  const past = { from: 'scheduled' as const, to: 'registration_open' as const, name: 'Weekend Cup', description: 'A proper description here.', mode: 'solo', capacity: 8, scheduleIssues: [], matchCount: 0, now: new Date('2030-01-05T00:00:00Z'), regClosesAt: '2030-01-02T00:00:00Z' };
  assert.ok(transitionBlockers(past).some((r) => r.includes('already passed')));
  assert.deepEqual(transitionBlockers({ ...past, regClosesAt: '2030-01-09T00:00:00Z' }), []);
});
