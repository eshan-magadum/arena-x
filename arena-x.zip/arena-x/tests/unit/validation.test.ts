import { test } from 'node:test';
import assert from 'node:assert/strict';
import { z } from 'zod';
import { isKnownTimeZone, parseWith, registerSchema, resultSubmissionSchema, tournamentCreateSchema, moderationSchema } from '../../server/lib/validation.ts';

const validTournament = {
  name: 'Weekend Solo Cup',
  mode: 'solo',
  capacity: 8,
  regOpensAt: '2030-01-01T00:00:00Z',
  regClosesAt: '2030-01-02T00:00:00Z',
  startsAt: '2030-01-03T00:00:00Z',
  timezone: 'Asia/Kolkata',
};

test('Asia/Kolkata is accepted even though it is missing from supportedValuesOf', () => {
  assert.equal(isKnownTimeZone('Asia/Kolkata'), true);
  assert.equal(isKnownTimeZone('Not/AZone'), false);
  assert.equal(parseWith(tournamentCreateSchema, validTournament).timezone, 'Asia/Kolkata');
});

test('unknown zones and unknown keys are rejected with field paths', () => {
  assert.throws(() => parseWith(tournamentCreateSchema, { ...validTournament, timezone: 'Mars/Olympus' }), /Some details need attention/);
  assert.throws(() => parseWith(tournamentCreateSchema, { ...validTournament, status: 'completed' }));
  assert.throws(() => parseWith(registerSchema, { email: 'a@b.co', password: 'long-enough-pw', displayName: 'Ace', role: 'admin' }));
});

test('mass-assignment fields such as role are rejected on registration', () => {
  const result = registerSchema.safeParse({ email: 'a@b.co', password: 'long-enough-pw', displayName: 'Ace', role: 'admin' });
  assert.equal(result.success, false);
});

test('display names and in-game IDs follow their formats', () => {
  const base = { email: 'ace@example.com', password: 'long-enough-pw' };
  assert.equal(registerSchema.safeParse({ ...base, displayName: 'Ace', inGameId: '12345' }).success, false);
  assert.equal(registerSchema.safeParse({ ...base, displayName: 'Ace', inGameId: '1234567' }).success, true);
  assert.equal(registerSchema.safeParse({ ...base, displayName: 'Ace<script>' }).success, false);
});

test('negative kills and fractional placements are rejected', () => {
  assert.equal(resultSubmissionSchema.safeParse({ kills: -1, placement: 1 }).success, false);
  assert.equal(resultSubmissionSchema.safeParse({ kills: 1, placement: 1.5 }).success, false);
  assert.equal(resultSubmissionSchema.safeParse({ kills: 2, placement: 1 }).success, true);
});

test('evidence must be https without embedded credentials', () => {
  const base = { kills: 1, placement: 1 };
  assert.equal(resultSubmissionSchema.safeParse({ ...base, evidenceUrl: 'http://example.com/a.png' }).success, false);
  assert.equal(resultSubmissionSchema.safeParse({ ...base, evidenceUrl: 'https://user:pw@example.com/a.png' }).success, false);
  assert.equal(resultSubmissionSchema.safeParse({ ...base, evidenceUrl: 'https://example.com/a.png' }).success, true);
});

test('moderation reasons must be substantive', () => {
  assert.equal(moderationSchema.safeParse({ action: 'ban', reason: 'no' }).success, false);
  assert.equal(moderationSchema.safeParse({ action: 'ban', reason: 'Repeated cheating reports' }).success, true);
  assert.ok(z.string().safeParse('x').success);
});
