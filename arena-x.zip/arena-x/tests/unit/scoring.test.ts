import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  pointsForPlacement,
  scoreResult,
  validateResultValues,
  rankEntries,
  unresolvedTiesWithin,
  validateScoringRules,
  type EntryTotals,
} from '../../server/domain/scoring.ts';

const rules = {
  killPoint: 1,
  placementPoints: [12, 9, 8, 7, 6, 5, 4, 3, 2, 1],
  tiebreakOrder: ['kills', 'first_places', 'best_placement'] as const,
};
const mutableRules = { ...rules, tiebreakOrder: [...rules.tiebreakOrder] };

test('placement points follow the table and score zero beyond it', () => {
  assert.equal(pointsForPlacement(1, mutableRules), 12);
  assert.equal(pointsForPlacement(10, mutableRules), 1);
  assert.equal(pointsForPlacement(11, mutableRules), 0);
});

test('a result scores kills times kill point plus placement points', () => {
  assert.deepEqual(scoreResult({ kills: 7, placement: 2 }, { ...mutableRules, killPoint: 2 }), {
    killPoints: 14,
    placementPoints: 9,
    totalPoints: 23,
  });
});

test('result values reject negative, fractional and out-of-range inputs', () => {
  assert.deepEqual(validateResultValues({ kills: 3, placement: 4 }, 12), []);
  assert.ok(validateResultValues({ kills: -1, placement: 1 }, 12).some((i) => i.field === 'kills'));
  assert.ok(validateResultValues({ kills: 1.5, placement: 1 }, 12).some((i) => i.field === 'kills'));
  assert.ok(validateResultValues({ kills: 100, placement: 1 }, 12).some((i) => i.field === 'kills'));
  assert.ok(validateResultValues({ kills: 1, placement: 0 }, 12).some((i) => i.field === 'placement'));
  assert.ok(validateResultValues({ kills: 1, placement: 13 }, 12).some((i) => i.field === 'placement'));
  assert.ok(validateResultValues({ kills: '3', placement: 1 }, 12).some((i) => i.field === 'kills'));
});

function entry(id: string, totalPoints: number, kills: number, firstPlaces: number, bestPlacement: number | null): EntryTotals {
  return { registrationId: id, totalPoints, kills, firstPlaces, bestPlacement, matchesPlayed: 1 };
}

test('ranking sorts by total points first', () => {
  const ranked = rankEntries([entry('a', 10, 5, 0, 3), entry('b', 20, 1, 0, 9), entry('c', 15, 9, 0, 1)]);
  assert.deepEqual(
    ranked.map((r) => [r.registrationId, r.rank]),
    [
      ['b', 1],
      ['c', 2],
      ['a', 3],
    ],
  );
});

test('tie-breakers resolve equal points in the configured order', () => {
  const byKills = rankEntries(
    [entry('a', 30, 4, 1, 1), entry('b', 30, 9, 0, 5)],
    ['kills', 'first_places', 'best_placement'],
  );
  assert.equal(byKills[0]!.registrationId, 'b');

  const byFirstPlaces = rankEntries(
    [entry('a', 30, 4, 1, 1), entry('b', 30, 9, 0, 5)],
    ['first_places', 'kills', 'best_placement'],
  );
  assert.equal(byFirstPlaces[0]!.registrationId, 'a');
});

test('fully tied entries share a rank using competition ranking', () => {
  const ranked = rankEntries([entry('a', 20, 5, 1, 1), entry('b', 20, 5, 1, 1), entry('c', 10, 0, 0, 4)]);
  const ranks = Object.fromEntries(ranked.map((r) => [r.registrationId, r.rank]));
  assert.equal(ranks.a, 1);
  assert.equal(ranks.b, 1);
  assert.equal(ranks.c, 3);
});

test('unresolved ties inside the prize places are reported', () => {
  const ranked = rankEntries([entry('a', 20, 5, 1, 1), entry('b', 20, 5, 1, 1), entry('c', 10, 0, 0, 4)]);
  const groups = unresolvedTiesWithin(ranked, 2);
  assert.equal(groups.length, 1);
  assert.deepEqual(groups[0]!.map((r) => r.registrationId).sort(), ['a', 'b']);
  assert.deepEqual(unresolvedTiesWithin(ranked, 0), []);
});

test('scoring rules reject invalid kill points, empty tables and repeated tie-breakers', () => {
  assert.deepEqual(validateScoringRules(mutableRules), []);
  assert.ok(validateScoringRules({ ...mutableRules, killPoint: -1 }).length > 0);
  assert.ok(validateScoringRules({ ...mutableRules, placementPoints: [] }).length > 0);
  assert.ok(validateScoringRules({ ...mutableRules, tiebreakOrder: ['kills', 'kills'] as never }).length > 0);
});
