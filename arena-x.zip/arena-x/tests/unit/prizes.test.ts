import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeAllocations, unallocatedMinor, validatePrizeShares, formatMinor } from '../../server/domain/prizes.ts';

test('shares split the pool exactly in integer minor units', () => {
  const allocations = computeAllocations(500_000, [5000, 3000, 2000]);
  assert.deepEqual(allocations, [
    { placement: 1, amountMinor: 250_000 },
    { placement: 2, amountMinor: 150_000 },
    { placement: 3, amountMinor: 100_000 },
  ]);
  assert.equal(unallocatedMinor(500_000, allocations), 0);
});

test('flooring leaves the remainder unallocated rather than inventing money', () => {
  const pool = 100_001;
  const allocations = computeAllocations(pool, [3333, 3333, 3333]);
  const paid = allocations.reduce((sum, a) => sum + a.amountMinor, 0);
  assert.equal(paid + unallocatedMinor(pool, allocations), pool);
  assert.ok(unallocatedMinor(pool, allocations) >= 0);
});

test('large pools keep precision beyond the float-safe range of intermediate products', () => {
  // 900e12 * 7777 is about 7e18, far above Number.MAX_SAFE_INTEGER; the BigInt path must stay exact.
  const pool = 900_000_000_000_000;
  const [first] = computeAllocations(pool, [7777]);
  assert.equal(first!.amountMinor, 699_930_000_000_000);
  assert.equal(unallocatedMinor(pool, [first!]), 200_070_000_000_000);
});

test('share validation rejects totals above 100 percent and non-integer basis points', () => {
  assert.deepEqual(validatePrizeShares([5000, 3000, 2000]), []);
  assert.ok(validatePrizeShares([6000, 5000]).length > 0);
  assert.ok(validatePrizeShares([1.5]).length > 0);
  assert.ok(validatePrizeShares([-1]).length > 0);
});

test('formatMinor renders minor units as currency', () => {
  assert.match(formatMinor(250_000, 'INR'), /2,500/);
});
